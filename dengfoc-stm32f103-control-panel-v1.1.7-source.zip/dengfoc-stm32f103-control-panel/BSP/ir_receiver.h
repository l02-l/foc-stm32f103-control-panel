/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef IR_RECEIVER_H
#define IR_RECEIVER_H
#include <stdint.h>
typedef struct
{
    uint16_t address;
    uint8_t command, repeat;
} IrEvent;
void ir_receiver_init(void);
uint8_t ir_receiver_pop(IrEvent *out);
#endif
