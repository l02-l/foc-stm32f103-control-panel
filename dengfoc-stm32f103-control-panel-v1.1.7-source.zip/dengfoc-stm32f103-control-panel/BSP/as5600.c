/*
 * 角度传感器：通过 PB10/PB11 读取 AS5600 的原始角度和磁场状态。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "as5600.h"
#include "soft_i2c.h"
/* 初始化传感器总线 PB10/PB11，对应例程的 AS5600_Init/MyI2C_Init。 */
void as5600_init(void)
{
    soft_i2c_init(&sensor_bus);
}
/* STATUS=0x0B、RAW_H=0x0C、RAW_L=0x0D 连续读取，避免周期性再发一整次状态事务。
 * AS5600 数据手册支持顺序读；从 STATUS 起始，三个字节依次递增到 RAW_L。
 * 成功只表示通信与角度格式有效；磁铁是否有效通过独立输出返回。
 */
uint8_t as5600_sample(uint16_t *raw, uint8_t *magnet_ok)
{
    uint8_t data[3];
    *magnet_ok = 0u;
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, data, 3u) || (data[1] & 0xF0u))
        return 0u;
    *raw = ((uint16_t)data[1] << 8) | data[2];
    *magnet_ok = (data[0] & 0x38u) == 0x20u;
    return 1u;
}
/* 读取 0x0C/0x0D 两字节并组合为 12 位原始角度。成功返回 1，失败返回 0，不用旧值冒充新数据。 */
uint8_t as5600_raw(uint16_t *raw)
{
    uint8_t data[2];
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Cu, data, 2u) || (data[0] & 0xF0u))
        return 0u;
    *raw = ((uint16_t)data[0] << 8) | data[1];
    return 1u;
}
/* 读取 0x0B 状态寄存器：必须检测到磁铁，且没有磁场过强或过弱标志。 */
uint8_t as5600_magnet_ok(void)
{
    uint8_t status = 0u;
    return soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, &status, 1u) && ((status & 0x38u) == 0x20u);
}
