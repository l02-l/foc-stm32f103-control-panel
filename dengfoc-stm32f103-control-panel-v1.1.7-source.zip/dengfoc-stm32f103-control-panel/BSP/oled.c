/*
 * 显示驱动：使用独立的 PB6/PB7 总线，兼容 128×64 的 SH1106/SSD1306。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "oled.h"
#include "soft_i2c.h"
#include <string.h>
#include <ctype.h>
static uint8_t buffer[1024], address, sh1106, available;
static uint16_t transfer_offset = 1024u;
static const char glyph_names[] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-+.:%/=>?_*#";
static const uint8_t glyphs[][5] = {{0, 0, 0, 0, 0},
                                    {0x3E, 0x51, 0x49, 0x45, 0x3E},
                                    {0, 0x42, 0x7F, 0x40, 0},
                                    {0x42, 0x61, 0x51, 0x49, 0x46},
                                    {0x21, 0x41, 0x45, 0x4B, 0x31},
                                    {0x18, 0x14, 0x12, 0x7F, 0x10},
                                    {0x27, 0x45, 0x45, 0x45, 0x39},
                                    {0x3C, 0x4A, 0x49, 0x49, 0x30},
                                    {1, 0x71, 9, 5, 3},
                                    {0x36, 0x49, 0x49, 0x49, 0x36},
                                    {6, 0x49, 0x49, 0x29, 0x1E},
                                    {0x7E, 0x11, 0x11, 0x11, 0x7E},
                                    {0x7F, 0x49, 0x49, 0x49, 0x36},
                                    {0x3E, 0x41, 0x41, 0x41, 0x22},
                                    {0x7F, 0x41, 0x41, 0x22, 0x1C},
                                    {0x7F, 0x49, 0x49, 0x49, 0x41},
                                    {0x7F, 9, 9, 9, 1},
                                    {0x3E, 0x41, 0x49, 0x49, 0x7A},
                                    {0x7F, 8, 8, 8, 0x7F},
                                    {0, 0x41, 0x7F, 0x41, 0},
                                    {0x20, 0x40, 0x41, 0x3F, 1},
                                    {0x7F, 8, 0x14, 0x22, 0x41},
                                    {0x7F, 0x40, 0x40, 0x40, 0x40},
                                    {0x7F, 2, 0x0C, 2, 0x7F},
                                    {0x7F, 4, 8, 0x10, 0x7F},
                                    {0x3E, 0x41, 0x41, 0x41, 0x3E},
                                    {0x7F, 9, 9, 9, 6},
                                    {0x3E, 0x41, 0x51, 0x21, 0x5E},
                                    {0x7F, 9, 0x19, 0x29, 0x46},
                                    {0x46, 0x49, 0x49, 0x49, 0x31},
                                    {1, 1, 0x7F, 1, 1},
                                    {0x3F, 0x40, 0x40, 0x40, 0x3F},
                                    {0x1F, 0x20, 0x40, 0x20, 0x1F},
                                    {0x7F, 0x20, 0x18, 0x20, 0x7F},
                                    {0x63, 0x14, 8, 0x14, 0x63},
                                    {3, 4, 0x78, 4, 3},
                                    {0x61, 0x51, 0x49, 0x45, 0x43},
                                    {8, 8, 8, 8, 8},
                                    {8, 8, 0x3E, 8, 8},
                                    {0, 0x60, 0x60, 0, 0},
                                    {0, 0x36, 0x36, 0, 0},
                                    {0x23, 0x13, 8, 0x64, 0x62},
                                    {0x20, 0x10, 8, 4, 2},
                                    {0x14, 0x14, 0x14, 0x14, 0x14},
                                    {0, 0x41, 0x22, 0x14, 8},
                                    {2, 1, 0x51, 9, 6},
                                    {0x40, 0x40, 0x40, 0x40, 0x40},
                                    /* 遥控提示使用星号和井号，缺字时原先会显示成空白。 */
                                    {0x14, 0x08, 0x3E, 0x08, 0x14},
                                    {0x14, 0x7F, 0x14, 0x7F, 0x14}};
/* 在命令流前补控制字节 0x00，再通过标准库 GPIO 软件 I²C 发送。 */
static uint8_t command(const uint8_t *data, uint16_t count)
{
    uint8_t packet[32];
    if (count > 31u)
        return 0u;
    packet[0] = 0u;
    memcpy(packet + 1, data, count);
    return soft_i2c_write(&display_bus, address, packet, count + 1u);
}
/* 探测七位地址 0x3C/0x3D，并根据 SH1106/SSD1306 选择初始化命令。 */
uint8_t oled_init(uint8_t use_sh1106)
{
    available = 0u;
    sh1106 = use_sh1106;
    soft_i2c_init(&display_bus);
    uint8_t off = 0xAEu;
    address = 0x3Cu;
    if (!command(&off, 1u))
    {
        address = 0x3Du;
        if (!command(&off, 1u))
            return 0u;
    }
    const uint8_t init[] = {0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40, 0xA1, 0xC8,
                            0xDA, 0x12, 0x81, 0x7F, 0xD9, 0x22, 0xDB, 0x20, 0xA4, 0xA6};
    if (!command(init, sizeof(init)))
        return 0u;
    const uint8_t sh[] = {0xAD, 0x8B}, ssd[] = {0x8D, 0x14, 0x20, 0x02};
    if (!command(sh1106 ? sh : ssd, sh1106 ? sizeof(sh) : sizeof(ssd)))
        return 0u;
    uint8_t on = 0xAFu;
    if (!command(&on, 1u))
        return 0u;
    available = 1u;
    transfer_offset = 1024u;
    oled_clear();
    oled_present();
    return 1u;
}
/* 返回屏幕最近一次初始化/传输是否成功，不用于判断电机状态。 */
uint8_t oled_available(void)
{
    return available;
}
/* 判断一帧显存是否仍未传完；传输期间不生成另一帧，避免画面混杂。 */
uint8_t oled_busy(void)
{
    return available && transfer_offset < 1024u;
}
/* 把 1024 字节显存清零；128×64 像素，每个像素占 1 bit。 */
void oled_clear(void)
{
    memset(buffer, 0, sizeof(buffer));
}
/* 在指定页写 ASCII 字符，每行最多 21 个；row 范围 0～7，每页高 8 像素。 */
void oled_text(uint8_t row, const char *s)
{
    if (row >= 8u)
        return;
    uint8_t *p = &buffer[(unsigned)row * 128u];
    unsigned col = 0u;
    while (*s && col < 21u)
    {
        char c = (char)toupper((unsigned char)*s++);
        const char *found = strchr(glyph_names, c);
        unsigned i = found ? (unsigned)(found - glyph_names) : 0u;
        memcpy(p + col * 6u, glyphs[i], 5u);
        p[col * 6u + 5u] = 0u;
        ++col;
    }
}
/* 请求发送新画面，实际传输由后台分多次完成。 */
void oled_present(void)
{
    if (available && transfer_offset >= 1024u)
        transfer_offset = 0u;
}
/* 每次只发送 16 字节显存。SH1106 列地址加 2，以适配常见 132 列内部显存。 */
void oled_poll(void)
{
    if (!oled_busy())
        return;
    uint8_t page = (uint8_t)(transfer_offset / 128u),
            col = (uint8_t)(transfer_offset % 128u) + (sh1106 ? 2u : 0u);
    uint8_t pos[] = {(uint8_t)(0xB0u | page), (uint8_t)(col & 0x0Fu),
                     (uint8_t)(0x10u | (col >> 4))};
    uint8_t data[17];
    data[0] = 0x40u;
    memcpy(data + 1, buffer + transfer_offset, 16u);
    if (!command(pos, sizeof(pos)) || !soft_i2c_write(&display_bus, address, data, sizeof(data)))
    {
        available = 0u;
        return;
    }
    transfer_offset += 16u;
}
