/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef BOARD_H
#define BOARD_H
#include "stm32f10x.h"
#include <stdint.h>

void board_init(void);
void board_start_control(void);
uint32_t board_millis(void);
uint32_t board_cycles(void);
uint16_t board_timer_us(void);
void board_delay_us(uint32_t us);
uint32_t board_lock(void);
void board_unlock(uint32_t key);
void board_gate(uint8_t enabled);
void board_pwm(uint16_t a, uint16_t b, uint16_t c);
void board_pwm_latch(void);
void board_current_request(void);
uint8_t board_uart_write(const char *s);
int board_uart_read(void);
uint32_t board_uart_dropped(void);
void board_watchdog_start(void);
void board_watchdog_feed(void);
#endif
