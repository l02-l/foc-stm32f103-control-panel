/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef OLED_PANEL_H
#define OLED_PANEL_H
#include <stdint.h>
uint8_t oled_init(uint8_t sh1106);
uint8_t oled_available(void);
uint8_t oled_busy(void);
void oled_clear(void);
void oled_text(uint8_t row, const char *text);
void oled_present(void);
void oled_poll(void);
#endif
