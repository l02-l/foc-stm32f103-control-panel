/*
 * 软件 I²C：参考例程 RWI2C.c，通过标准库 GPIO 函数产生时钟和数据波形。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "soft_i2c.h"
const SoftI2c sensor_bus = {GPIOB, GPIO_Pin_10, GPIO_Pin_11};
const SoftI2c display_bus = {GPIOB, GPIO_Pin_6, GPIO_Pin_7};
/* 给 SCL/SDA 电平留出建立与保持时间；实际速率还包括标准库函数执行时间。 */
static void pause_bus(const SoftI2c *b)
{
    /* OLED 总线放慢至约 100 kHz 以下；AS5600 总线保留原时序。 */
    board_delay_us(b == &display_bus ? 5u : 1u);
}
/* 通过标准库改变 SDA 输出；开漏写 1 表示释放总线，由外部上拉电阻拉高。 */
static void sda(const SoftI2c *b, uint8_t high)
{
    GPIO_WriteBit(b->port, b->sda, high ? Bit_SET : Bit_RESET);
}
/* 通过标准库把 SCL 拉低，准备更新下一位数据。 */
static void scl_low(const SoftI2c *b)
{
    GPIO_ResetBits(b->port, b->scl);
}
/* 释放 SCL，并检查线路确实变高；超出约 100 μs 仍为低则返回 0。 */
static uint8_t scl_high(const SoftI2c *b)
{
    GPIO_SetBits(b->port, b->scl);
    uint32_t start = board_cycles();
    while (GPIO_ReadInputDataBit(b->port, b->scl) == Bit_RESET)
        if ((uint32_t)(board_cycles() - start) > 7200u)
            return 0u;
    pause_bus(b);
    return 1u;
}
/* 产生起始或重复起始条件：SCL 为高时，把 SDA 从高拉低。 */
static uint8_t start_bus(const SoftI2c *b)
{
    sda(b, 1u);
    pause_bus(b);
    if (!scl_high(b) || GPIO_ReadInputDataBit(b->port, b->sda) == Bit_RESET)
        return 0u;
    sda(b, 0u);
    pause_bus(b);
    scl_low(b);
    return 1u;
}
/* 产生停止条件：SCL 为高时释放 SDA，使本次传输结束。 */
static void stop_bus(const SoftI2c *b)
{
    scl_low(b);
    sda(b, 0u);
    pause_bus(b);
    (void)scl_high(b);
    sda(b, 1u);
    pause_bus(b);
}
/* 先发最高位，共发送 8 位；第 9 个时钟读取从机 ACK，收到低电平才返回 1。 */
static uint8_t send_byte(const SoftI2c *b, uint8_t value)
{
    for (unsigned i = 0; i < 8u; i++)
    {
        sda(b, value & 0x80u);
        pause_bus(b);
        if (!scl_high(b))
            return 0u;
        scl_low(b);
        value <<= 1;
    }
    sda(b, 1u);
    pause_bus(b);
    if (!scl_high(b))
        return 0u;
    uint8_t ack = GPIO_ReadInputDataBit(b->port, b->sda) == Bit_RESET;
    scl_low(b);
    return ack;
}
/* 读取 8 位数据。last=0 时主机发 ACK 继续读；last=1 时发 NACK 结束读。 */
static uint8_t receive_byte(const SoftI2c *b, uint8_t *out, uint8_t last)
{
    uint8_t value = 0u;
    sda(b, 1u);
    for (unsigned i = 0; i < 8u; i++)
    {
        pause_bus(b);
        if (!scl_high(b))
            return 0u;
        value = (uint8_t)((value << 1) | GPIO_ReadInputDataBit(b->port, b->sda));
        scl_low(b);
    }
    sda(b, last);
    pause_bus(b);
    if (!scl_high(b))
        return 0u;
    scl_low(b);
    sda(b, 1u);
    *out = value;
    return 1u;
}
/* 把两根线配置成开漏输出，并发 9 个时钟尝试结束上次复位打断的传输。 */
void soft_i2c_init(const SoftI2c *b)
{
    GPIO_InitTypeDef g;
    g.GPIO_Pin = b->scl | b->sda;
    g.GPIO_Mode = GPIO_Mode_Out_OD;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_SetBits(b->port, b->scl | b->sda);
    GPIO_Init(b->port, &g);
    /* 复位可能把从机停在字节中间，先发 9 个时钟再发 STOP，尝试释放总线。 */
    for (unsigned i = 0; i < 9u; i++)
    {
        scl_low(b);
        pause_bus(b);
        (void)scl_high(b);
    }
    stop_bus(b);
}
/* 写入一个数据块。addr 为七位地址，函数内部左移并补上写方向位。 */
uint8_t soft_i2c_write(const SoftI2c *b, uint8_t addr, const uint8_t *data, uint16_t n)
{
    uint8_t ok = start_bus(b) && send_byte(b, (uint8_t)(addr << 1));
    while (ok && n--)
        ok = send_byte(b, *data++);
    stop_bus(b);
    return ok;
}
/* 先写寄存器地址，再重复起始读取数据；前面字节 ACK，最后字节 NACK，最后 STOP。 */
uint8_t soft_i2c_read_reg(const SoftI2c *b, uint8_t addr, uint8_t reg, uint8_t *out, uint16_t n)
{
    uint8_t ok = start_bus(b) && send_byte(b, (uint8_t)(addr << 1)) && send_byte(b, reg) &&
                 start_bus(b) && send_byte(b, (uint8_t)((addr << 1) | 1u));
    while (ok && n)
    {
        --n;
        ok = receive_byte(b, out++, n == 0u);
    }
    stop_bus(b);
    return ok;
}
