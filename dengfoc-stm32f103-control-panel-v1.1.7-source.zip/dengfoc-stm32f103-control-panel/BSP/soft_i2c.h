/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef SOFT_I2C_H
#define SOFT_I2C_H
#include "board.h"
/* port 是 GPIO 外设指针；scl/sda 是 GPIO_Pin_x 掩码，不是引脚序号。 */
typedef struct
{
    GPIO_TypeDef *port;
    uint16_t scl, sda;
} SoftI2c;
extern const SoftI2c sensor_bus, display_bus;
void soft_i2c_init(const SoftI2c *b);
uint8_t soft_i2c_write(const SoftI2c *b, uint8_t addr, const uint8_t *data, uint16_t count);
uint8_t soft_i2c_read_reg(const SoftI2c *b, uint8_t addr, uint8_t reg, uint8_t *out,
                          uint16_t count);
#endif
