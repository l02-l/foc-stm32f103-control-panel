/*
 * 红外接收：TIM3_CH1 在 PB4 捕获下降沿，后台再把有效 NEC 码转换为菜单事件。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "ir_receiver.h"
#include "nec_decoder.h"
#include "board.h"
static NecDecoder decoder;
static IrEvent queue[8];
static volatile uint8_t head, tail;
/* 使用标准库将 TIM3_CH1 部分重映射到 PB4；关闭 JTAG、保留 SWD，并配置下降沿捕获。 */
void ir_receiver_init(void)
{
    GPIO_InitTypeDef g;
    TIM_ICInitTypeDef capture;
    NVIC_InitTypeDef n;
    /* TIM3_CH1 部分重映射后是 PB4；释放 JTAG 引脚，同时保留 ST-LINK 使用的 SWD。 */
    GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
    g.GPIO_Pin = GPIO_Pin_4;
    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOB, &g);
    TIM_ICStructInit(&capture);
    capture.TIM_Channel = TIM_Channel_1;
    capture.TIM_ICPolarity = TIM_ICPolarity_Falling;
    capture.TIM_ICSelection = TIM_ICSelection_DirectTI;
    capture.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    capture.TIM_ICFilter = 3u;
    TIM_ICInit(TIM3, &capture);
    TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
    TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);
    n.NVIC_IRQChannel = TIM3_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 3;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
}
/* 读取硬件已锁存的 CCR1 时间戳，计算相邻下降沿间隔，解码成功后写入事件队列。 */
void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_CC1))
    {
        /* CCR1 在边沿到达时由硬件锁存，读取被高优先级中断推迟也不改变时间戳。 */
        uint16_t now = (uint16_t)TIM_GetCapture1(TIM3);
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
        static uint16_t previous;
        uint16_t dt = (uint16_t)(now - previous);
        previous = now;
        if (TIM_GetFlagStatus(TIM3, TIM_FLAG_CC1OF))
        {
            TIM_ClearFlag(TIM3, TIM_FLAG_CC1OF);
            decoder.state = 0u;
            return;
        }
        if (nec_falling(&decoder, dt))
        {
            uint8_t next = (head + 1u) & 7u;
            if (next != tail)
            {
                queue[head] = (IrEvent){decoder.address, decoder.command, decoder.repeat};
                head = next;
            }
        }
    }
}
/* 后台取出一个红外事件；返回 1 表示有数据，返回 0 表示队列为空。 */
uint8_t ir_receiver_pop(IrEvent *out)
{
    if (head == tail)
        return 0u;
    *out = queue[tail];
    tail = (tail + 1u) & 7u;
    return 1u;
}
