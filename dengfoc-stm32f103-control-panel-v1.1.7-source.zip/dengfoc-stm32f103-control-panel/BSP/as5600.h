/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef AS5600_PANEL_H
#define AS5600_PANEL_H
#include <stdint.h>
void as5600_init(void);
uint8_t as5600_sample(uint16_t *raw, uint8_t *magnet_ok);
uint8_t as5600_raw(uint16_t *raw);
uint8_t as5600_magnet_ok(void);
#endif
