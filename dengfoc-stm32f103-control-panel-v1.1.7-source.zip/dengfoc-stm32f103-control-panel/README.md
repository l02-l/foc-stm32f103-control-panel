# STM32F103 有感 FOC 电机控制台

基于 **DengFOC V3P、STM32F103C8T6、2208 电机与 AS5600** 的单电机控制项目。使用 STM32F10x 标准外设库和 Keil，实现电流、速度、位置三种模式，以及 OLED、红外遥控、串口调参和 Flash 参数保存。

通过红外遥控器或串口给定目标。应用源码包含中文注释，并附六节按实际模块展开的学习课程。

**当前版本 v1.1.7（无旋钮）。** 三模式无负载试运行及屏幕、遥控实测来自 v1.1.5 和 v1.1.6。[验证条件与日志](Docs/VALIDATION.md)

<p>
  <img src="Docs/Bench/oled_monitor_photo.jpg" alt="OLED 监视页面实物" width="260">
  <img src="Docs/Bench/oled_pid_photo.jpg" alt="电流 PID 参数页面" width="260">
</p>

## 功能

- 有感 FOC：两相电流反馈、Clarke/Park、反变换与三相 SPWM。
- Id/Iq 电流 PI、速度 PI、位置控制，目标斜坡、限幅和积分抗饱和。
- AS5600 单圈读取、64 位跨零累计、实测时间差测速与低通滤波。
- PWM 触发 ADC 注入采样，采样中断与控制计算分离。
- 电角零位/方向校准、机械位置清零、CRC 校验与 Flash 参数保存。
- SSD1306/SH1106 OLED 配置、NEC 遥控菜单、USART1 命令行。
- STOP/CAL/RUN/FAULT 状态机、传感器/时序故障、软件过流与看门狗。

## 控制结构

```mermaid
flowchart LR
    INPUT[串口 / 红外遥控] --> POS[位置控制 100 Hz]
    INPUT --> SPEED[速度控制 500 Hz]
    POS --> SPEED
    SPEED --> IQ[Iq 目标]
    INPUT --> IQ
    IQ --> CURRENT[Id/Iq 电流控制 3 kHz]
    CURRENT --> PWM[TIM2 PWM 15 kHz]
    PWM --> MOTOR[2208 电机]
    MOTOR --> AS[AS5600 1 kHz]
    AS --> POS
    AS --> SPEED
    AS --> CURRENT
    MOTOR --> ADC[两相 ADC 同步采样 15 kHz]
    ADC --> CURRENT
```

ADC 中断处理采样、零点、原始越限与分频发布；每五帧请求 PendSV 执行电流任务。TIM4 读角并调度外环，主循环处理命令、菜单与 OLED。[详细架构](Docs/ARCHITECTURE.md)

## 硬件与引脚

| 模块 | 当前配置 |
| --- | --- |
| 主控 | STM32F103C8T6，72 MHz，64 KB Flash / 20 KB SRAM |
| 驱动/电机 | DengFOC V3P + STM32 转接板，M0，2208 + AS5600 |
| 显示/输入 | 128×64 I²C OLED、NEC 红外遥控器 |
| 串口 | 转接板 CH340，115200 / 8N1，ASCII 文本与行尾 |

PA0/1/2：三相 PWM；PB0/1：电流 ADC；PB10/11：AS5600；PB6/7：OLED；PB4：红外；PA9/10：串口；PA8：两路驱动共用使能。[完整接线](Docs/WIRING.md)

## 构建与运行

环境为 **Keil MDK 5、ARM Compiler 6.18、Keil.STM32F1xx_DFP 2.4.0**。标准库、CMSIS 与启动源码已包含；编译器和设备包自行安装。

打开 `ControlPanel.uvprojx`，选择 `ControlPanel`。

PowerShell 构建示例，Keil 路径改为自己的安装位置：

```powershell
.\Tools\build.ps1 -Keil 'C:\Keil_v5\UV4\UV4.exe' -Target ControlPanel
```

输出为 `Firmware/ControlPanel.hex`，脚本不自动下载。完整课程构建和 ARM 测试见 [构建说明](Docs/BUILD.md)。仓库不附编译器、设备包和预编译固件。

上电保持 STOP。先查询 `status`，确认传感器、磁场与测流零点正常；首次校准按 [操作说明](Docs/USER_GUIDE.md) 执行，不复用别人的电角零位。校准和启动会让电机运动，`stop` / 遥控 `*` 用于停机，软件保护不替代可调限流电源。

串口命令单条发送，附 LF 或 CRLF。已完成本机校准后，速度模式顺序为 `mode speed` → `run` → `speed 5` → `stop`，逐条确认。`run` 重置旧目标，目标在启动后设置。

## 验证摘要

| 记录 | 条件与结果 |
| --- | --- |
| 三模式基础试运行 | 12 V、单台 2208、无外部负载；20 mA 末段平均 19.6 mA；±10 rpm 为 +8.81/−9.56 rpm；10° 末帧 9.22° |
| v1.1.6 遥控流程 | STOP→RUN→STOP；设定 5 rpm，确认转动；1183 个状态帧中 err=0、fault=NONE |
| 该轮最大耗时 | 控制 130 μs、读角 621 μs；对应该次采集 |
| v1.1.7 软件验证 | 主工程、测试工程与六个学习目标构建通过，ARM 合成测试与镜像审计通过 |

低速纹波、位置静差与带载表现仍需整定。[完整证据](Docs/VALIDATION.md)

## 源码目录

```text
App/       启动、串口命令、菜单、Flash 参数
BSP/       GPIO、TIM、ADC、I²C、传感器、OLED、红外
Control/   控制状态机、PI、坐标变换、调制与参数校验
Config/    频率、限值与标准库配置
Drivers/   ST 标准库、CMSIS、启动代码（保留原声明）
Learning/  六个独立课程入口和注释模块
Tests/     ARM 合成测试源码
Tools/     构建、测试、仓库检查与源码打包
Docs/      接线、操作、验证、来源与学习索引
```

## 学习课程

| 课 | 内容 |
| --- | --- |
| [01](Learning/Lesson01/README.md) | 工程入口与任务协作 |
| [02](Learning/Lesson02/README.md) | 时钟树与 GPIO |
| [03](Learning/Lesson03/README.md) | USART、环形缓冲与命令解析 |
| [04](Learning/Lesson04/README.md) | AS5600、跨零与速度估计 |
| [05](Learning/Lesson05/README.md) | PWM、同步采样与多速率调度 |
| [06](Learning/Lesson06/README.md) | 两相电流测量与零点换算 |

课程使用独立 Keil 工程；课程编译通过不等于额外上板验收。[完整大纲](Docs/LEARNING_OUTLINE.md)

## 来源与许可

参考 DengFOC 例程与硬件资料学习、改编，见 [来源与贡献范围](Docs/SOURCES.md)。ST/Arm 文件保留原版权与声明，原套件、原理图和工具安装包不随仓库分发。

项目新增部分暂未指定统一开源许可证；第三方文件保留原声明。详见 [LICENSING](LICENSING.md) 与 [第三方说明](THIRD_PARTY_NOTICES.md)。
