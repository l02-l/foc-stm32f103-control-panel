# 第三方来源说明

| 范围 | 来源与版本 | 处理 |
| --- | --- | --- |
| Drivers/SPL | STMicroelectronics STM32F10x Standard Peripheral Library V3.5.0，2011-03-11 | 保留原文件头、版权及免责声明 |
| Drivers/CMSIS/core_cm3.h | Arm CMSIS Cortex-M3 V1.30，2009-10-30 | 保留原文件声明 |
| Drivers/CMSIS 其余设备/启动源码 | DengFOC STM32 例程附带的 ST/CMSIS | 保留声明；项目启动栈改为 4 KB，堆为 0 |
| 控制公式、引脚与示例思路 | DengFOC V3P STM32 第 2/3/4/8 套例程 | 来源关系见 Docs/SOURCES.md，不附原套件 |
| OLED 兼容信息 | 原工作区 stm32f10x_pal_oled.c 与 SSD1306/SH1106 资料 | 参考初始化差异，不附模板包 |

Learning 中的 board/console/motor 连接文件由 Tools/make_learning_project.py 生成。第三方代码、参考公式和本项目新增的应用组织应分别说明，见 [LICENSING](LICENSING.md)。
