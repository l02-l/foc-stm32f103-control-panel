/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* 接线见 Docs/WIRING.md。新增 OLED、红外统一使用 3.3 V 电平。 */
#define APP_VERSION "1.1.7"
#define BOARD_CPU_HZ 72000000u /* HSE 8 MHz 经 PLL×9 得到 72 MHz */
#define BOARD_PWM_HZ 15000u    /* PWM 载波频率，单位 Hz */
#define BOARD_PWM_COUNTS 4800u /* ARR+1，取 4800 得到 15 kHz */
#define BOARD_ADC_TRIGGER_TICKS 4400u /* 约 61.1 μs，在默认调制的低电平零矢量区采两相 */
#define BOARD_CURRENT_DIV 5u   /* 15 kHz ADC 每 5 帧运行一次电流环，即 3 kHz */
#define BOARD_CURRENT_FILTER_ALPHA 0.25f /* 3 kHz d/q 反馈一阶低通，约 1 ms 时间常数 */
#define BOARD_SPEED_FILTER_TAU_S 0.02f   /* 测速滤波时间常数，20 ms，减少低速反馈滞后 */
#define BOARD_SENSOR_HZ 1000u  /* 角度读取和外环调度的基本频率 */
#define BOARD_ADC_VREF 3.3f          /* ADC 参考电压，单位 V，实测偏差会影响电流比例 */
#define BOARD_SHUNT_OHMS 0.01f       /* 分流电阻，单位 Ω，依据 V3P 原理图 */
#define BOARD_CURRENT_GAIN 50.0f     /* INA240A2 电流放大器增益 */
#define BOARD_CURRENT_A_SIGN (-1.0f) /* 按例程规定电流正方向，不能凭波形外观随意翻转 */
#define BOARD_CURRENT_B_SIGN (-1.0f)
#define BOARD_OFFSET_SAMPLES 4096u         /* 停机时平均这些 ADC 样本，得到电流零点 */
#define BOARD_SETTINGS_ADDRESS 0x0800FC00u /* C8 的 64 KB Flash 最后 1 KB 页，已从链接区预留 */
#define BOARD_UART_BAUD 115200u
#define BOARD_OLED_SH1106 0         /* 本机实测使用 SSD1306 点亮；1=SH1106，串口可切换 */
#define BOARD_CONTROL_BUDGET_US 200u /* 3 kHz PendSV 控制任务预算，低于约 333 μs 控制周期 */
#define BOARD_SENSOR_BUDGET_US 900u /* 单次角度任务预算，单位 μs */
#define APP_PI 3.14159265358979323846f
#define APP_TAU (2.0f * APP_PI)

#endif
