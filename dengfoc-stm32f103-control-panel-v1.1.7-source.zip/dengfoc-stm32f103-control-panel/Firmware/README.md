# 固件输出

此目录存放本地构建产生的固件，Git 不跟踪 HEX/BIN。

- `Tools/build.ps1` 生成 `ControlPanel.hex`。

正式 Target 为 ControlPanel。下载与首次校准见 [操作说明](../Docs/USER_GUIDE.md)。
