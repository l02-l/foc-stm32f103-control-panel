# 上传 GitHub

推荐仓库名：`dengfoc-stm32f103-control-panel`。

描述可用：`STM32F103 有感 FOC 电机控制台：三环控制、AS5600、OLED、红外遥控与串口调参，基于标准外设库。`

建议 Topics：`stm32`、`stm32f103`、`foc`、`motor-control`、`pmsm`、`embedded-c`、`as5600`。

## GitHub Desktop

1. 打开 GitHub Desktop，登录自己的账号。
2. File → Add local repository，选择此文件夹，确保是含 ControlPanel.uvprojx 的仓库根目录。
3. 查看 Changes，创建首次提交，摘要可填 `Prepare STM32 FOC control panel project`。
4. Publish repository，填写仓库名和描述，自行选择 Public/Private。
5. 发布后确认首页图片、接线说明、六节课程和 Actions 检查均可打开。

不要把整个原工作区、原套件或 ZIP 当作唯一仓库文件上传；使用本目录的正常源码树。GitHub Desktop 会使用 .gitignore 排除生成文件。

## Git 命令行

先在 GitHub 创建一个空仓库，不预先生成 README 或许可证，复制实际仓库地址。在本目录终端执行：

```powershell
git status
git add .
git commit -m "Prepare STM32 FOC control panel project"
```

若 Git 提示未配置作者身份，先设置自己的用户名和提交邮箱；不要照抄别人的身份。

```powershell
git config user.name "你的 Git 提交署名"
git config user.email "你的提交邮箱或 GitHub 隐私邮箱"
```

随后将下面地址替换为自己创建的真实地址：

```powershell
git remote add origin https://github.com/YOUR_ACCOUNT/dengfoc-stm32f103-control-panel.git
git push -u origin main
```

占位地址不是真实仓库。仓库已经有 origin 时先用 `git remote -v` 核对，不盲目追加或覆盖。

## 许可与后续演示

当前新增代码没有统一开源许可证，第三方文件保留原声明。发布前按自己的意愿决定是否另给拥有权利的新增部分选择许可证，见 [LICENSING](../LICENSING.md)。

后续可在首页加入自己录制的演示视频链接。性能数值保留测试条件和真实证据，个人实现/改编范围见 [SOURCES](SOURCES.md)。
