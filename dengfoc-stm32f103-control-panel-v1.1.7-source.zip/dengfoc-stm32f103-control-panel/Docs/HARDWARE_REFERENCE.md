# 硬件与原套件资料

当前硬件接线见 [WIRING](WIRING.md)。学习课程引用的以下原套件资料未随仓库分发：

- V3P 驱动板最新版原理图：R15/R16=0.01 Ω，U6/U7=INA240A2，M0 两相前端。
- STM32 转接板原理图：M0/M1 信号和板载 CH340。
- STM32F103C8T6 核心板原理图：电源、晶振、BOOT、SWD。
- 「3、stm例程资料」第 2/3/4/8 套标准库例程及「注意事项（必看）」。

原课程指向套件文件的链接在上传版中统一转到本页，说明原资料名称和用途。当前软件构建依赖均位于本仓库及安装的工具链，不依赖原工作区目录。

器件资料：[STM32F103](https://www.st.com/resource/en/datasheet/stm32f103c8.pdf)、[RM0008](https://www.st.com/resource/en/reference_manual/cd00171190.pdf)、[INA240](https://www.ti.com/lit/ds/symlink/ina240.pdf)、[AS5600 厂商文档镜像](https://www.mouser.com/datasheet/2/588/AS5600_DS000365_5_00-1877365.pdf)。
