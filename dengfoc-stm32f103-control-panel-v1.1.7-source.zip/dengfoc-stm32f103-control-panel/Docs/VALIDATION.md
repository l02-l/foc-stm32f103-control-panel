# 验证记录

## 实物基线

2026-10-31，12 V、单台 2208、AS5600、V3P、STM32F103C8T6、无外部负载。三模式基础记录对应 v1.1.5，屏幕/遥控与连续读角修订为 v1.1.6。

| 项目 | 结果与条件 |
| --- | --- |
| 电流目标 20 mA | 初轮末段平均 19.6 mA |
| 速度目标 +10 / −10 rpm | 初轮末段平均 +8.81 / −9.56 rpm |
| 位置目标 +10° | 初轮末帧约 9.22° |
| 保存与重启 | cal=1、增益保存并加载，重启保持 STOP |
| OLED / 遥控 | 模式、翻页、选择/修改 KP/KI、启动/目标/停止获实物确认 |
| v1.1.6 最终流程 | STOP→RUN→STOP，REF=5，确认转动；1183 状态帧 err=0、fault=NONE |
| 该轮最大记录耗时 | 控制 130 μs、传感器 621 μs；60/60 OLED 快照可用 |

初轮与复测不是同一批数据。这些为基本无负载结果，低速波动、位置静差、带载表现及真实电流比例仍需整定/标定。

原始资料：

- [三模式审核](ENGINEERING_REVIEW.md)
- [屏幕与遥控](UI_VALIDATION.md)
- [三模式日志](Bench/review_closed_loops_1_1_5.txt) / [统计](Bench/review_closed_loops_1_1_5.json)
- [最终遥控日志](Bench/ui_remote_final_1_1_6.txt) / [统计](Bench/ui_final_result_1_1_6.json)
- [接线重插后的复测](Bench/ui_burst_reseated_1_1_6.txt)

TIMING/SENSOR 失败过程也保留在 Bench，以区分修复前后。

## 软件与镜像

历史测试在 Unicorn 中执行真实 Keil ARM 代码，以合成输入替代硬件：2552 项断言、0 失败。[历史机器结果](Evidence/historical_results.json)

历史 v1.1.6 镜像：无旋钮 Flash/RAM=41696/7256 字节，旋钮目标=42280/7272；已检查向量与最后 1 KB 参数页。[历史镜像报告](Evidence/historical_image_audit.json)

v1.1.7 无旋钮版的重新构建与检查见 [发布整理记录](RELEASE_PREPARATION.md)。合成测试不模拟真实电机、总线波形或 NVIC 抢占；课程编译也不等于新增硬件验收。复现见 [BUILD](BUILD.md)。
