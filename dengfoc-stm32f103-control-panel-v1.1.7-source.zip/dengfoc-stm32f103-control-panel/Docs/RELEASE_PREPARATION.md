# GitHub 发布整理 · v1.1.7

2026-11-23。正式 Keil 工程的目标为 `ControlPanel`。通过红外遥控器或串口给定目标，OLED 监视页显示 AS5600 原始计数。源码使用 STM32F10x 标准外设库，含六个独立学习工程和中文注释。

Flash v1 布局和 CRC 算法沿用旧版。旧记录校验通过后，原输入选择位归零，PID、电角校准、遥控码和屏幕配置继续加载。OLED 与 AS5600 分别使用 PB6/PB7 和 PB10/PB11。

## 构建与验证

Windows、ARM Compiler 6.18、Keil.STM32F1xx_DFP 2.4.0。

| 目标 | Keil 重建 |
| --- | --- |
| ControlPanel | 0 错误、0 警告 |
| CoreTests | 0 错误、0 警告 |
| Lesson01～Lesson06_NoKnob | 六个目标均 0 错误、0 警告 |

[构建日志](Evidence/Build)中的本机编译器路径已匿名化。

- 在 Unicorn 执行 Keil 编译的 ARM 代码，2530 项断言、0 失败。[合成测试结果](Evidence/repository_results_2026-11-23.json)
- 使用旧版 ARM 代码接受的 Flash v1 记录验证新版读取。旧输入标记归零，其余参数字节一致，CRC 损坏的记录被拒绝。[兼容验证结果](Evidence/flash_compatibility_v1.1.7.json)
- 正式镜像占用 Flash 40824 字节、RAM 7240 字节。核对控制中断向量、内存边界与最后 1 KB 参数区。[镜像审计](Evidence/repository_image_audit_2026-11-23.json)

v1.1.7 完成上述软件验证，待上板复测。三模式试运行及 OLED/遥控的实物数据来自 v1.1.5 和 v1.1.6。[实物记录](VALIDATION.md)

## 发布文件

源码包包含正式工程、课程、构建工具、说明与 SHA-256 清单。Keil 编译生成的固件位于 `Firmware/ControlPanel.hex`。复现步骤见 [构建说明](BUILD.md)。
