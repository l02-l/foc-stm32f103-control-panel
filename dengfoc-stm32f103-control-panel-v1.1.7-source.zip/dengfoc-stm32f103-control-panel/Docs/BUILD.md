# 构建与验证

## STM32

环境为 Windows、Keil MDK 5、ARM Compiler 6.18、Keil.STM32F1xx_DFP 2.4.0。Python 3.10+ 用于仓库工具和 ARM 测试；在 Keil 编译正式固件无需 Python。

打开 ControlPanel.uvprojx，选择 ControlPanel。如果提示 Compiler 5 不存在，确认目标使用 ARM Compiler 6，并打开了本仓库工程。

```powershell
.\Tools\build.ps1 -Keil 'C:\Keil_v5\UV4\UV4.exe' -Target ControlPanel
```

也可通过 KEIL_UV4 环境变量指定 UV4.exe/uVision.com。输出位于 Objects/Bench，ControlPanel.hex 同时复制到 Firmware。脚本不烧录、不访问串口。

最后 1 KB Flash（0x0800FC00）用于参数，链接区预留该页。下载和首次校准见 [操作说明](USER_GUIDE.md)。

## 课程工程

```powershell
python Tools/make_learning_project.py
.\Tools\build.ps1 -Keil 'C:\Keil_v5\UV4\UV4.exe' -Target Learning
```

Lesson01 打开 ControlPanel_Learning.uvprojx；Lesson02～06 分别打开 ControlPanel_Lesson02.uvprojx 等。每个目标只链接自己的入口和替换模块。

## ARM 合成测试

```powershell
python -m pip install -r Tests/requirements.txt
python Tools/make_test_project.py
.\Tools\build.ps1 -Keil 'C:\Keil_v5\UV4\UV4.exe' -Target CoreTests
python Tools/run_arm_tests.py
python Tools/audit_images.py
```

最后一条需先构建 ControlPanel。测试执行实际 Keil ARM 代码，以合成输入替代硬件边界，不验证真实中断时序、电机模型或总线波形。结果写入 Tests/results.json、Tests/image_audit.json，历史证据保存在 Docs/Evidence。

## 仓库检查与打包

```powershell
python Tools/check_repository.py
python Tools/package.py
```

GitHub Actions 检查工程引用、链接、生成连接文件和源码卫生，不把这些检查称作固件编译。源码 ZIP 输出到 dist，以 Git 已跟踪文件为范围，不包含构建产物和个人缓存。
