# 代码学习入口 · v1.1.7

当前基线为 **ControlPanel：无旋钮，保留遥控器、OLED 与串口**。第一课已按完成实机修订后的代码重写。

## 第一课从这里开始

- [完整课程：知识点、伪代码、填空、注释代码、自测与答案](../Learning/Lesson01/README.md)
- [学习入口 main.c](../Learning/Lesson01/main.c)
- [独立学习工程](../ControlPanel_Learning.uvprojx)：Target 选择 Lesson01_NoKnob。
- [实际编译记录](../Learning/Lesson01/build.log)：零错误、零警告。本轮未烧录学习入口。
- [知识库全文](../Learning/Lesson01/README.md)
- [16 部分完整大纲](LEARNING_OUTLINE.md)

第一课预计 5～6 小时，重点是写出初始化顺序、解释 ADC→PendSV 和 TIM4 读角两条任务路径。学习入口增加每秒一条 L1 状态日志，正式工程 App/main.c 保持原样。

## 学习与正式工程的区别

| 项目 | 正式 ControlPanel | Lesson01_NoKnob |
| --- | --- | --- |
| 入口 | App/main.c | Learning/Lesson01/main.c |
| 控制/驱动/显示模块 | 实际项目模块 | 复用同一套模块 |
| L1 任务观察日志 | 无 | 约 1 Hz |
| 常规遥测 | 约 10 Hz，log 0/1 控制 | 同左；log 0 不关闭 L1 |
| HEX | Firmware/ControlPanel.hex | Objects/Lesson01/Lesson01_NoKnob.hex |

两个入口分别编译，不能把两个 main.c 同时加进同一个 Target。

## 第一课完成后

提交你自己的启动伪代码、两条任务路径图和自测答案。

## 第二课：板级资源、时钟树与 GPIO

- [完整课程](../Learning/Lesson02/README.md)，含知识讲解、完整注释代码、练习与答案。
- [本课模块](../Learning/Lesson02/lesson02_resources.c) 与 [入口](../Learning/Lesson02/main.c)。
- [独立工程 ControlPanel_Lesson02.uvprojx](../ControlPanel_Lesson02.uvprojx)，Target 为 Lesson02_NoKnob。
- [编译记录](../Learning/Lesson02/build.log)：零错误、零警告，尚未烧录。
- [知识库第二课](../Learning/Lesson02/README.md)。

建议 8～10 小时，重点是 8 MHz→72 MHz 时钟路径、APB1 的 36/72 MHz 区别、GPIO 电气方式和位掩码。本课模块实际接入 board_init；其他板级逻辑由正式 BSP/board.c 生成到 board_lesson02.c。

重新生成课程工程可运行 Tools/make_learning_project.py，它会生成各课独立工程及对应连接文件；修改模块源码时注意区分手写文件和生成文件。GPIO 练习修改 lesson02_resources.c；需要更新生成文件时再运行脚本。

项目的当前实物结果见 [完整审核](ENGINEERING_REVIEW.md) 与 [屏幕/遥控验证](UI_VALIDATION.md)。已有基础功能验证不等于已经独立理解全部实现，课程按实际模块逐步完成。

## 第三课：USART1、环形缓冲与命令调试

- [完整课程](../Learning/Lesson03/README.md)，含收发原理、真实源码、写代码练习和 12 道自测。
- [中文注释命令模块](../Learning/Lesson03/lesson03_commands.c) 与 [入口](../Learning/Lesson03/main.c)。
- [独立工程 ControlPanel_Lesson03.uvprojx](../ControlPanel_Lesson03.uvprojx)，Target 为 Lesson03_NoKnob。
- [编译记录](../Learning/Lesson03/build.log)：零错误、零警告，尚未烧录。
- [知识库第三课](../Learning/Lesson03/README.md)。

建议 8～10 小时。新增 echo/uart 命令经过真实 UART、中断队列和行解析流程；练习在 lesson03_commands.c 增加 ping。console_lesson03.c 由正式 App/console.c 生成并插入学习命令调用；本课工程只链接这一份 console。正式工程不增加这些学习命令。

## 第四课：AS5600、软件 I²C 与角度速度估计

- [完整课程](../Learning/Lesson04/README.md)：寄存器读取、指针、位操作、跨零、原点、实际 dt 与滤波。
- [详细中文注释的传感器模块](../Learning/Lesson04/lesson04_sensor.c) 与 [学习入口](../Learning/Lesson04/main.c)。
- [独立工程 ControlPanel_Lesson04.uvprojx](../ControlPanel_Lesson04.uvprojx)，Target 为 Lesson04_NoKnob。
- [编译记录](../Learning/Lesson04/build.log)：ARM Compiler 6.18，零错误、零警告，尚未烧录。
- [知识库第四课](../Learning/Lesson04/README.md)。

建议 10～12 小时。TIM4 仍走实际 1 kHz 采样链，学习模块替代本课 Target 的 BSP/as5600.c；主循环每 500 ms 观察快照。主要编码练习是独立写 sample 函数。本课不保留第三课专用 echo/uart 分支，正式项目代码不变。

## 第五课：PWM、同步采样与定时调度

- [完整课程](../Learning/Lesson05/README.md)：PSC/ARR/CCR、预装载、ADC 触发、分频、优先级与任务预算。
- [详细中文注释的定时模块](../Learning/Lesson05/lesson05_timing.c) / [头文件](../Learning/Lesson05/lesson05_timing.h)，以及 [学习入口](../Learning/Lesson05/main.c)。
- [独立工程 ControlPanel_Lesson05.uvprojx](../ControlPanel_Lesson05.uvprojx)，Target 为 Lesson05_NoKnob。
- [编译记录](../Learning/Lesson05/build.log)：ARM Compiler 6.18，零错误、零警告，尚未烧录。
- [知识库第五课](../Learning/Lesson05/README.md)。

建议 10～12 小时。board_lesson05.c 从正式 board.c 生成，把 pwm_adc_init 替换为本课模块调用，其余逻辑复用正式版本。L5 配置日志按寄存器计算频率，每秒输出 ds/dc 任务计数差；不以这些日志代替 PWM 波形或逐周期时序实测。主要练习为重写 TIM4 等价配置，正式工程保持原样。

## 第六课：两相电流测量与 ADC 零点

- [完整课程](../Learning/Lesson06/README.md)：原理图、电压/电流换算、启动平均、方向、重建与残差。
- [中文注释换算模块](../Learning/Lesson06/lesson06_current.c) / [头文件](../Learning/Lesson06/lesson06_current.h)，以及 [学习入口](../Learning/Lesson06/main.c)。
- [独立工程 ControlPanel_Lesson06.uvprojx](../ControlPanel_Lesson06.uvprojx)，Target 为 Lesson06_NoKnob。
- [编译记录](../Learning/Lesson06/build.log)：ARM Compiler 6.18，零错误、零警告，尚未烧录。
- [知识库第六课](../Learning/Lesson06/README.md)。

建议 10～12 小时。motor_lesson06.c 从正式 motor.c 生成，只增加头文件并将两相电流换算接到本课函数，其余控制逻辑复用正式版本。L6 每 500 ms 用快照中的最新 ADC/零点生成对应计算电流，不将不同更新率的原始量和相电流混作同帧。主要练习为独立写 ADC 到 A 的函数；静态零点观察与实际电流标定分别记录。
