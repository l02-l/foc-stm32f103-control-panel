# 接线 · v1.1.7 无旋钮

STM32 控制 M0 电机，红外遥控和板载 USB 串口提供指令。

接线前断开电源。原有 STM32、转接板、V3P 堆叠保留，转接板与 V3P 天线丝印同向。只连接 M0 电机，M1 三相端子不接电机。

## 原有模块

| 模块端 | STM32 / V3P 端 | 说明 |
| --- | --- | --- |
| M0 三相 | V3P M0 三相端子 | 相序更改后重新校准 |
| AS5600 SCL / SDA | PB10 / PB11，SCL0 / SDA0 | 保留原有四芯线 |
| AS5600 3V3 / GND | 3.3 V / GND | 保证接触可靠 |
| M0 电流采样 | PB0 / PB1 | 转接板已有连接 |
| OLED SCL / SDA | PB6 / PB7，SCL1 / SDA1 | OLED 专用总线 |
| OLED VCC / GND | STM32 侧 3V3 / GND | 总线统一 3.3 V |
| 红外接收头 S / + / - | PB4 / 3V3 / GND | TIM3 输入捕获，固件关闭 JTAG、保留 SWD |
| USB-TTL RX / TX / GND | PA9 / PA10 / GND | 115200、8N1，TX/RX 交叉 |
| ST-LINK SWDIO / SWCLK / GND | PA13 / PA14 / GND | 保留现有下载连接 |

## 优先使用绿色 STM32 转接板的 USB 串口

配套 `STM32转接板原理图.pdf` 中已有 CH340E，RXD 接 STM32 PA9/TXD，TXD 接 PA10/RXD。使用该转接板 USB 接电脑即可访问 USART1，选择对应 COM、115200、8N1。此时无需外接 USB-TTL，也无需在 PA9/PA10 上缠绕飞线；外接 USB-TTL 应断开，避免多个发送端同时连接。

这里指绿色 STM32 转接板的 USB 接口。蓝色核心板自身 USB 在本工程中没有 USB CDC 功能。仅验证串口 help 时保持 V3P 的 12 V 电机电源断开，恢复叠装前断电并核对排针方向。

## 编译目标与下载

使用 `ControlPanel` 目标。供电恢复后，检查串口启动文字 `DengFOC ControlPanel 1.1.7 | PA8 OFF`。OLED 的 SDA/SCL 上拉至 3.3 V，AS5600 使用独立的 PB10/PB11。

OLED 默认 SSD1306 兼容配置，当前样机已用此配置点亮并核对照片。可发送 `screen ssd1306` 或 `screen sh1106` 切换，停机 `save` 保存；I²C 地址相同不代表控制器初始化可以混用。屏幕尺寸为 128×64。红外默认 NEC，按键不匹配时观察串口 `IR addr=... cmd=...`，按操作手册修改映射。

PA8 同时控制两路驱动供电，工程固定未使用 M1 的 PA3/PA6/PA7 为低。现有 12 V/2 A 适配器没有可调限流，电机控制参数仍需按实际电流和运行状态调试。
