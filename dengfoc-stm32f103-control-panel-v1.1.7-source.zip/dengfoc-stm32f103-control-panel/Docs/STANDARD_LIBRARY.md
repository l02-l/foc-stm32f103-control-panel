# 标准库与例程对照 · 中文注释版

本项目使用原套件「3、stm例程资料」中的 **STM32F10x 标准外设库 V3.5.0**。驱动和 CMSIS 已复制到工程内，Keil 中定义 `USE_STDPERIPH_DRIVER`、`STM32F10X_MD`。项目自身的 GPIO、TIM、ADC、USART、Flash、IWDG 操作统一调用标准库函数。

## 从例程找到对应项目代码

| 指定目录中的资料 | 当前工程 | 可直接对照的接口 |
| --- | --- | --- |
| 第 2 套 `Hardware/pwm.c` | `BSP/board.c` 的 `pwm_adc_init()`、`board_pwm()` | `RCC_APB1PeriphClockCmd`、`TIM_TimeBaseInit`、`TIM_OC1/2/3Init`、`TIM_SetCompare1/2/3` |
| 第 2 套 `Hardware/RWI2C.c` | `BSP/soft_i2c.c` | `GPIO_Init`、`GPIO_WriteBit`、`GPIO_SetBits`、`GPIO_ResetBits`、`GPIO_ReadInputDataBit` |
| 第 2 套 `Hardware/AS5600.c` | `BSP/as5600.c` | 写 `0x0C` 寄存器地址，重复起始读取高低字节，正确 ACK/NACK |
| 第 2 套 `Hardware/Serial.c` | `BSP/board.c` 的 `uart_init()`、`USART1_IRQHandler()` | `USART_Init`、`USART_ITConfig`、`USART_GetITStatus`、`USART_ReceiveData`、`USART_SendData` |
| 第 2 套 `Hardware/AD.c`、第 8 套 `Sensor/Inlinecurrent.c` | `BSP/board.c`、`Control/motor.c` | `ADC_Init`、`ADC_InjectedChannelConfig`、`ADC_GetInjectedConversionValue`，保留原板的电流换算比例和引脚方向 |
| 第 8 套 `Run_FOC/DFOC.c` | `Control/control_math.c`、`Control/motor.c` | Clarke/Park、反变换、三相调制及“位置→速度→电流”控制链 |
| 第 8 套 `Run_FOC/PID_Control.c` | `cm_pid_step()`、`cm_pid_track()` | 显式传入 dt、积分保存、输出限幅及积分饱和处理 |
| 例程的中断文件和标准库 TIM 示例 | `BSP/board.c` 的 `TIM4_IRQHandler()`、`BSP/ir_receiver.c` | `TIM_GetITStatus`、`TIM_ClearITPendingBit`、`TIM_GetCapture1` |

完整应用把原例程里的分散初始化集中到板级文件 `board.c`，控制算法集中到 `Control`。初学时先看相同的标准库调用，再学习它们如何通过中断、缓冲区和状态机协作。

## 主要外设的标准库写法

```c
/* 与例程 PWM_Channel1/2/3 的原理一致。 */
TIM_SetCompare1(TIM2, compare_a);
TIM_SetCompare2(TIM2, compare_b);
TIM_SetCompare3(TIM2, compare_c);

/* 软件 I²C 用标准库拉低/释放开漏引脚。 */
GPIO_ResetBits(GPIOB, GPIO_Pin_10);
GPIO_SetBits(GPIOB, GPIO_Pin_10);

/* 注入组按 PWM 时刻采样，读取两路转换结果。 */
raw_a = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
raw_b = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
```

STM32 ADC 使用 TIM2 触发的注入组采两相电流。OLED 和 AS5600 使用独立的软件 I²C 总线，GPIO 操作由标准库完成。

## 内核计时和临界区

`SysTick_Config`、`NVIC_SetPriority`、`__disable_irq`、`__DMB` 属于 CMSIS 内核接口。DWT 周期计数和 PRIMASK 也是 Cortex-M3 内核资源，标准外设库没有对应封装；兼容旧 CMSIS 所需的少量内核寄存器访问和内联汇编集中在 `board.c`。GPIO、定时器、ADC 和串口的应用代码使用标准库接口。

## 中文注释怎样阅读

- 每个 `.c` 模块开头说明用途，函数前说明输入/输出或调用场景。
- 结构体和配置宏标明 `rad`、`rpm`、`A`、`V`、计数等单位。
- `motor.c` 解释三环、目标斜坡、校准阶段、ADC 零点和电角换算。
- `control_math.c` 解释跨零、PID、坐标变换和占空比计算。
- 源码使用 **UTF-8**；Keil 中若中文显示乱码，应按 UTF-8 重新打开。串口命令和 OLED 标签保持既有英文标识，以匹配当前 ASCII 字库与使用说明。

ST 原版 `Drivers` 文件保留官方版权和原注释。项目自身的 `App/BSP/Control/Config` 已添加中文学习注释，并统一采用四空格缩进、展开函数体的格式。
