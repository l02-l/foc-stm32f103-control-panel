param(
    [string]$Keil = $env:KEIL_UV4,
    [string]$Target = 'All',
    [switch]$Rebuild
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if (-not $Keil) {
    $command = Get-Command 'uVision.com', 'UV4.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($command) { $Keil = $command.Source }
}
if (-not $Keil -or -not (Test-Path -LiteralPath $Keil -PathType Leaf)) {
    throw 'Specify -Keil <UV4.exe/uVision.com path> or set KEIL_UV4.'
}
$targets = switch ($Target) {
    'All' { @('ControlPanel') }
    'Learning' { 1..6 | ForEach-Object { 'Lesson{0:00}_NoKnob' -f $_ } }
    default { @($Target) }
}
$buildFlag = if ($Rebuild) { '-r' } else { '-b' }
Push-Location $projectRoot
try {
    foreach ($name in $targets) {
        $project = switch -Regex ($name) {
            '^ControlPanel$' { 'ControlPanel.uvprojx'; break }
            '^CoreTests$' { 'CoreTests.uvprojx'; break }
            '^Lesson01_NoKnob$' { 'ControlPanel_Learning.uvprojx'; break }
            '^Lesson0([2-6])_NoKnob$' { "ControlPanel_Lesson0$($Matches[1]).uvprojx"; break }
            default { throw "Unknown target: $name" }
        }
        [xml]$xml = Get-Content -LiteralPath $project -Raw
        $entry = $xml.Project.Targets.Target | Where-Object { $_.TargetName -eq $name }
        if (-not $entry) { throw "Target $name missing from $project" }
        $common = $entry.TargetOption.TargetCommonOption
        $output = Join-Path $projectRoot ([string]$common.OutputDirectory)
        $listing = Join-Path $projectRoot ([string]$common.ListingPath)
        New-Item -ItemType Directory -Path $output, $listing -Force | Out-Null
        $log = Join-Path $output 'build.log'
        & $Keil $buildFlag $project -t $name -o $log -j0
        if ($LASTEXITCODE -ne 0) { throw "Keil build failed: $name, exit $LASTEXITCODE" }
        if (-not (Test-Path -LiteralPath $log)) { throw "Missing build log: $log" }
        if ((Get-Content -LiteralPath $log -Raw) -notmatch '0 Error\(s\)') {
            throw "Build success was not confirmed in $log"
        }
        if ($name -eq 'ControlPanel') {
            New-Item -ItemType Directory -Path 'Firmware' -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $output "$name.hex") -Destination "Firmware/$name.hex" -Force
        }
        Write-Host "Built $name; log: $log"
    }
} finally { Pop-Location }
