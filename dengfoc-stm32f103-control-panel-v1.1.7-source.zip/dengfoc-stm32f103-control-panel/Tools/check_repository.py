"""Source/document checks usable on GitHub runners without Keil or hardware."""
from pathlib import Path
import ast
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from urllib.parse import unquote

root = Path(__file__).resolve().parents[1]
errors = []

def fail(message):
    errors.append(message)

def files():
    try:
        output = subprocess.check_output(
            ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=root)
        return sorted({root/p for p in output.decode('utf-8').split('\0') if p})
    except subprocess.CalledProcessError:
        raise SystemExit('Run inside the prepared Git repository.')

paths = files()
for path in paths:
    relative = path.relative_to(root)
    if not path.is_file():
        fail(f'Missing file: {relative}')
        continue
    if path.stat().st_size >= 50*1024*1024:
        fail(f'Large repository file: {relative}')
    if path.suffix in ('.o', '.axf', '.hex', '.bin', '.pyc') or '.uvguix.' in path.name:
        fail(f'Generated artifact included: {relative}')
    if path.suffix.lower() in ('.jpg', '.jpeg'):
        data = path.read_bytes()
        # Location/device information can remain in EXIF or XMP even when invisible in the photo.
        if b'Exif\x00\x00' in data or b'http://ns.adobe.com/xap/' in data:
            fail(f'Photo metadata requires review: {relative}')
    if path.suffix.lower() not in ('.md','.py','.ps1','.c','.h','.s','.uvprojx','.uvoptx','.json','.jsonl','.txt','.log','.yml'):
        continue
    try:
        text = path.read_text(encoding='utf-8-sig')
    except UnicodeDecodeError:
        if relative.parts[0] == 'Drivers':
            # Legacy vendor comments may use an ANSI code page; keep original bytes.
            text = path.read_bytes().decode('latin-1')
        else:
            fail(f'Expected UTF-8 text: {relative}')
            continue
    # Scan the exact former machine roots, without exposing credential-like content in errors.
    if re.search(r'G:[\\/]lsp[\\/]|C:[\\/]Users[\\/]links[\\/]', text, re.I):
        fail(f'Personal machine path: {relative}')
    if re.search(r'\bgh[pousr]_[A-Za-z0-9]{30,}\b|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', text):
        fail(f'Potential credential: {relative}')
    if path.suffix == '.py':
        try:
            ast.parse(text,filename=str(relative))
        except SyntaxError as exc:
            fail(f'Python syntax: {relative}:{exc.lineno}')
    if path.suffix == '.md':
        # Links in fenced examples are not navigation targets.
        prose = re.sub(r'```.*?```','',text,flags=re.S)
        urls = re.findall(r'\]\(([^)]+)\)',prose)
        urls += re.findall(r'<img\b[^>]*\bsrc="([^"]+)"',prose)
        for url in urls:
            if re.match(r'https?://|mailto:|#',url):
                continue
            target = (path.parent/unquote(url.split('#',1)[0])).resolve()
            if not target.is_relative_to(root) or not target.exists():
                fail(f'Broken/outside link: {relative} -> {url}')

for project in sorted(root.glob('*.uvprojx')):
    tree = ET.parse(project)
    for target in tree.findall('Targets/Target'):
        entries = target.findall('Groups/Group/Files/File')
        names = [entry.findtext('FileName') for entry in entries]
        is_tests = target.findtext('TargetName') == 'CoreTests'
        if not is_tests and names.count('main.c') != 1:
            fail(f'Expected one main.c: {project.name}/{target.findtext("TargetName")}')
        for entry in entries:
            source = (root/entry.findtext('FilePath').replace('\\','/')).resolve()
            if not source.is_relative_to(root) or not source.is_file():
                fail(f'Missing/outside source: {project.name}: {entry.findtext("FilePath")}')
        include = target.findtext('TargetOption/TargetArmAds/Cads/VariousControls/IncludePath') or ''
        for directory in include.split(';'):
            if directory and not (root/directory.replace('\\','/')).is_dir():
                fail(f'Missing include directory: {project.name}: {directory}')

for options in root.glob('*.uvoptx'):
    if re.search(r'-U[0-9A-Fa-f]{8,}',options.read_text(encoding='utf-8')):
        fail(f'Bound debug probe: {options.name}')

# Generated course files must reflect current production modules, not a stale copy.
board = (root/'BSP/board.c').read_text(encoding='utf-8')
for lesson, signature, replacement, include in (
    ('02','static void gpio_init(void)','lesson02_gpio_init','lesson02_resources.h'),
    ('05','static void pwm_adc_init(void)','lesson05_timing_init','lesson05_timing.h')):
    start = board.rfind('/*',0,board.index(signature))
    next_signature = 'static void uart_init(void)' if lesson == '02' else 'void board_init(void)'
    end = board.rfind('/*',0,board.index(next_signature))
    expected = board[:start]+board[end:]
    old_call = '    gpio_init();' if lesson == '02' else '    pwm_adc_init();'
    expected = expected.replace(old_call,f'    {replacement}();',1)
    expected = expected.replace('#include "board.h"',f'#include "board.h"\n#include "{include}"',1)
    generated = root/f'Learning/Lesson{lesson}/board_lesson{lesson}.c'
    if not generated.read_text(encoding='utf-8').endswith(expected):
        fail(f'Stale generated board: {generated.relative_to(root)}')

console = (root/'App/console.c').read_text(encoding='utf-8')
console = console.replace('#include "console.h"','#include "console.h"\n#include "lesson03_commands.h"',1)
console = console.replace('    const char *cmd = args[0];',
                          '    if (lesson03_handle(args, count))\n        return;\n    const char *cmd = args[0];',1)
if not (root/'Learning/Lesson03/console_lesson03.c').read_text(encoding='utf-8').endswith(console):
    fail('Stale generated console for Lesson03')

motor = (root/'Control/motor.c').read_text(encoding='utf-8')
motor = motor.replace('#include "motor.h"','#include "motor.h"\n#include "lesson06_current.h"',1)
for phase in ('a','b'):
    old = f'    status.i{phase} = ((float){phase} - status.offset_{phase}) * amps_per_count * BOARD_CURRENT_{phase.upper()}_SIGN;'
    new = f'    status.i{phase} = lesson06_amps_from_adc({phase}, status.offset_{phase}, BOARD_CURRENT_{phase.upper()}_SIGN);'
    motor = motor.replace(old,new,1)
if not (root/'Learning/Lesson06/motor_lesson06.c').read_text(encoding='utf-8').endswith(motor):
    fail('Stale generated motor for Lesson06')

# These retained historical results are evidence, not results generated by this check.
for name in ('README.md','LICENSING.md','THIRD_PARTY_NOTICES.md','Docs/BUILD.md',
             'Docs/VALIDATION.md','Docs/RELEASE_PREPARATION.md'):
    if not (root/name).is_file():
        fail(f'Required documentation missing: {name}')

if errors:
    print('\n'.join(errors))
    raise SystemExit(1)
print(f'PASS: {len(paths)} source/evidence files; project references, relative links, Python syntax and hygiene.')
print('This check does not compile firmware or test physical hardware.')
