"""Generate independent learning projects with their actual teaching modules."""
from pathlib import Path
import copy
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
win = lambda p: '.' + chr(92) + p.replace('/', chr(92))
tree = ET.parse(root / 'ControlPanel.uvprojx')
targets = tree.find('Targets')
base = next(t for t in targets if t.findtext('TargetName') == 'ControlPanel')
targets.clear()

# Keep the production board implementation except its GPIO initialization.
source = (root / 'BSP/board.c').read_text(encoding='utf-8')
begin = source.rfind('/*', 0, source.index('static void gpio_init(void)'))
end = source.rfind('/*', 0, source.index('static void uart_init(void)'))
assert begin >= 0 and end > begin and source[begin:end].count('static void gpio_init') == 1
source = source[:begin] + source[end:]
assert source.count('    gpio_init();') == 1
source = source.replace('    gpio_init();', '    lesson02_gpio_init();', 1)
source = source.replace('#include "board.h"', '#include "board.h"\n#include "lesson02_resources.h"', 1)
(root / 'Learning/Lesson02/board_lesson02.c').write_text(
    '/* Generated from BSP/board.c; edit lesson02_resources.c for GPIO practice. */\n' + source,
    encoding='utf-8')

# Connect Lesson03 after the original tokenizer; keep original UART and command semantics.
console = (root / 'App/console.c').read_text(encoding='utf-8')
console = console.replace('#include "console.h"', '#include "console.h"\n#include "lesson03_commands.h"', 1)
hook = '    const char *cmd = args[0];'
assert console.count(hook) == 1
console = console.replace(hook, '    if (lesson03_handle(args, count))\n        return;\n' + hook, 1)
(root / 'Learning/Lesson03/console_lesson03.c').write_text(
    '/* Generated from App/console.c; edit lesson03_commands.c for command practice. */\n' + console,
    encoding='utf-8')

project_name = lambda number: 'ControlPanel_Learning' if number == 1 else f'ControlPanel_Lesson{number:02d}'
# Lesson05 supplies the actual timer/ADC initialization; retain all other board behavior.
board5 = (root / 'BSP/board.c').read_text(encoding='utf-8')
begin = board5.rfind('/*', 0, board5.index('static void pwm_adc_init(void)'))
end = board5.rfind('/*', 0, board5.index('void board_init(void)'))
assert begin >= 0 and end > begin
board5 = board5[:begin] + board5[end:]
assert board5.count('    pwm_adc_init();') == 1
board5 = board5.replace('    pwm_adc_init();', '    lesson05_timing_init();', 1)
board5 = board5.replace('#include "board.h"', '#include "board.h"\n#include "lesson05_timing.h"', 1)
(root / 'Learning/Lesson05/board_lesson05.c').write_text(
    '/* Generated from BSP/board.c; edit lesson05_timing.c for timer practice. */\n' + board5,
    encoding='utf-8')

# Lesson06 routes actual phase-current conversion through the learning module.
motor6 = (root / 'Control/motor.c').read_text(encoding='utf-8')
motor6 = motor6.replace('#include "motor.h"', '#include "motor.h"\n#include "lesson06_current.h"', 1)
for phase in ('a', 'b'):
    old = f'    status.i{phase} = ((float){phase} - status.offset_{phase}) * amps_per_count * BOARD_CURRENT_{phase.upper()}_SIGN;'
    new = f'    status.i{phase} = lesson06_amps_from_adc({phase}, status.offset_{phase}, BOARD_CURRENT_{phase.upper()}_SIGN);'
    assert motor6.count(old) == 1
    motor6 = motor6.replace(old, new, 1)
(root / 'Learning/Lesson06/motor_lesson06.c').write_text(
    '/* Generated from Control/motor.c; edit lesson06_current.c for current-conversion practice. */\n' + motor6,
    encoding='utf-8')

for number in (1, 2, 3, 4, 5, 6):
    folder = f'Lesson{number:02d}'
    name = folder + '_NoKnob'
    lesson = copy.deepcopy(base)
    targets.append(lesson)
    lesson.find('TargetName').text = name
    common = lesson.find('TargetOption/TargetCommonOption')
    common.find('OutputName').text = name
    common.find('OutputDirectory').text = win(f'Objects/{folder}/')
    common.find('ListingPath').text = win(f'Listings/{folder}/')
    lesson.find('TargetOption/TargetArmAds/Cads/VariousControls/Define').text = \
        'USE_STDPERIPH_DRIVER,STM32F10X_MD'
    entries = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'main.c']
    assert len(entries) == 1
    entries[0].find('FilePath').text = win(f'Learning/{folder}/main.c')
    if number == 2:
        boards = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'board.c']
        assert len(boards) == 1
        boards[0].find('FileName').text = 'board_lesson02.c'
        boards[0].find('FilePath').text = win('Learning/Lesson02/board_lesson02.c')
        group = ET.SubElement(lesson.find('Groups'), 'Group')
        ET.SubElement(group, 'GroupName').text = 'Lesson02 Resources'
        files = ET.SubElement(group, 'Files')
        entry = ET.SubElement(files, 'File')
        ET.SubElement(entry, 'FileName').text = 'lesson02_resources.c'
        ET.SubElement(entry, 'FileType').text = '1'
        ET.SubElement(entry, 'FilePath').text = win('Learning/Lesson02/lesson02_resources.c')
    if number == 3:
        consoles = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'console.c']
        assert len(consoles) == 1
        consoles[0].find('FileName').text = 'console_lesson03.c'
        consoles[0].find('FilePath').text = win('Learning/Lesson03/console_lesson03.c')
        group = ET.SubElement(lesson.find('Groups'), 'Group')
        ET.SubElement(group, 'GroupName').text = 'Lesson03 Commands'
        files = ET.SubElement(group, 'Files')
        entry = ET.SubElement(files, 'File')
        ET.SubElement(entry, 'FileName').text = 'lesson03_commands.c'
        ET.SubElement(entry, 'FileType').text = '1'
        ET.SubElement(entry, 'FilePath').text = win('Learning/Lesson03/lesson03_commands.c')
    if number == 4:
        sensors = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'as5600.c']
        assert len(sensors) == 1
        sensors[0].find('FileName').text = 'lesson04_sensor.c'
        sensors[0].find('FilePath').text = win('Learning/Lesson04/lesson04_sensor.c')
    if number == 5:
        boards = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'board.c']
        assert len(boards) == 1
        boards[0].find('FileName').text = 'board_lesson05.c'
        boards[0].find('FilePath').text = win('Learning/Lesson05/board_lesson05.c')
        group = ET.SubElement(lesson.find('Groups'), 'Group')
        ET.SubElement(group, 'GroupName').text = 'Lesson05 Timing'
        files = ET.SubElement(group, 'Files')
        entry = ET.SubElement(files, 'File')
        ET.SubElement(entry, 'FileName').text = 'lesson05_timing.c'
        ET.SubElement(entry, 'FileType').text = '1'
        ET.SubElement(entry, 'FilePath').text = win('Learning/Lesson05/lesson05_timing.c')
    if number == 6:
        motors = [f for f in lesson.findall('Groups/Group/Files/File') if f.findtext('FileName') == 'motor.c']
        assert len(motors) == 1
        motors[0].find('FileName').text = 'motor_lesson06.c'
        motors[0].find('FilePath').text = win('Learning/Lesson06/motor_lesson06.c')
        group = ET.SubElement(lesson.find('Groups'), 'Group')
        ET.SubElement(group, 'GroupName').text = 'Lesson06 Current'
        files = ET.SubElement(group, 'Files')
        entry = ET.SubElement(files, 'File')
        ET.SubElement(entry, 'FileName').text = 'lesson06_current.c'
        ET.SubElement(entry, 'FileType').text = '1'
        ET.SubElement(entry, 'FilePath').text = win('Learning/Lesson06/lesson06_current.c')
    for path in (f'Objects/{folder}', f'Listings/{folder}'):
        (root / path).mkdir(parents=True, exist_ok=True)
    # Different teaching entry/board paths use separate projects, avoiding uVision group merging.
    output = project_name(number)
    single = ET.ElementTree(copy.deepcopy(tree.getroot()))
    single_targets = single.find('Targets')
    single_targets.clear()
    single_targets.append(copy.deepcopy(lesson))
    ET.indent(single)
    single.write(root / (output + '.uvprojx'), encoding='UTF-8', xml_declaration=True)

options = ET.parse(root / 'ControlPanel.uvoptx')
opt_root = options.getroot()
base_options = next(t for t in opt_root.findall('Target') if t.findtext('TargetName') == 'ControlPanel')
for node in list(opt_root.findall('Target')):
    opt_root.remove(node)
for number in (1, 2, 3, 4, 5, 6):
    node = copy.deepcopy(base_options)
    node.find('TargetName').text = f'Lesson{number:02d}_NoKnob'
    single = ET.ElementTree(copy.deepcopy(opt_root))
    single.getroot().append(node)
    ET.indent(single)
    output = project_name(number)
    single.write(root / (output + '.uvoptx'), encoding='UTF-8', xml_declaration=True)
print('Generated independent Lesson01 through Lesson06 projects.')
