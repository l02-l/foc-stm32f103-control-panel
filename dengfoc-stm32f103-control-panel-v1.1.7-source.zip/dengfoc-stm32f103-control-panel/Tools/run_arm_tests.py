"""Run the real ARM ELF test functions with synthetic board inputs.
Requires: pip install unicorn pyelftools
Pass --deps PATH when using packages installed to a local directory.
"""
import sys,json,argparse
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--deps');args=parser.parse_args()
if args.deps: sys.path.insert(0,str(Path(args.deps).resolve()))
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_MODE_MCLASS
from unicorn.arm_const import UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_R0,UC_ARM_REG_PC
from elftools.elf.elffile import ELFFile

root=Path(__file__).resolve().parents[1]
with (root/'Tests/Build/CoreTests.axf').open('rb') as f:
    elf=ELFFile(f);sym={x.name:x['st_value'] for x in elf.get_section_by_name('.symtab').iter_symbols()}
    uc=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
    uc.mem_map(0x08000000,0x10000);uc.mem_map(0x20000000,0x10000);uc.mem_map(0x01000000,0x1000)
    for segment in elf.iter_segments():
        if segment['p_type']=='PT_LOAD' and segment['p_filesz']:
            uc.mem_write(segment['p_vaddr'],segment.data())
    uc.reg_write(UC_ARM_REG_SP,0x20004FF0);uc.reg_write(UC_ARM_REG_LR,0x01000001)
    uc.emu_start(sym['tests_run_all']|1,0x01000000,count=100000000)
    assert uc.reg_read(UC_ARM_REG_PC)==0x01000000,'Emulator did not return from the complete test suite'
    def u32(name): return int.from_bytes(uc.mem_read(sym[name],4),'little')
    checks=u32('test_checks');failures=u32('test_failures')
    lines=[int.from_bytes(uc.mem_read(sym['test_failed_lines']+4*i,4),'little') for i in range(min(failures,64))]
    result={'engine':'Unicorn ARM Cortex-M emulation; actual Keil-compiled C',
        'checks':checks,'failures':failures,'failed_lines':lines,
        'limitations':'Synthetic ADC/encoder inputs; no physical timing, I2C bus, OLED or motor verification.'}
    (root/'Tests/results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
    if failures or uc.reg_read(UC_ARM_REG_R0)!=0 or not checks: raise SystemExit(1)
