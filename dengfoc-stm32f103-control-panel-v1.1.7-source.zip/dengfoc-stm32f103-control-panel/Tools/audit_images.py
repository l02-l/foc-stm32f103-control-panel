"""Check the delivered ARM images' real vector tables and memory placement."""
import sys,json,argparse,hashlib
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--deps');args=parser.parse_args()
if args.deps: sys.path.insert(0,str(Path(args.deps).resolve()))
from elftools.elf.elffile import ELFFile
root=Path(__file__).resolve().parents[1]
reports=[]
for folder,name in [('Bench','ControlPanel')]:
    with (root/f'Objects/{folder}/{name}.axf').open('rb') as stream:
        elf=ELFFile(stream);symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
        flash_end=0x08000000;ram_end=0x20000000
        vectors=None
        for segment in elf.iter_segments():
            if segment['p_type']!='PT_LOAD': continue
            va,pa,size=segment['p_vaddr'],segment['p_paddr'],segment['p_filesz']
            if 0x08000000<=pa<0x08100000: flash_end=max(flash_end,pa+size)
            if 0x20000000<=va<0x20010000: ram_end=max(ram_end,va+segment['p_memsz'])
            if va==0x08000000: vectors=segment.data()
        assert flash_end<=0x0800FC00,(name,'overlaps settings page',hex(flash_end))
        # ArmLink may combine scattered RO/RW regions into a single PT_LOAD.
        for section in elf.iter_sections():
            va=section['sh_addr']
            if section['sh_flags']&2 and 0x20000000<=va<0x20010000:
                ram_end=max(ram_end,va+section['sh_size'])
        assert ram_end<=0x20005000,(name,'exceeds SRAM')
        assert vectors is not None
        for irq,handler in [(-2,'PendSV_Handler'),(18,'ADC1_2_IRQHandler'),(29,'TIM3_IRQHandler'),(30,'TIM4_IRQHandler'),(37,'USART1_IRQHandler')]:
            entry=int.from_bytes(vectors[(16+irq)*4:(17+irq)*4],'little')
            assert (entry&~1)==(symbols[handler]&~1),(name,'wrong interrupt vector',handler)
        hexpath=root/f'Firmware/{name}.hex';digest=hashlib.sha256(hexpath.read_bytes()).hexdigest()
        reports.append({'target':name,'flash_load_bytes':flash_end-0x08000000,
            'ram_end':hex(ram_end),'ram_bytes':ram_end-0x20000000,'settings_page':'0x0800FC00, reserved 1 KB',
            'interrupt_vectors':'PendSV/ADC1_2/TIM3/TIM4/USART1 verified','hex_sha256':digest})
(root/'Tests/image_audit.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
print(json.dumps(reports,indent=2))
