from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
tree=ET.parse(root/'ControlPanel.uvprojx');t=tree.find('./Targets/Target');t.find('TargetName').text='CoreTests'
t.find('TargetOption/TargetCommonOption/OutputName').text='CoreTests'
t.find('TargetOption/TargetCommonOption/CreateHexFile').text='0'
t.find('TargetOption/TargetCommonOption/OutputDirectory').text='.\\Tests\\Build\\'
t.find('TargetOption/TargetCommonOption/ListingPath').text='.\\Tests\\Build\\'
t.find('TargetOption/TargetArmAds/Cads/VariousControls/Define').text='USE_STDPERIPH_DRIVER,STM32F10X_MD'
(root/'Tests/Build').mkdir(parents=True,exist_ok=True)
for extra in list(tree.find('Targets'))[1:]: tree.find('Targets').remove(extra)
groups=t.find('Groups');groups.clear()
for name,files in {'Startup':['Drivers/CMSIS/startup_stm32f10x_md.s','Drivers/CMSIS/system_stm32f10x.c'],
    'Tests':['Tests/core_tests.c','Control/control_math.c','Control/params.c','Control/nec_decoder.c','Control/motor.c','BSP/as5600.c','App/console.c']}.items():
    g=ET.SubElement(groups,'Group');ET.SubElement(g,'GroupName').text=name;fs=ET.SubElement(g,'Files')
    for path in files:
        f=ET.SubElement(fs,'File');ET.SubElement(f,'FileName').text=Path(path).name
        ET.SubElement(f,'FileType').text='2' if path.endswith('.s') else '1'
        ET.SubElement(f,'FilePath').text='.\\'+path.replace('/','\\')
ET.indent(tree);tree.write(root/'CoreTests.uvprojx',encoding='UTF-8',xml_declaration=True)
