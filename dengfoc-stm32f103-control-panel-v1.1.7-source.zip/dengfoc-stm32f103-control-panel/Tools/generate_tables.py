from pathlib import Path
import math
dst=Path(__file__).resolve().parents[1]/'Control/sine_table.h'
values=[f'{math.sin(math.pi*i/512):.10f}f' for i in range(257)]
dst.write_text('/* 自动生成的四分之一正弦表：257 个采样点，配合象限映射和线性插值使用。 */\nstatic const float sine_quarter[257] = {\n'+
    '\n'.join('    '+', '.join(values[i:i+8])+',' for i in range(0,257,8))+'\n};\n',encoding='utf-8')
print(dst)
