"""Package tracked source files, never .git or local build outputs."""
from pathlib import Path
import hashlib, re, subprocess, zipfile
root=Path(__file__).resolve().parents[1]
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode('utf-8').split('\0')
paths=[p for p in paths if p]
if not paths:
    raise SystemExit('Stage prepared source files with git add before packaging.')
version=re.search(r'#define\s+APP_VERSION\s+"([^"]+)"',(root/'Config/app_config.h').read_text(encoding='utf-8')).group(1)
output=root/'dist'/f'dengfoc-stm32f103-control-panel-v{version}-source.zip'
output.parent.mkdir(exist_ok=True)
manifest=[]
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for relative in sorted(paths):
        path=root/relative
        if not path.is_file(): raise SystemExit(f'Tracked file missing: {relative}')
        data=path.read_bytes()
        archive.writestr(root.name+'/'+relative,data)
        manifest.append(hashlib.sha256(data).hexdigest()+'  '+relative)
    archive.writestr(root.name+'/MANIFEST.sha256','\n'.join(manifest)+'\n')
print(f'{output}: {len(paths)} tracked files + checksum manifest')
