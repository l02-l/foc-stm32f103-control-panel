/*
 * 程序入口：先初始化硬件和参数，再启动控制中断，最后在主循环处理界面。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
/* 学习入口：中断执行控制计算，主循环执行显示与交互。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"

/* ADC 发布采样，PendSV 执行电流控制，TIM4 执行读角/外环；主循环负责界面与命令。 */
int main(void)
{
    AppParams params;
    board_init();                            /* 先关闭 PA8，再配置两路功率桥的输入状态 */
    uint8_t loaded = settings_load(&params); /* 参数页空白或校验失败时使用默认值 */
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");
    board_start_control(); /* 启动 ADC、电流和角度任务，保持驱动停机 */
    ui_init();
    board_watchdog_start();
    uint32_t watchdog_ms = 0u, last_samples = 0u, last_steps = 0u;
    while (1)
    {
        console_poll();  /* 解析接收命令；每 100 ms 组织一帧状态输出 */
        ui_poll();       /* 处理遥控事件，并发送一小段 OLED 显存 */
        uint32_t now = board_millis();
        if ((uint32_t)(now - watchdog_ms) >= 100u)
        {
            watchdog_ms = now;
            MotorStatus s;
            motor_snapshot(&s);
            /* 不仅检查主循环能运行，还要检查采样和电流任务计数持续增加，才喂狗。 */
            if (s.sensor_samples != last_samples && s.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = s.sensor_samples;
            last_steps = s.current_steps;
        }
    }
}
