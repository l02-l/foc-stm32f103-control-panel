/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef UI_PANEL_H
#define UI_PANEL_H
void ui_init(void);
void ui_poll(void);
#endif
