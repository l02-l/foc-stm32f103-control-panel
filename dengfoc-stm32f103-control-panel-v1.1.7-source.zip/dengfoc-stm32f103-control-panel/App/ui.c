/*
 * 人机界面：处理遥控按键、菜单页面和参数编辑；画面低频刷新。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "ui.h"
#include "motor.h"
#include "oled.h"
#include "ir_receiver.h"
#include "console.h"
#include "settings.h"
#include "app_config.h"
#include "board.h"
#include <stdio.h>
#include <string.h>
static uint8_t page, selection;
static char note[22];
static uint32_t note_ms;
/* 保存一条短提示，同时输出到串口；OLED 底部临时显示这条提示。 */
static void notify(const char *text)
{
    snprintf(note, sizeof(note), "%s", text);
    note_ms = board_millis();
    console_message(text);
    console_message("\r\n");
}
/* 把接口的成功/失败结果转换为界面提示。 */
static void notify_result(uint8_t ok)
{
    notify(ok ? "OK" : "REJECTED: CHECK STATE");
}
/* 按参数选择屏幕控制器并显示启动状态；屏幕缺失时仍可通过串口操作。 */
void ui_init(void)
{
    AppParams p;
    motor_get_params(&p);
    (void)oled_init((uint8_t)p.oled_sh1106);
    notify("BOOT STOPPED");
}
/* direction 为 +1 或 -1。监视页修改目标值，PID/限值页修改当前选中的参数。 */
static void adjust(int direction)
{
    AppParams p;
    motor_get_params(&p);
    MotorStatus s;
    motor_snapshot(&s);
    if (page == 0u)
    {
        if (s.mode == MODE_SPEED)
            motor_set_speed(s.speed_target_rpm + 5.0f * (float)direction);
        else if (s.mode == MODE_POSITION)
            motor_set_position(s.position_target_rad + 5.0f * APP_PI / 180.0f * (float)direction);
        else
            motor_set_current(s.current_target + 0.01f * (float)direction);
        return;
    }
    if (page <= 3u)
    {
        PidGains *g = page == 1u ? &p.current_pid : page == 2u ? &p.speed_pid : &p.position_pid;
        float steps[3] = {page == 2u ? 0.001f : 0.1f, page == 1u ? 5.0f : 0.01f, 0.0001f};
        float *value = selection == 0u ? &g->kp : selection == 1u ? &g->ki : &g->kd;
        *value = cm_clamp(*value + steps[selection] * (float)direction, 0.0f,
                          selection == 0u   ? 100.0f
                          : selection == 1u ? 2000.0f
                                            : 1.0f);
    }
    else
    {
        float *value = selection == 0u   ? &p.voltage_limit
                       : selection == 1u ? &p.current_limit
                       : selection == 2u ? &p.trip_current
                                         : &p.speed_limit_rpm;
        const float steps[] = {0.1f, 0.01f, 0.05f, 5.0f};
        *value += steps[selection] * (float)direction;
        if (p.calibration_voltage > p.voltage_limit)
            p.calibration_voltage = p.voltage_limit;
    }
    notify_result(motor_apply_params(&p));
}
/* 处理一个已映射的按键事件；模式切换会先停机，星号键在所有页面都请求停机。 */
static void on_key(RemoteKey key)
{
    MotorStatus s;
    motor_snapshot(&s);
    AppParams p;
    motor_get_params(&p);
    if (key == KEY_STAR)
    {
        motor_stop();
        notify("STOP");
        return;
    }
    if (key == KEY_OK)
    {
        if (s.state == MOTOR_RUNNING || s.state == MOTOR_CALIBRATING)
        {
            motor_stop();
            notify("STOP");
        }
        else
            notify_result(motor_start());
        return;
    }
    if (key == KEY_HASH)
    {
        notify_result(motor_calibrate());
        return;
    }
    if (key == KEY_1 || key == KEY_2 || key == KEY_3)
    {
        notify_result(motor_set_mode((ControlMode)(key - KEY_1)));
        return;
    }
    if (key == KEY_0)
    {
        page = (page + 1u) % 5u;
        selection = 0u;
        return;
    }
    if (key == KEY_4)
    {
        motor_reverse_target();
        return;
    }
    if (key == KEY_6)
    {
        notify_result(settings_save(&p));
        return;
    }
    if (key == KEY_7)
    {
        notify_result(motor_clear_fault());
        return;
    }
    if (key == KEY_8)
    {
        if (s.state == MOTOR_STOPPED)
        {
            motor_zero_position();
            notify("POSITION ZERO");
        }
        else
            notify("STOP FIRST");
        return;
    }
    if (key == KEY_9)
    {
        motor_stop();
        params_defaults(&p);
        notify_result(motor_apply_params(&p));
        return;
    }
    if (key == KEY_LEFT || key == KEY_RIGHT)
    {
        adjust(key == KEY_LEFT ? -1 : 1);
        return;
    }
    if (key == KEY_UP || key == KEY_DOWN)
    {
        if (page == 0u)
            adjust(key == KEY_UP ? 1 : -1);
        else
        {
            uint8_t count = page == 4u ? 4u : 3u;
            selection = (uint8_t)((selection + (key == KEY_UP ? count - 1u : 1u)) % count);
        }
    }
}
/* 根据当前页面生成 128×64 画面。这里只改显存，真正发送由 oled_poll 分块完成。 */
static void render(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    AppParams p;
    motor_get_params(&p);
    char line[48];
    oled_clear();
    snprintf(line, sizeof(line), "%s %s", motor_mode_name(s.mode), motor_state_name(s.state));
    oled_text(0u, line);
    if (page == 0u)
    {
        snprintf(line, sizeof(line), "RPM %ld REF %ld", (long)s.speed_rpm,
                 (long)s.speed_target_rpm);
        oled_text(1u, line);
        snprintf(line, sizeof(line), "DEG %ld REF %ld", (long)(s.position_rad * 180.0f / APP_PI),
                 (long)(s.position_target_rad * 180.0f / APP_PI));
        oled_text(2u, line);
        snprintf(line, sizeof(line), "IQ %ld ID %ld MA", (long)(s.iq * 1000.0f),
                 (long)(s.id * 1000.0f));
        oled_text(3u, line);
        snprintf(line, sizeof(line), "AS5600 RAW %u", (unsigned)s.raw);
        oled_text(4u, line);
        snprintf(line, sizeof(line), "CAL %u MAG %u OFF %u", (unsigned)s.calibrated,
                 (unsigned)s.magnet_ok, (unsigned)s.offsets_ready);
        oled_text(5u, line);
        snprintf(line, sizeof(line), "F:%s", motor_fault_name(s.fault));
        oled_text(6u, line);
    }
    else if (page <= 3u)
    {
        const PidGains *g = page == 1u   ? &p.current_pid
                            : page == 2u ? &p.speed_pid
                                         : &p.position_pid;
        oled_text(1u, page == 1u ? "CURRENT PID" : page == 2u ? "SPEED PID" : "POSITION PID");
        const float values[] = {g->kp, g->ki, g->kd};
        const char *names[] = {"KP", "KI", "KD"};
        for (uint8_t i = 0; i < 3u; i++)
        {
            /* 把参数乘 10000 后拆成整数和小数，显示四位小数，避免 printf 浮点格式开销。 */
            long v = (long)(values[i] * 10000.0f + 0.5f);
            snprintf(line, sizeof(line), "%c%s %ld.%04ld", selection == i ? '>' : ' ', names[i],
                     v / 10000L, v % 10000L);
            oled_text(i + 2u, line);
        }
        oled_text(5u, "UP/DOWN SELECT");
        oled_text(6u, "LEFT/RIGHT CHANGE");
    }
    else
    {
        oled_text(1u, "LIMITS");
        const char *names[] = {"V MAX MV", "I MAX MA", "TRIP MA", "RPM MAX"};
        const float values[] = {p.voltage_limit * 1000.0f, p.current_limit * 1000.0f,
                                p.trip_current * 1000.0f, p.speed_limit_rpm};
        for (uint8_t i = 0; i < 4u; i++)
        {
            snprintf(line, sizeof(line), "%c%s %ld", selection == i ? '>' : ' ', names[i],
                     (long)values[i]);
            oled_text(i + 2u, line);
        }
        oled_text(6u, "SOURCE IR/SERIAL");
    }
    if ((uint32_t)(board_millis() - note_ms) < 2000u)
        oled_text(7u, note);
    else
        oled_text(7u, page ? "0 PAGE 6 SAVE * STOP" : "* STOP OK RUN # CAL");
    oled_present();
}
/* 读取红外队列、限制长按重复动作，并以 5 Hz 更新画面；每次只发送一个小数据块。 */
void ui_poll(void)
{
    IrEvent event;
    static uint32_t last_press, last_repeat;
    static uint8_t have_press, last_command;
    while (ir_receiver_pop(&event))
    {
        uint32_t now = board_millis();
        if (event.repeat)
        {
            if (!have_press || (uint32_t)(now - last_press) > 250u ||
                (uint32_t)(now - last_repeat) < 100u)
                continue;
            event.command = last_command;
            last_repeat = now;
            last_press = now;
        }
        else
        {
            last_press = now;
            last_repeat = now;
            last_command = event.command;
            have_press = 1u;
            char text[48];
            snprintf(text, sizeof(text), "IR addr=%04X cmd=%02X\r\n", event.address, event.command);
            console_message(text);
        }
        AppParams p;
        motor_get_params(&p);
        for (unsigned key = 0; key < KEY_COUNT; key++)
            if (p.ir_codes[key] == event.command)
            {
                if (!event.repeat || key == KEY_UP || key == KEY_DOWN || key == KEY_LEFT ||
                    key == KEY_RIGHT)
                    on_key((RemoteKey)key);
                break;
            }
    }
    static uint32_t frame_ms, retry_ms;
    uint32_t now = board_millis();
    if (!oled_available() && (uint32_t)(now - retry_ms) >= 3000u)
    {
        retry_ms = now;
        AppParams p;
        motor_get_params(&p);
        (void)oled_init((uint8_t)p.oled_sh1106);
    }
    if (oled_available() && !oled_busy() && (uint32_t)(now - frame_ms) >= 200u)
    {
        frame_ms = now;
        render();
    }
    oled_poll();
}
