/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef SETTINGS_PANEL_H
#define SETTINGS_PANEL_H
#include "params.h"
uint8_t settings_load(AppParams *p);
uint8_t settings_save(const AppParams *p);
#endif
