/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef CONSOLE_PANEL_H
#define CONSOLE_PANEL_H
#include <stdint.h>
void console_init(void);
void console_poll(void);
void console_status(void);
void console_message(const char *text);
#endif
