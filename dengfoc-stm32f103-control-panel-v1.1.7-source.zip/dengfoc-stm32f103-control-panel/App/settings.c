/*
 * 参数存储：使用 STM32 内部 Flash 最后一页保存参数，CRC32 检查数据完整性。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "settings.h"
#include "board.h"
#include "motor.h"
#include "app_config.h"
#include <stddef.h>
#include <string.h>
typedef struct
{
    uint32_t magic, version, length;
    AppParams params;
    uint32_t crc;
} SettingsRecord;
#define SETTINGS_MAGIC 0x44464F43u
/* 检查 Flash 记录的标识、版本、长度、CRC 和参数范围；任一失败则载入默认值并返回 0。 */
uint8_t settings_load(AppParams *p)
{
    const SettingsRecord *record = (const SettingsRecord *)BOARD_SETTINGS_ADDRESS;
    if (record->magic != SETTINGS_MAGIC || record->version != 1u ||
        record->length != sizeof(AppParams) ||
        record->crc != cm_crc32(record, offsetof(SettingsRecord, crc)) ||
        !params_valid(&record->params))
    {
        params_defaults(p);
        return 0u;
    }
    *p = record->params;
    /* 先按原始记录校验 CRC，再清除旧版旋钮输入标记。 */
    p->reserved_input = 0u;
    return 1u;
}
/* 仅在停机/故障状态保存参数。先擦除最后 1 KB 页，再逐字写入，最后读回核对。 */
uint8_t settings_save(const AppParams *p)
{
    MotorStatus st;
    motor_snapshot(&st);
    if (!params_valid(p) || (st.state != MOTOR_STOPPED && st.state != MOTOR_FAULT))
        return 0u;
    SettingsRecord record;
    memset(&record, 0, sizeof(record));
    record.magic = SETTINGS_MAGIC;
    record.version = 1u;
    record.length = sizeof(AppParams);
    record.params = *p;
    record.params.reserved_input = 0u;
    record.crc = cm_crc32(&record, offsetof(SettingsRecord, crc));
    uint32_t key = board_lock();
    board_gate(0u);
    FLASH_Unlock();
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
    FLASH_Status result = FLASH_ErasePage(BOARD_SETTINGS_ADDRESS);
    const uint32_t *words = (const uint32_t *)&record;
    for (uint32_t i = 0; i < sizeof(record) / 4u && result == FLASH_COMPLETE; i++)
        result = FLASH_ProgramWord(BOARD_SETTINGS_ADDRESS + 4u * i, words[i]);
    FLASH_Lock();
    board_unlock(key);
    return result == FLASH_COMPLETE &&
           memcmp((const void *)BOARD_SETTINGS_ADDRESS, &record, sizeof(record)) == 0;
}
