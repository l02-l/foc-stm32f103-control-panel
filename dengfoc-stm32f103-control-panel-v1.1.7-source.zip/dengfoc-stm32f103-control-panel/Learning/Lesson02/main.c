/*
 * 第二课入口：复用正式控制与交互模块，使用本课 GPIO 初始化并打印时钟配置。
 * Target：Lesson02_NoKnob。board_init 的 GPIO 调用由生成的 board_lesson02.c 接入。
 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "lesson02_resources.h"

int main(void)
{
    AppParams params;
    uint32_t last_check_ms, last_samples = 0u, last_steps = 0u;

    board_init(); /* 实际调用 lesson02_gpio_init；其他板级逻辑复用正式实现 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson02 v1.1.7: clocks and GPIO\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");

    /* 此时 ADC 分频、GPIO、串口已经配置，控制 TIM2/TIM4 尚未启动。 */
    lesson02_print_clocks();
    board_start_control();
    ui_init();
    board_watchdog_start();
    last_check_ms = board_millis();

    while (1)
    {
        console_poll();
        ui_poll();

        /* 沿用第一课的任务存活检查；本课不改变控制周期。 */
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus snapshot;
            last_check_ms = now;
            motor_snapshot(&snapshot);
            if (snapshot.sensor_samples != last_samples && snapshot.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = snapshot.sensor_samples;
            last_steps = snapshot.current_steps;
        }
    }
}
