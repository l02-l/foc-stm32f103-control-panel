# 第二课：STM32 时钟树、GPIO 与板级资源

日期：2026-11-02。基线：**v1.1.7，无旋钮，标准外设库，STM32F103C8T6 + V3P**。

建议 8～10 小时：时钟树 3 小时、GPIO 与 C 语法 3 小时、读写代码和练习 2～4 小时。

## 0. 本课学习目标与材料

第一课知道了 main 如何组织模块。这一课进入 `board_init()`，弄清每一个外设开始工作前，需要什么时钟、什么引脚模式。

完成后，你应能：

1. 从 8 MHz 外部晶振推导出 SYSCLK/HCLK/PCLK1/PCLK2 和定时器时钟。
2. 用实际 PSC/ARR 算出 15 kHz PWM、1 kHz 采样节拍。
3. 解释推挽、开漏、复用输出、模拟输入和上拉输入的区别。
4. 从零写出 PA8 与三路 PWM/电流反馈引脚的标准库配置。
5. 分清配置寄存器读回、软件频率推算和真实电压/频率测量。

| 文件 | 作用 |
| --- | --- |
| [正式 BSP/board.c](../../BSP/board.c) | 本课对照的实际板级实现 |
| [system_stm32f10x.c](../../Drivers/CMSIS/system_stm32f10x.c) | SystemInit 和 SetSysClockTo72 |
| [lesson02_resources.c](lesson02_resources.c) / [头文件](lesson02_resources.h) | 本课亲手学习的 GPIO 实现与时钟信息输出 |
| [main.c](main.c) | 使用本课板级实现的完整入口 |
| [board_lesson02.c](board_lesson02.c) | 自动生成的板级连接文件，其余逻辑沿用正式 board.c |
| [ControlPanel_Lesson02.uvprojx](../../ControlPanel_Lesson02.uvprojx) | 本课独立工程，选择 Lesson02_NoKnob |
| [build.log](build.log) | 本机编译结果：0 Error(s)、0 Warning(s) |

本课代码已编译，尚未烧录、未产生新的硬件测量结果。所有“预期输出”均按现有配置推算。正式控制台仍有独立工程与固件。

## 1. 电路基础：时钟之前先认清电源与地

这套系统同时出现 12 V、5 V、3.3 V，它们有不同用途：12 V 用于功率级母线，USB 提供 5 V，核心板稳压后的 MCU 逻辑通常以 3.3 V 为参考。GPIO 输出高电平不会因为 PWM 使用 12 V 母线而变成 12 V。

“PA8 输出 0”是相对公共 GND 的低电平指令，不表示没有地线，也不表示单凭这一项已经检查了整个功率桥。先有公共电位参考，传感器、驱动和 MCU 的数字信号才有明确含义。

电机相线接功率级，AS5600/OLED 信号接逻辑接口。学习 GPIO 配置时要沿原理图和引脚表辨认信号，不能把三相输出当普通 GPIO 接口。

## 2. 时钟是什么？72 MHz 表示什么？

时钟给数字电路提供重复的节拍。72 MHz 意味着每秒 7200 万个时钟周期，一个周期约 13.89 ns。

它不是“每秒执行 7200 万行 C 代码”。不同指令、Flash 访问、浮点软件运算和中断都会消耗不同的周期数。

### 2.1 HSI、HSE 与 PLL

| 名称 | 本项目含义 | 在哪里找 |
| --- | --- | --- |
| HSI | 芯片内部高速 RC 时钟，复位时默认来源 | CMSIS 头文件、时钟初始化 |
| HSE | 外部高速时钟，本板按 8 MHz 晶振配置 | HSE_VALUE、SetSysClockTo72 |
| PLL | 将输入时钟按配置倍频 | HSE × 9，得到 72 MHz |

实际配置过程是：打开 HSE→等待稳定→配置分频与 PLL→等待 PLL 稳定→把系统时钟切到 PLL。

`#define BOARD_CPU_HZ 72000000u` 是软件常量，不能独自改变硬件时钟。Keil 工程中的 8 MHz 晶振字段也不等于 CPU 最终主频只有 8 MHz。

### 2.2 本项目的时钟树

```mermaid
flowchart TD
    HSE[HSE 8 MHz] --> PLL[PLL ×9]
    PLL --> SYS[SYSCLK 72 MHz]
    SYS --> AHB[AHB ÷1 → HCLK 72 MHz]
    AHB --> CORE[CPU / DWT]
    AHB --> ST[SysTick 内核时钟 / 72000 → 1 ms]
    AHB --> APB1[APB1 ÷2 → PCLK1 36 MHz]
    APB1 --> TIM[定时器路径 ×2 → TIM2/3/4 72 MHz]
    AHB --> APB2[APB2 ÷1 → PCLK2 72 MHz]
    APB2 --> GPIO[GPIO / AFIO / USART1 接口]
    APB2 --> ADC[ADC ÷6 → ADCCLK 12 MHz]
```

SYSCLK 是系统时钟源；HCLK 是 AHB/内核相关时钟；PCLK1/PCLK2 是两条 APB 总线时钟。GPIOA、TIM2 和 USART1 不能仅凭名字猜属于哪条总线。

### 2.3 为什么 PCLK1 不能直接设成 72 MHz？

STM32F103x8/xB 的 APB1 最高为 36 MHz，APB2 最高为 72 MHz，所以本工程将 APB1 设为 HCLK/2。这是该系列的规格限制。见 [ST 官方数据手册：时钟树与工作条件](https://www.st.com/resource/en/datasheet/stm32f103c8.pdf)。

### 2.4 为什么定时器又是 72 MHz？

STM32F103 的规则为：

```text
APB 预分频 = 1：TIMCLK = PCLK
APB 预分频 > 1：TIMCLK = 2 × PCLK
```

这是定时器时钟路径的规则，不是给 UART、GPIO、ADC 全部乘 2。[ST RM0008：RCC 时钟章节](https://www.st.com/resource/en/reference_manual/rm0008-stm32f103xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)

| HCLK | APB1 分频 | PCLK1 | TIM2/3/4 时钟 |
| ---: | ---: | ---: | ---: |
| 72 MHz | 2 | 36 MHz | 72 MHz |
| 72 MHz | 4 | 18 MHz | 36 MHz |
| 假设 36 MHz | 1 | 36 MHz | 36 MHz |

第二行不是 18×4。即使 APB 分频为 4，定时器路径仍按规则乘 2。

## 3. 回到真实源码，逐项核对时钟

### 3.1 SystemInit 负责建立系统时钟

普通 Target 定义了 STM32F10X_MD，使用非 Value Line 的 72 MHz 分支。源文件里虽然也能搜到 24 MHz 宏，但它在另一条件编译分支，不代表当前生效。

在 SetSysClockTo72 中找这几项：

```c
RCC_CFGR_HPRE_DIV1       /* AHB 不分频 */
RCC_CFGR_PPRE2_DIV1      /* APB2 不分频 */
RCC_CFGR_PPRE1_DIV2      /* APB1 二分频 */
RCC_CFGR_PLLSRC_HSE      /* PLL 输入来自 HSE */
RCC_CFGR_PLLMULL9        /* PLL 倍频 9 */
```

原厂文件中 APB1 一处注释仍写着 `PCLK1 = HCLK`，下一行实际使用 `PPRE1_DIV2`。此处按实际配置宏理解为 HCLK/2。读代码要同时核对条件编译、调用与配置值。

系统时钟提高后，Flash 访问也要匹配等待周期。原文件配置了 2 个等待周期及预取；本课理解“主频改变会影响相关配置”，不用重新写 PLL 初始化。

### 3.2 board_init 配置项目资源

```c
NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
gpio_init();
/* 开启 DWT 周期计数。 */
SystemCoreClockUpdate();
SysTick_Config(SystemCoreClock / 1000u);
uart_init();
pwm_adc_init();
```

- SystemCoreClockUpdate 读取配置并刷新软件变量，不重新配置 PLL。
- SysTick_Config 使用这里的内核时钟源，72000000/1000=72000 个计数构成约 1 ms。
- RCC_ADCCLKConfig(RCC_PCLK2_Div6) 在 pwm_adc_init 中把 ADC 时钟设为 72/6=12 MHz。
- GPIO、USART 与定时器的外设时钟门控在各配置函数里打开。

为什么 ADC 不直接用 72 MHz？该芯片 ADC 时钟上限为 14 MHz，72/4=18 MHz 超过上限，72/6=12 MHz 则在范围内。这也是本项目选六分频的原因。见 [ST 数据手册 ADC characteristics](https://www.st.com/resource/en/datasheet/stm32f103c8.pdf)。

### 3.3 四种“时钟信息”不要混为一谈

| 信息 | 怎么得到 | 能证明什么 |
| --- | --- | --- |
| BOARD_CPU_HZ | 编译常量 | 程序的设计假设 |
| SystemCoreClock | 根据配置更新的软件变量 | 软件认为当前 HCLK 是多少 |
| RCC_GetClocksFreq | 按 RCC 寄存器与 HSE_VALUE/HSI_VALUE 计算 | 当前配置对应的频率 |
| 外部测频 | 示波器/频率计测信号 | 被测信号真实频率 |

前三者不会自动测出外部晶振的真实频率。如果 HSE_VALUE 与硬件不符，计算报告也可能不符。仅把 SystemCoreClock 赋成 72000000 不能让硬件从 8 MHz 变成 72 MHz。

## 4. 用时钟计算现有工程的时间尺度

对于本项目的向上计数定时器：

```text
计数频率 = TIMCLK / (PSC + 1)
更新频率 = TIMCLK / ((PSC + 1) × (ARR + 1))
周期     = 1 / 更新频率
```

PSC 的寄存器值对应分频系数减 1；计数器从 0 数到 ARR，一个完整周期包含 ARR+1 个计数。

| 资源 | 配置 | 结果 |
| --- | --- | --- |
| TIM2 PWM | TIMCLK=72 MHz，PSC=0，ARR=4799 | 15 kHz，约 66.7 μs |
| TIM3 红外时间戳 | TIMCLK=72 MHz，PSC=71，ARR=65535 | 1 μs/计数，65.536 ms 回绕 |
| TIM4 角度任务 | TIMCLK=72 MHz，PSC=71，ARR=999 | 1 ms 更新一次 |
| ADC | PCLK2/6 | 12 MHz，不是采样频率 12 MHz |
| DWT | 当前内核时钟 72 MHz | 72 个周期约 1 μs，32 位计数约 59.65 s 回绕 |

ADC 的转换耗时还包括采样与转换所需周期。本项目每个 PWM 周期触发一组两相顺序采样，不能把 ADC 工作时钟直接当作每秒采样组数。

电流控制每 5 组 ADC 数据调度一次，所以是 3 kHz；这属于软件分频，GPIO 的速度等级不参与这项计算。

## 5. GPIO 的四个问题

配置一个引脚时，先回答：**哪个端口、哪一位、谁控制输出、需要什么电气方式？**

### 5.1 推挽输出 Out_PP

输出 1 时主动拉高，输出 0 时主动拉低。PA8 使能脚使用普通推挽，由 GPIO_SetBits/ResetBits 控制。

“推挽”描述输出电路；“普通”表示输出数据由 GPIO 路径控制。

### 5.2 开漏输出 Out_OD

写 0 时拉低；写 1 时释放线路，高电平由上拉电阻形成。它能让 I²C 主机与从机在同一根线上轮流拉低，包括从机发送 ACK。

本项目 AS5600 与 OLED 都使用软件 I²C，因此引脚是普通开漏 Out_OD，软件逐位操作线路；不是因为 PB6/PB7 恰好也是硬件 I²C 引脚就必须选 AF_OD。

### 5.3 复用推挽 AF_PP

电气上仍是推挽，输出数据交给定时器、串口等外设。PA0/1/2 用于 TIM2 PWM，PA9 用于 USART1 TX。

STM32F1 使用固定映射/重映射规则。本项目 PA0/1/2 使用 TIM2 默认映射；需要重映射时还要配置 AFIO，不能只改 GPIO_Mode。

### 5.4 模拟输入 AIN、浮空输入和上拉输入

| 模式 | 本项目用途 | 关键含义 |
| --- | --- | --- |
| AIN | PB0/PB1 电流反馈 | 给 ADC 模拟路径使用，不由 GPIO 驱动输出 |
| IN_FLOATING | PA10，串口 RX | 输入端不由本配置启用内部上拉/下拉；正常由发送端驱动 |
| IPU | PB4，红外接收输入 | 启用内部上拉，输入空闲参考为高 |

浮空输入不表示运行时可以没有信号驱动。没有驱动又没有合适上拉/下拉时，读数可能不确定。

## 6. GPIO_Speed_50MHz 不等于输出 50 MHz

在 STM32F1 中，GPIO_Speed_2MHz/10MHz/50MHz 是输出驱动速度等级，涉及边沿和驱动能力配置。输出波形是否翻转、按什么频率翻转，由 GPIO 操作或对应外设决定。引脚配置字段见 [RM0008 的 GPIO CRL/CRH 说明](https://www.st.com/resource/en/reference_manual/rm0008-stm32f103xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)。

```c
gpio.GPIO_Mode = GPIO_Mode_AF_PP;
gpio.GPIO_Speed = GPIO_Speed_50MHz;
```

这两行把 PA0 配成较高速度等级的复用推挽，实际 PWM 仍由 TIM2 的 72 MHz、PSC=0、ARR=4799 得到 15 kHz。

也不要为了练习把 PWM 引脚随意改到较低速度等级；这不是调速方法。

## 7. RCC 门控与 C 语言位操作

### 7.1 配置外设之前先打开它的时钟

```c
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                          RCC_APB2Periph_AFIO,
                      ENABLE);
```

这行打开外设时钟门控，让对应配置逻辑工作。它不设置 PLL，也不把 GPIO 波形改成 PCLK2。

GPIOA/B/C、AFIO、USART1、ADC1 用 APB2 的相应门控；TIM2/3/4 用 APB1 的相应门控。GPIO 引脚被哪个外设使用，不会改变 GPIO 模块本身挂在哪条总线上。

### 7.2 GPIO_Pin_8 是位掩码，不是整数 8

```text
GPIO_Pin_8 = 1 << 8 = 0x0100
GPIO_Pin_3 = 1 << 3 = 0x0008
两位合并   = 0x0100 | 0x0008 = 0x0108
```

`|` 是按位或，组合多个位；`||` 是逻辑或，通常只得到 0 或 1。用 `GPIO_Pin_8 || GPIO_Pin_3` 会丢失原有掩码含义。

`GPIO_Init(GPIOA, &gpio)` 决定端口是 A，gpio.GPIO_Pin 决定选择哪些位。因此 GPIO_Pin_0 在 GPIOA 上表示 PA0，在 GPIOB 上表示 PB0。

### 7.3 结构体是在填写配置表

```c
GPIO_InitTypeDef gpio;
gpio.GPIO_Pin = GPIO_Pin_8;
gpio.GPIO_Mode = GPIO_Mode_Out_PP;
gpio.GPIO_Speed = GPIO_Speed_2MHz;
GPIO_Init(GPIOA, &gpio);
```

前三项只是给软件对象赋值，最后 GPIO_Init 才按这张表配置 GPIO。复用同一结构体时，要检查本次需要的字段是否已经赋值。

模拟/数字输入模式不使用 GPIO_Speed 作为输出速度；库实现只在输出模式中合入速度位。这能解释正式代码改成 AIN 前没有再次设置 GPIO_Speed。

## 8. PA8 为什么先 Reset，再初始化为输出？

```c
GPIO_ResetBits(GPIOA, GPIO_Pin_8);
gpio.GPIO_Pin = GPIO_Pin_8;
gpio.GPIO_Mode = GPIO_Mode_Out_PP;
gpio.GPIO_Speed = GPIO_Speed_2MHz;
GPIO_Init(GPIOA, &gpio);
```

ResetBits 先将输出数据锁存值设为 0，再把管脚切到输出模式，减少模式切换时错误输出高电平的机会。

输出锁存 ODR 与输入读回 IDR 有不同意义：读取 ODR 可以知道输出配置要求什么；实际引脚电压还受负载、接线等影响。不能用 ODR=0 代替万用表测量，更不能据此单独证明整个功率级没有任何输出。

PA3/PA6/PA7 是本项目未使用 M1 的三个输入，也在同一组中置低。PA8 是共享使能，不能因为只使用 M0 就忽略 M1 输入的固定状态。

## 9. GPIO 在哪些模块完成最终配置？

board_init 不是一次性替每个模块配置全部引脚。实际最终用途如下：

| 引脚 | 最终模式 | 负责的函数/文件 |
| --- | --- | --- |
| PA8 | Out_PP，初始低 | board.c / 本课 lesson02_gpio_init |
| PA0/PA1/PA2 | AF_PP | board.c / 本课实现，TIM2 输出 PWM |
| PA3/PA6/PA7 | Out_PP，初始低 | board.c / 本课实现，未使用 M1 输入 |
| PB0/PB1 | AIN | board.c / 本课实现，ADC 电流反馈 |
| PA4/PA5 | AIN | 保留原板配置，本课不接旋钮 |
| PA9 | AF_PP | uart_init，串口 TX |
| PA10 | IN_FLOATING | uart_init，串口 RX |
| PB10/PB11 | Out_OD | as5600_init→soft_i2c_init |
| PB6/PB7 | Out_OD | ui_init→oled_init→soft_i2c_init |
| PB4 | IPU | ir_receiver_init，TIM3_CH1 部分重映射 |
| PA13/PA14 | SWD 调试功能 | 释放 JTAG 时仍保留 SWD |

PB4 原本涉及 JTAG 复用，红外模块使用 `GPIO_Remap_SWJ_JTAGDisable` 释放 JTAG，保留 SWD，并配置 TIM3 部分重映射。只把 PB4 设为输入还不够。

本项目没有使用硬件 I²C1/2 完成 AS5600 或 OLED 通信，因此不能把“PB10/PB11 属于 APB1 的 I²C2”直接当作当前软件 I²C 的时钟来源。

## 10. 先写伪代码，再写本课函数

### 10.1 目标

实现与正式 gpio_init 相同的引脚配置；用标准库读取当前时钟配置并输出。上电仍由状态机保持 STOP。

```text
打开 GPIOA/B/C 和 AFIO 时钟
预先将 PA8、PA3、PA6、PA7 的输出锁存置低
把这一组配置为普通推挽输出
把 PA0/PA1/PA2 配为复用推挽
把 PB0/PB1、PA4/PA5 配为模拟输入
读 RCC 时钟配置
根据 APB 分频规则推导定时器时钟
打印各频率和 PA8 输出锁存值
```

### 10.2 先补这段，再看完整代码

```c
GPIO_InitTypeDef gpio;
RCC_APB2PeriphClockCmd(/* A：GPIOA 与 AFIO 掩码 */, ENABLE);
GPIO_ResetBits(GPIOA, GPIO_Pin_8);
gpio.GPIO_Pin = /* B：PA8 的位掩码 */;
gpio.GPIO_Mode = /* C：普通推挽 */;
gpio.GPIO_Speed = GPIO_Speed_2MHz;
GPIO_Init(/* D：端口与配置对象地址 */);
```

参考：A 为 `RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO`；B 为 `GPIO_Pin_8`；C 为 `GPIO_Mode_Out_PP`；D 为 `GPIOA, &gpio`。

## 11. 完整中文注释代码

### 11.1 本课模块 lesson02_resources.c

```c
/*
 * 第二课：实际替换板级 GPIO 初始化，随后只读打印当前时钟配置。
 * GPIO 分组与正式 v1.1.7 的 gpio_init 一致；PA9/PA10、I2C、PB4 仍由各自模块配置。
 * 不在这里重新配置 PLL，不在这里置高 PA8。
 */
#include "lesson02_resources.h"
#include "board.h"
#include "console.h"
#include <stdio.h>

void lesson02_gpio_init(void)
{
    GPIO_InitTypeDef gpio;

    /* GPIOA/B/C 与 AFIO 挂在 APB2；这里开启外设时钟门控，不改变系统主频。
     * | 是按位或，把几个外设使能位组合起来；ENABLE 是标准库的使能参数。
     */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                              RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO,
                          ENABLE);

    /* 先设置输出锁存值，再切到输出模式，减少切换瞬间出现错误高电平的机会。
     * PA8 是共享使能；PA3/PA6/PA7 是未使用 M1 的输入，初始化时统一置低。
     * 此处是数字引脚配置，不能单独证明整个功率电路的所有状态。
     */
    GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_7);
    gpio.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_7;
    gpio.GPIO_Mode = GPIO_Mode_Out_PP; /* 普通推挽输出，由 GPIO_Set/ResetBits 控制 */
    gpio.GPIO_Speed = GPIO_Speed_2MHz; /* 输出驱动速度等级，不是自动生成 2 MHz 波形 */
    GPIO_Init(GPIOA, &gpio);

    /* M0 三路 PWM 引脚改为复用推挽，由 TIM2 控制输出数据。
     * 50 MHz 是引脚速度等级；15 kHz PWM 由定时器输入时钟、PSC、ARR 决定。
     * GPIO_Pin_0 在 GPIOA 上是 PA0；后面 GPIOB 的同一个掩码表示 PB0。
     */
    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    /* PB0/PB1 接两路电流放大器输出，作为 ADC 模拟输入。
     * 模拟输入不由 GPIO 输出驱动；标准库在输入模式下不使用 GPIO_Speed 设置。
     */
    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    gpio.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOB, &gpio);

    /* 保留原板对 PA4/PA5 的模拟配置；本课程无旋钮，不从这里采集旋钮。 */
    gpio.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    gpio.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &gpio);
}

/* 打印的是寄存器配置结合 HSE_VALUE/HSI_VALUE 算出的频率，不是频率计测量值。 */
void lesson02_print_clocks(void)
{
    RCC_ClocksTypeDef clocks;
    char line[180];

    /* 更新软件变量不会重配 PLL；RCC_GetClocksFreq 读取当前时钟源和分频配置。 */
    SystemCoreClockUpdate();
    RCC_GetClocksFreq(&clocks);

    /* STM32F103 的 APB 分频为 1 时，TIMCLK=PCLK；大于 1 时，TIMCLK=2*PCLK。
     * 由 PCLK 与 HCLK 是否相等判断分频是否为 1，不能无条件给所有外设乘 2。
     */
    uint32_t tim_apb1 = clocks.PCLK1_Frequency;
    uint32_t tim_apb2 = clocks.PCLK2_Frequency;
    if (clocks.PCLK1_Frequency != clocks.HCLK_Frequency)
        tim_apb1 *= 2u;
    if (clocks.PCLK2_Frequency != clocks.HCLK_Frequency)
        tim_apb2 *= 2u;

    (void)snprintf(line, sizeof(line), "L2 SYS=%lu HCLK=%lu PCLK1=%lu PCLK2=%lu Hz\r\n",
                   (unsigned long)clocks.SYSCLK_Frequency,
                   (unsigned long)clocks.HCLK_Frequency,
                   (unsigned long)clocks.PCLK1_Frequency,
                   (unsigned long)clocks.PCLK2_Frequency);
    console_message(line);

    (void)snprintf(line, sizeof(line), "L2 TIM_APB1=%lu TIM_APB2=%lu ADC=%lu Hz\r\n",
                   (unsigned long)tim_apb1, (unsigned long)tim_apb2,
                   (unsigned long)clocks.ADCCLK_Frequency);
    console_message(line);

    /* 读取输出锁存值，不是用万用表测到的引脚电压。 */
    (void)snprintf(line, sizeof(line), "L2 SystemCoreClock=%lu PA8_ODR=%u\r\n",
                   (unsigned long)SystemCoreClock,
                   (unsigned)GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_8));
    console_message(line);
}
```

### 11.2 完整入口 main.c

```c
/*
 * 第二课入口：复用正式控制与交互模块，使用本课 GPIO 初始化并打印时钟配置。
 * Target：Lesson02_NoKnob。board_init 的 GPIO 调用由生成的 board_lesson02.c 接入。
 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "lesson02_resources.h"

int main(void)
{
    AppParams params;
    uint32_t last_check_ms, last_samples = 0u, last_steps = 0u;

    board_init(); /* 实际调用 lesson02_gpio_init；其他板级逻辑复用正式实现 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson02 v1.1.7: clocks and GPIO\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");

    /* 此时 ADC 分频、GPIO、串口已经配置，控制 TIM2/TIM4 尚未启动。 */
    lesson02_print_clocks();
    board_start_control();
    ui_init();
    board_watchdog_start();
    last_check_ms = board_millis();

    while (1)
    {
        console_poll();
        ui_poll();

        /* 沿用第一课的任务存活检查；本课不改变控制周期。 */
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus snapshot;
            last_check_ms = now;
            motor_snapshot(&snapshot);
            if (snapshot.sensor_samples != last_samples && snapshot.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = snapshot.sensor_samples;
            last_steps = snapshot.current_steps;
        }
    }
}
```

### 11.3 这段代码怎样真正进入工程？

本课工程只链接一个 main 和一个板级实现：

```text
Learning/Lesson02/main.c
    → board_init（board_lesson02.c）
    → lesson02_gpio_init（lesson02_resources.c）
```

board_lesson02.c 从正式 BSP/board.c 自动生成，保留串口、PWM、ADC、IRQ 和看门狗，把 GPIO 初始化接到本课函数。因此学习函数会实际使用，而不是只有一段不调用的参考代码。

练习时修改 lesson02_resources.c；正式 BSP/board.c 仍是对照文件。重新生成学习工程可运行 Tools/make_learning_project.py，它会按当前正式版本更新连接文件，同时生成各课的独立工程。

## 12. 编译与一个代表性观察

打开 **ControlPanel_Lesson02.uvprojx**，选择 **Lesson02_NoKnob**，使用 ARM Compiler 6.18。

- 本课输出：Objects/Lesson02/Lesson02_NoKnob.hex。
- 本课 GPIO 文件：Learning/Lesson02/lesson02_resources.c。
- 本课 main：Learning/Lesson02/main.c。
- 第一课仍通过 ControlPanel_Learning.uvprojx 编译。

根据当前配置，本课启动后的预期输出为：

```text
Lesson02 v1.1.7: clocks and GPIO
L2 SYS=72000000 HCLK=72000000 PCLK1=36000000 PCLK2=72000000 Hz
L2 TIM_APB1=72000000 TIM_APB2=72000000 ADC=12000000 Hz
L2 SystemCoreClock=72000000 PA8_ODR=0
```

这不是本轮硬件实测日志；它是预期值。TIM_APB2 表示该总线定时器时钟路径，并不表示本项目已启用 TIM1。

当前代码把 ADC 分频配置放在 board_init 内，因此打印时应已为 12 MHz；如果把打印搬到 ADC 分频配置之前，得到的可能是复位后的分频值。

本课观察集中在这三行：检查推算结果、解释每一项来自哪一级时钟，并说明 PA8_ODR 的证据范围。无需用修改主频、PWM 频率或切换使能来证明已经学会。

## 13. 手算与代码练习

### 练习 A：把时钟树自己画一遍

画出 HSE→PLL→AHB→APB1/APB2，并标出 TIM2、USART1、ADC、GPIOA、SysTick。每条箭头写上分频/倍频系数。

### 练习 B：只写一个端口配置

合上参考，写出“PA0/PA1/PA2 作为 TIM2 复用推挽输出”的完整标准库片段。至少包括 GPIOA 门控、引脚掩码、模式、速度等级与 GPIO_Init 调用。

### 练习 C：不修改硬件，只改变题目条件

假设 HCLK 仍为 72 MHz，APB1 改为四分频，TIM4 的 PSC=71、ARR=999：

1. PCLK1 是多少？
2. TIM4 输入时钟是多少？
3. 每个计数多少 μs？更新周期多少 ms？

参考：18 MHz、36 MHz、2 μs、2 ms。不要直接把这些条件写进当前整机配置。

## 14. 自测与答案

先独立回答，再检查答案。

1. 8 MHz 晶振为什么能得到 72 MHz 主频？
2. SystemCoreClockUpdate 是否会重新配置 PLL？
3. APB1=36 MHz，本项目 TIM2 为何是 72 MHz？APB1 四分频时 TIM2 又是多少？
4. GPIO_Speed_50MHz、PWM 15 kHz、控制 3 kHz 三者分别表示什么？
5. `GPIO_Pin_8 | GPIO_Pin_3` 的十六进制值是多少？改为 `||` 会怎样？
6. 为什么 GPIO_Init(GPIOA, &gpio) 与 GPIO_Init(GPIOB, &gpio) 会配置不同引脚？
7. 软件 I²C 为什么写 1 表示释放 SDA？为什么本项目用 Out_OD？
8. PB0 接 ADC 应选 AIN 还是 AF_PP？
9. PA8 先 ResetBits 再切为输出，解决哪个阶段的问题？
10. ODR=0、oled=1、RCC 打印 72 MHz，分别不能直接证明什么？

参考答案：

1. HSE 输入 PLL，当前配置为 ×9，再作为 SYSCLK。
2. 不会，它更新软件记录；改变硬件需要配置 RCC。
3. APB 分频大于 1 时定时器时钟为 2×PCLK1；四分频时是 2×18=36 MHz。
4. 引脚驱动速度等级、PWM 载波频率、电流任务调度频率。
5. 0x0108；逻辑或通常得到 1，原掩码被丢失。
6. 端口参数决定 A/B 组，GPIO_Pin 掩码决定组内的位。
7. 开漏只主动拉低，写 1 关闭下拉，由上拉形成高电平并允许从机 ACK；线路由软件 GPIO 操作。
8. AIN。
9. 模式切换时先准备输出锁存初值，减少错误高电平；不是对整个功率级的完整验证。
10. ODR 不直接证明真实引脚电压；oled=1 不直接证明肉眼画面；RCC 推算不直接测量实际晶振频率。

## 15. 本课完成标准与求职积累

产出一张时钟树、一份最终引脚表、你自己写的 PA8/PWM 初始化片段和一份编译日志。

一分钟讲解示例：

> 我的主控使用外部 8 MHz 经 PLL 得到 72 MHz。APB1 为 36 MHz，但 TIM2/3/4 通过定时器时钟路径得到 72 MHz。板级初始化先准备驱动输入低电平，再设置输出模式；PWM 引脚选复用推挽，软件 I²C 选普通开漏，电流反馈选模拟输入。外设时钟门控、引脚模式和外设自身配置各有作用，不能只完成其中一项。

下一课：**USART1 与命令调试通道**。沿 PA9/PA10→USART 中断→环形缓冲→console_poll，补齐 static、extern、volatile 与字符串解析。
