/* Generated from BSP/board.c; edit lesson02_resources.c for GPIO practice. */
/*
 * 板级支持：沿用例程的 STM32F10x 标准外设库，配置 GPIO、定时器、ADC 和串口。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "board.h"
#include "lesson02_resources.h"
#include "app_config.h"
#include "motor.h"
#include "as5600.h"
#include "ir_receiver.h"
#include <string.h>

static volatile uint32_t milliseconds;
static char tx[1024], rx[256];
static volatile uint16_t tx_head, tx_tail, rx_head, rx_tail;
static volatile uint32_t dropped;
/* 例程的旧 CMSIS 没有 DWT_Type；标准外设库也不封装内核 DWT，因此这里保留内核计时寄存器。 */
#define DWT_CTRL_REG (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT_REG (*(volatile uint32_t *)0xE0001004u)

/* 进入短临界区：先保存 PRIMASK，再关闭可屏蔽中断。返回值用于恢复原有中断状态。 */
uint32_t board_lock(void)
{
    uint32_t key;
    __asm volatile("mrs %0, primask" : "=r"(key));
    __disable_irq();
    return key;
}
/* 退出临界区，恢复进入前的 PRIMASK，避免嵌套调用时错误地提前打开中断。 */
void board_unlock(uint32_t key)
{
    __asm volatile("msr primask, %0" ::"r"(key) : "memory");
}
/* 读取 SysTick 维护的毫秒计数；无符号差值可处理计数自然回绕。 */
uint32_t board_millis(void)
{
    return milliseconds;
}
/* 读取 Cortex-M3 内核周期计数。72 MHz 时每 72 个计数约为 1 μs。 */
uint32_t board_cycles(void)
{
    return DWT_CYCCNT_REG;
}
/* 使用标准库读取 TIM3 计数器；该定时器每计数 1 μs，65536 μs 后回绕。 */
uint16_t board_timer_us(void)
{
    return TIM_GetCounter(TIM3);
}
/* 根据内核周期数进行微秒等待，仅用于软件 I²C 的短时序，不作为电机采样调度。 */
void board_delay_us(uint32_t us)
{
    uint32_t start = board_cycles(), wait = us * (BOARD_CPU_HZ / 1000000u);
    while ((uint32_t)(board_cycles() - start) < wait)
    {
        __NOP();
    }
}
/* 通过标准库设置 PA8。1 为请求栅极供电使能，0 为关闭；PA8 是两路驱动共用的。 */
void board_gate(uint8_t enabled)
{
    if (enabled)
        GPIO_SetBits(GPIOA, GPIO_Pin_8);
    else
        GPIO_ResetBits(GPIOA, GPIO_Pin_8);
}
/* 对应例程 PWM_Channel1/2/3，使用 TIM_SetCompare1/2/3 写三路 CCR，范围为 0～4800。 */
void board_pwm(uint16_t a, uint16_t b, uint16_t c)
{
    TIM_SetCompare1(TIM2, a);
    TIM_SetCompare2(TIM2, b);
    TIM_SetCompare3(TIM2, c);
}
/* 产生一次更新事件，使预装载比较值生效；启动时先锁存中点占空比，再使能驱动。 */
void board_pwm_latch(void)
{
    TIM_GenerateEvent(TIM2, TIM_EventSource_Update);
}

/* 配置 USART1：PA9 复用推挽发送、PA10 浮空接收、115200/8N1，接收使用中断。 */
static void uart_init(void)
{
    GPIO_InitTypeDef g;
    USART_InitTypeDef u;
    NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    g.GPIO_Pin = GPIO_Pin_9;
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);
    g.GPIO_Pin = GPIO_Pin_10;
    g.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &g);
    USART_StructInit(&u);
    u.USART_BaudRate = BOARD_UART_BAUD;
    USART_Init(USART1, &u);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);
    n.NVIC_IRQChannel = USART1_IRQn;
    /* 115200/8N1 每字节约 86.8 μs，F103 的 USART 没有接收 FIFO。
     * 串口只搬运字节，必须能抢占耗时的软件 I²C（TIM4），避免 RXNE 来不及读取而 ORE。
     * 优先级：ADC=0、USART1=1、PendSV控制=2、TIM4/红外=3、SysTick=4。 */
    n.NVIC_IRQChannelPreemptionPriority = 1;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
}
/* 参照例程的结构体初始化方式配置 TIM2 PWM、ADC1 注入组、TIM3 时基和 TIM4 采样中断。 */
static void pwm_adc_init(void)
{
    TIM_TimeBaseInitTypeDef t;
    TIM_OCInitTypeDef oc;
    ADC_InitTypeDef a;
    NVIC_InitTypeDef n;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 | RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    /* TIM2 输入 72 MHz：fPWM=72000000/((0+1)×(4799+1))=15 kHz。 */
    TIM_TimeBaseStructInit(&t);
    t.TIM_Period = BOARD_PWM_COUNTS - 1u;
    t.TIM_Prescaler = 0;
    TIM_TimeBaseInit(TIM2, &t);
    TIM_OCStructInit(&oc);
    oc.TIM_OCMode = TIM_OCMode_PWM1;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    oc.TIM_Pulse = 0;
    TIM_OC1Init(TIM2, &oc);
    TIM_OC2Init(TIM2, &oc);
    TIM_OC3Init(TIM2, &oc);
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
    /* CH4 在 CNT=4400（约 61.1 μs）触发 ADC，避开 50% 附近的三相开关沿。
     * 参数限制电压幅值不超过母线 25%，最高相占空比不超过 75%：
     * 最晚开关约在 50 μs，采样前留约 11.1 μs，两个 ADC 转换约 3.33 μs，
     * 仍早于下周期 66.7 μs 的开关。PA3 保持 GPIO 低，不输出 CH4 波形。 */
    oc.TIM_OCMode = TIM_OCMode_PWM2;
    oc.TIM_Pulse = BOARD_ADC_TRIGGER_TICKS;
    TIM_OC4Init(TIM2, &oc);
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_OC4Ref);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    ADC_StructInit(&a);
    a.ADC_Mode = ADC_Mode_Independent;
    a.ADC_ScanConvMode = ENABLE;
    a.ADC_ContinuousConvMode = DISABLE;
    a.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    a.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &a);
    /* 注入组依次采 PB0/ADC_IN8、PB1/ADC_IN9；不沿用旧例程的自由连续转换。 */
    ADC_InjectedSequencerLengthConfig(ADC1, 2);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_7Cycles5);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_9, 2, ADC_SampleTime_7Cycles5);
    ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_T2_TRGO);
    /* 电流采样仅使用注入组，由 TIM2 事件触发。 */
    ADC_Cmd(ADC1, ENABLE);
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1))
    {
    }
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1))
    {
    }
    ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
    ADC_ITConfig(ADC1, ADC_IT_JEOC, ENABLE);
    n.NVIC_IRQChannel = ADC1_2_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 0;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
    /* TIM3：72 MHz/(71+1)=1 MHz，每计数 1 μs，供红外输入捕获使用。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 65535;
    TIM_TimeBaseInit(TIM3, &t);
    TIM_Cmd(TIM3, ENABLE);
    /* TIM4：1 MHz/(999+1)=1 kHz，每 1 ms 触发一次角度任务。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 999;
    TIM_TimeBaseInit(TIM4, &t);
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    n.NVIC_IRQChannel = TIM4_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_Init(&n);
}
/* 初始化板级资源。此时只配置控制定时器，直到 board_start_control 才正式启动采样。 */
void board_init(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    lesson02_gpio_init();
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT_CYCCNT_REG = 0u;
    DWT_CTRL_REG |= 1u;
    SystemCoreClockUpdate();
    SysTick_Config(SystemCoreClock / 1000u);
    NVIC_SetPriority(PendSV_IRQn, 2u);
    NVIC_SetPriority(SysTick_IRQn, 4u);
    uart_init();
    pwm_adc_init();
}
/* 打开 PWM 触发的 ADC 注入转换并启动 TIM2/TIM4；启动采样不会自动置高 PA8。 */
void board_start_control(void)
{
    ADC_ExternalTrigInjectedConvCmd(ADC1, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
    TIM_Cmd(TIM4, ENABLE);
}
/* 把整段文本放入环形缓冲区；空间不足时返回 0，避免主循环等待串口硬件。 */
uint8_t board_uart_write(const char *s)
{
    unsigned len = (unsigned)strlen(s);
    uint32_t key = board_lock();
    unsigned free_space = (tx_tail - tx_head - 1u) & 1023u;
    if (len > free_space)
    {
        ++dropped;
        board_unlock(key);
        return 0u;
    }
    while (*s)
    {
        tx[tx_head] = *s++;
        tx_head = (tx_head + 1u) & 1023u;
    }
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    board_unlock(key);
    return 1u;
}
/* 从接收环形缓冲区取一个字节；没有新字符时返回 -1。 */
int board_uart_read(void)
{
    if (rx_head == rx_tail)
        return -1;
    int c = (uint8_t)rx[rx_tail];
    rx_tail = (rx_tail + 1u) & 255u;
    return c;
}
/* 取得串口溢出/接收错误的累计次数，便于判断输出是否过多。 */
uint32_t board_uart_dropped(void)
{
    return dropped;
}
/* 使用标准库启动独立看门狗；按 LSI 约 40 kHz 估算，超时时间约 1 s。 */
void board_watchdog_start(void)
{
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
    IWDG_SetPrescaler(IWDG_Prescaler_64);
    IWDG_SetReload(625u);
    IWDG_ReloadCounter();
    IWDG_Enable(); /* 按标称 LSI 频率估算约 1 s */
}
/* 重装独立看门狗计数器；主循环只在控制任务持续运行时调用。 */
void board_watchdog_feed(void)
{
    IWDG_ReloadCounter();
}
/* SysTick 每 1 ms 进入一次，只增加毫秒计数，不在这里执行耗时操作。 */
void SysTick_Handler(void)
{
    ++milliseconds;
}
/* 每次 PWM 同步注入转换完成后进入，读取 PB0/PB1 对应结果，交给电流任务处理。 */
void ADC1_2_IRQHandler(void)
{
    if (ADC_GetITStatus(ADC1, ADC_IT_JEOC))
    {
        uint16_t a = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
        uint16_t b = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
        ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
        motor_adc_isr(a, b);
    }
}
/* ADC 每 5 帧请求一次独立控制任务；ADC 本身可抢占该任务继续采样/检查过流。 */
void board_current_request(void)
{
    SCB->ICSR = SCB_ICSR_PENDSVSET_Msk;
}
void PendSV_Handler(void)
{
    motor_current_task();
}
/* 每 1 ms 连续读取磁场状态和角度并更新外环，记录包含抢占在内的本次任务耗时。 */
void TIM4_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM4, TIM_IT_Update))
    {
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
        uint32_t begin = board_cycles();
        uint16_t raw = 0u;
        uint8_t magnet = 0u;
        /* 单次连续读同时取得状态和角度，消除每 100 帧第二次事务造成的耗时尖峰。 */
        uint8_t ok = as5600_sample(&raw, &magnet);
        motor_sensor_isr(raw, ok, magnet, board_cycles(), board_millis());
        uint32_t elapsed = board_cycles() - begin;
        motor_record_sensor_time(elapsed);
        if (elapsed > BOARD_SENSOR_BUDGET_US * 72u)
            motor_timing_fault(TIMING_SENSOR_TASK, elapsed);
    }
}
/* 按标准库查询 RXNE/TXE 和错误标志，只搬运字节；文本解析留在主循环。 */
void USART1_IRQHandler(void)
{
    uint8_t error = USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET ||
                    USART_GetFlagStatus(USART1, USART_FLAG_FE) != RESET ||
                    USART_GetFlagStatus(USART1, USART_FLAG_NE) != RESET;
    /* 先读取状态，再调用标准库读数据，完成 F1 串口错误标志的清除序列。 */
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET || error)
    {
        uint8_t c = (uint8_t)USART_ReceiveData(USART1);
        uint16_t next = (rx_head + 1u) & 255u;
        if (error)
            ++dropped;
        else if (next != rx_tail)
        {
            rx[rx_head] = (char)c;
            rx_head = next;
        }
        else
            ++dropped;
    }
    if (USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
    {
        if (tx_tail != tx_head)
        {
            USART_SendData(USART1, (uint8_t)tx[tx_tail]);
            tx_tail = (tx_tail + 1u) & 1023u;
        }
        else
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
    }
}
/* 发生硬件异常时先关闭 PA8，随后等待看门狗复位。 */
void HardFault_Handler(void)
{
    board_gate(0u);
    while (1)
    {
    }
}
/* 内存管理异常：先关闭驱动，再停在异常处理函数。 */
void MemManage_Handler(void)
{
    board_gate(0u);
    while (1)
    {
    }
}
/* 总线访问异常：先关闭驱动，再等待复位。 */
void BusFault_Handler(void)
{
    board_gate(0u);
    while (1)
    {
    }
}
/* 指令使用异常：先关闭驱动，再等待复位。 */
void UsageFault_Handler(void)
{
    board_gate(0u);
    while (1)
    {
    }
}
/* 不可屏蔽异常：先关闭驱动，避免异常期间继续施加旧输出。 */
void NMI_Handler(void)
{
    board_gate(0u);
    while (1)
    {
    }
}
