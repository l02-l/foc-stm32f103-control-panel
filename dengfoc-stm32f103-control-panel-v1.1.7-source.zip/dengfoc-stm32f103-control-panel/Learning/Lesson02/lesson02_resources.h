/* 第二课：板级 GPIO 配置与时钟信息接口。使用 STM32F10x 标准外设库。 */
#ifndef LESSON02_RESOURCES_H
#define LESSON02_RESOURCES_H

void lesson02_gpio_init(void);
void lesson02_print_clocks(void);

#endif
