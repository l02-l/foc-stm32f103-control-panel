/*
 * 第二课：实际替换板级 GPIO 初始化，随后只读打印当前时钟配置。
 * GPIO 分组与正式 v1.1.7 的 gpio_init 一致；PA9/PA10、I2C、PB4 仍由各自模块配置。
 * 不在这里重新配置 PLL，不在这里置高 PA8。
 */
#include "lesson02_resources.h"
#include "board.h"
#include "console.h"
#include <stdio.h>

void lesson02_gpio_init(void)
{
    GPIO_InitTypeDef gpio;

    /* GPIOA/B/C 与 AFIO 挂在 APB2；这里开启外设时钟门控，不改变系统主频。
     * | 是按位或，把几个外设使能位组合起来；ENABLE 是标准库的使能参数。
     */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                              RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO,
                          ENABLE);

    /* 先设置输出锁存值，再切到输出模式，减少切换瞬间出现错误高电平的机会。
     * PA8 是共享使能；PA3/PA6/PA7 是未使用 M1 的输入，初始化时统一置低。
     * 此处是数字引脚配置，不能单独证明整个功率电路的所有状态。
     */
    GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_7);
    gpio.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_7;
    gpio.GPIO_Mode = GPIO_Mode_Out_PP; /* 普通推挽输出，由 GPIO_Set/ResetBits 控制 */
    gpio.GPIO_Speed = GPIO_Speed_2MHz; /* 输出驱动速度等级，不是自动生成 2 MHz 波形 */
    GPIO_Init(GPIOA, &gpio);

    /* M0 三路 PWM 引脚改为复用推挽，由 TIM2 控制输出数据。
     * 50 MHz 是引脚速度等级；15 kHz PWM 由定时器输入时钟、PSC、ARR 决定。
     * GPIO_Pin_0 在 GPIOA 上是 PA0；后面 GPIOB 的同一个掩码表示 PB0。
     */
    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    /* PB0/PB1 接两路电流放大器输出，作为 ADC 模拟输入。
     * 模拟输入不由 GPIO 输出驱动；标准库在输入模式下不使用 GPIO_Speed 设置。
     */
    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    gpio.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOB, &gpio);

    /* 保留原板对 PA4/PA5 的模拟配置；本课程无旋钮，不从这里采集旋钮。 */
    gpio.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    gpio.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &gpio);
}

/* 打印的是寄存器配置结合 HSE_VALUE/HSI_VALUE 算出的频率，不是频率计测量值。 */
void lesson02_print_clocks(void)
{
    RCC_ClocksTypeDef clocks;
    char line[180];

    /* 更新软件变量不会重配 PLL；RCC_GetClocksFreq 读取当前时钟源和分频配置。 */
    SystemCoreClockUpdate();
    RCC_GetClocksFreq(&clocks);

    /* STM32F103 的 APB 分频为 1 时，TIMCLK=PCLK；大于 1 时，TIMCLK=2*PCLK。
     * 由 PCLK 与 HCLK 是否相等判断分频是否为 1，不能无条件给所有外设乘 2。
     */
    uint32_t tim_apb1 = clocks.PCLK1_Frequency;
    uint32_t tim_apb2 = clocks.PCLK2_Frequency;
    if (clocks.PCLK1_Frequency != clocks.HCLK_Frequency)
        tim_apb1 *= 2u;
    if (clocks.PCLK2_Frequency != clocks.HCLK_Frequency)
        tim_apb2 *= 2u;

    (void)snprintf(line, sizeof(line), "L2 SYS=%lu HCLK=%lu PCLK1=%lu PCLK2=%lu Hz\r\n",
                   (unsigned long)clocks.SYSCLK_Frequency,
                   (unsigned long)clocks.HCLK_Frequency,
                   (unsigned long)clocks.PCLK1_Frequency,
                   (unsigned long)clocks.PCLK2_Frequency);
    console_message(line);

    (void)snprintf(line, sizeof(line), "L2 TIM_APB1=%lu TIM_APB2=%lu ADC=%lu Hz\r\n",
                   (unsigned long)tim_apb1, (unsigned long)tim_apb2,
                   (unsigned long)clocks.ADCCLK_Frequency);
    console_message(line);

    /* 读取输出锁存值，不是用万用表测到的引脚电压。 */
    (void)snprintf(line, sizeof(line), "L2 SystemCoreClock=%lu PA8_ODR=%u\r\n",
                   (unsigned long)SystemCoreClock,
                   (unsigned)GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_8));
    console_message(line);
}
