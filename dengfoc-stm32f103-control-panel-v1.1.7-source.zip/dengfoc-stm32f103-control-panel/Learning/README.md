# 按模块学习项目

基线为无旋钮 ControlPanel，保留 OLED、遥控器与串口。课程复用实际模块，通过独立入口/连接文件接入练习代码。

| 课 | 完整讲解与代码 | Target |
| --- | --- | --- |
| 1 | [启动与任务](Lesson01/README.md) | Lesson01_NoKnob |
| 2 | [时钟与 GPIO](Lesson02/README.md) | Lesson02_NoKnob |
| 3 | [串口与命令](Lesson03/README.md) | Lesson03_NoKnob |
| 4 | [角度与速度](Lesson04/README.md) | Lesson04_NoKnob |
| 5 | [PWM 与调度](Lesson05/README.md) | Lesson05_NoKnob |
| 6 | [电流与零点](Lesson06/README.md) | Lesson06_NoKnob |

课程 1 打开 ControlPanel_Learning.uvprojx；课程 2～6 打开对应 ControlPanel_Lesson02.uvprojx 等。一个 Target 不同时加入多个 main/board/motor 实现。

[完整大纲](../Docs/LEARNING_OUTLINE.md) · [构建步骤](../Docs/BUILD.md)

Tools/make_learning_project.py 可重建各课工程和连接文件。练习按手写模块注释修改，输出在 Objects/LessonXX。校准/启动需显式请求，单纯观察日志不要求转动。
