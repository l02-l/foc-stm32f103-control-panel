# 第一课：读懂 main，让整个项目协同运行

版本：**v1.1.7，无旋钮，保留 OLED、遥控器与串口**。更新日期：2026-10-31。

预计 5～6 小时，可分两次学习。先理解知识点，再按伪代码动手，最后看完整参考代码。

## 0. 本课目标与文件

你已经能观察电机运行和屏幕页面。本课要进一步回答：**这些功能是怎样被 main 组织起来的？**

完成后，应能自己写出初始化顺序和后台循环，并解释采样、控制与显示由谁执行。本课先把各模块当作有明确输入输出的函数使用；后续课程逐个实现模块内部。

| 材料 | 本课用途 |
| --- | --- |
| [正式入口 App/main.c](../../App/main.c) | 看完整项目实际上怎样启动 |
| [中文注释学习入口 main.c](main.c) | 本课完整代码，增加每秒一条 L1 观察日志 |
| [学习工程 ControlPanel_Learning.uvprojx](../../ControlPanel_Learning.uvprojx) | 选择 Lesson01_NoKnob 编译 |
| [board.c](../../BSP/board.c)、[motor.h](../../Control/motor.h) | 找中断入口、接口和运行状态 |
| [app_config.h](../../Config/app_config.h) | 核对版本、频率与 SSD1306 默认配置 |

正式项目与学习工程使用相同的板级驱动、AS5600、控制算法、菜单和 Flash 模块。学习入口增加 1 Hz 观察日志。正式 App/main.c 不因本课而改动。

本课代码已编译验证，编译记录见 [build.log](build.log)；本轮没有烧录学习入口。v1.1.6 正式工程的已有实测结果见 [验证报告](../../Docs/UI_VALIDATION.md)，两者分别记录。

## 1. 先建立四个概念

### 1.1 初始化：建立资源和起始状态

初始化就是让模块具备工作条件。例如：

- USART1 初始化：配置 PA9/PA10、115200 波特率、收发中断。
- 电机模块初始化：装入 PID、限幅和校准参数，清除上次控制历史，建立 STOP。
- AS5600 初始化：准备 PB10/PB11 软件 I²C 总线。

把 GPIO 配好不等于电机已经转动；把控制参数装好也不等于已经产生有效转矩。初始化、开始周期采样、使能功率桥是三个不同动作。

### 1.2 主循环：持续处理后台工作

```c
while (1)
{
    console_poll();
    ui_poll();
}
```

`1` 恒为真，所以循环反复执行。`poll` 表示本次检查并处理需要完成的工作：串口有没有收到命令、遥控有没有新事件、屏幕还有没有一小块数据待发。

函数返回后，主循环继续往下执行。没有 `Delay_ms()` 不代表没有执行耗时，例如 OLED 每次发送 16 字节仍需要时间。

### 1.3 中断：事件触发后进入指定入口

ADC 转换完成或定时器产生更新事件时，外设可以向 CPU 请求中断。CPU 在允许条件下暂存现场，执行处理函数，然后恢复被打断的代码。

本项目只有一个 CPU 内核，不是每个模块各占一个 CPU。不同优先级的中断可以抢占，被抢占者稍后继续。

```text
主循环处理 OLED
    → ADC 转换完成，进入 ADC1_2_IRQHandler
    → ADC 处理结束，若 PendSV 已挂起且满足优先级条件，执行控制任务
    → 恢复主循环
```

主循环没有逐次调用 FOC，控制仍能执行，就是因为控制任务有另外的触发入口。

### 1.4 状态、模式、页面、参数分别回答不同问题

| 概念 | 例子 | 回答的问题 |
| --- | --- | --- |
| 运行状态 state | STOP、CAL、RUN、FAULT | 当前在停机、校准、运行还是故障？ |
| 控制模式 mode | CURRENT、SPEED、POSITION | 外部给定的是电流、速度还是位置？ |
| 显示页面 page | 监视、电流 PID、速度 PID、位置 PID、限值 | 当前在屏幕上查看/编辑什么？ |
| 配置参数 AppParams | PID、限值、极对数、电角零偏、屏幕配置 | 控制与界面采用哪些设置？ |

你刚才看到过顶行 `SPEED STOP`、第二行 `CURRENT PID`：选择速度模式、保持停机、查看电流环参数，这三个条件可以同时成立。

`cal=1` 表示电角校准记录有效；`st=CAL` 表示正在执行校准流程。它们不是同一个概念。已有校准保存后，上电仍为 STOP。

## 2. 从硬件到目录

### 2.1 本课只记住这些信号

| 信号 | 本项目位置 | 含义 |
| --- | --- | --- |
| 三相 PWM | PA0/PA1/PA2，TIM2 CH1/2/3 | 给 M0 功率桥的调制指令 |
| 驱动使能 | PA8 | 请求栅极供电使能；由驱动状态机控制 |
| 两相电流采样 | PB0/PB1，ADC 注入组 | 电流反馈 |
| AS5600 | PB10=SCL、PB11=SDA | 原始角度与磁场状态反馈 |
| OLED | PB6=SCL、PB7=SDA | 当前模块使用 SSD1306 兼容配置 |
| 红外 | PB4，TIM3_CH1 | 捕获遥控接收脉冲 |
| 串口 | PA9=TX、PA10=RX | 绿色转接板的板载 CH340 接电脑 |

STM32F103C8T6 运行于 72 MHz。通过遥控或串口给定目标。M1 不作为本课控制对象。具体接线仍以 [WIRING.md](../../Docs/WIRING.md) 为准。

### 2.2 按职责找文件

| 层 | 文件 | 第一课理解程度 |
| --- | --- | --- |
| 启动与厂商库 | Drivers/CMSIS、Drivers/SPL | 知道启动入口和标准外设库的来源 |
| 板级支持 BSP | board.c、as5600.c、oled.c、ir_receiver.c | 知道谁配置硬件、谁处理中断 |
| 控制与参数 | motor.c、control_math.c、params.c | 知道参数、状态、控制计算的接口 |
| 应用 | main.c、console.c、ui.c、settings.c | 知道入口如何组织功能 |

读代码时先回答：函数定义在哪里、谁调用、传入什么、返回什么。看到不认识的 PI 细节可以做标记，第一课先追踪函数边界。

## 3. 从复位到自己的 main

当前项目的启动流程：

```text
MCU 从用户 Flash 启动
    → 从向量表取得初始栈指针、Reset_Handler 地址
    → Reset_Handler 调用 SystemInit()
    → 跳转 C 运行库入口 __main
    → 建立初始化数据区和零初始化区
    → 进入自己的 main()
```

在 [启动文件](../../Drivers/CMSIS/startup_stm32f10x_md.s) 中找到：

```asm
LDR R0, =SystemInit
BLX R0
LDR R0, =__main
BX  R0
```

本课不用手写汇编，能指出这两个调用即可。

- `SystemInit()` 在 main 前处理系统时钟等底层设置。
- `board_init()` 在 main 内配置这个项目要用的外设。
- `__main` 是 C 运行库入口；`main` 是你写的应用入口。

全局/静态未显式初始化对象会得到零初始化；普通自动局部变量不会因此自动变成零。例如 `AppParams params;` 声明后仍要由后面的函数完整赋值。

## 4. 本课需要补齐的 C 语言

### 4.1 声明、定义、调用

```c
/* board.h 中：函数声明，告诉编译器接口。 */
void board_start_control(void);

/* board.c 中：函数定义，给出实现。 */
void board_start_control(void)
{
    /* 实际外设操作见原文件。 */
}

/* main.c 中：调用函数。 */
board_start_control();
```

头文件中的声明不包含函数的全部机器代码。实现所在的 `.c` 仍需加入 Keil 工程并参与链接。函数名后面的 `()` 表示调用；仅写函数名不会执行它。

### 4.2 结构体与取地址

```c
AppParams params;
uint8_t loaded = settings_load(&params);
```

逐项读：

1. `AppParams` 是结构体类型，`params` 是一个对象。
2. `&params` 取对象地址，传入函数后，函数能填写调用者的对象。
3. `settings_load()` 返回一个 uint8_t 值，赋给 loaded。

这里有两条输出通路：**指针写出配置，返回值说明配置来源。**

| loaded | params 的内容 | 后续行为 |
| --- | --- | --- |
| 1 | 有效 Flash 记录 | 可包含已保存的电角校准、PID、屏幕设置 |
| 0 | 函数已填好的默认参数 | 默认未校准，需要后续明确执行校准才能启动 |

所以 loaded=0 不表示 params 没有值。判断返回值含义要读函数约定。

### 4.3 配置与运行快照

```c
AppParams params;          /* PID、限值、校准和界面配置。 */
MotorStatus snapshot;      /* 运行状态、角度、转速、计数和故障。 */

motor_init(&params);       /* 读取配置，在控制模块内部建立初始状态。 */
motor_snapshot(&snapshot); /* 把共享运行信息复制到当前对象。 */
```

对象通过 `snapshot.state` 访问成员。指针通过 `s->state` 访问成员，等价于 `(*s).state`。

本课 `lesson_report(uint32_t now, const MotorStatus *s)` 中，`const` 表示函数不通过这个指针修改快照；`static` 表示该函数只在当前 `.c` 文件内使用。它们不代表关闭中断或自动同步数据。

`motor_snapshot()` 在短临界区内复制状态，避免中断更新一半时读到相互不一致的成员。`volatile` 本身不能保证整个结构体快照一致。

### 4.4 哪些变量要记住上一轮？

```c
uint32_t last_report_ms = 0u;
while (1)
{
    /* 本轮更新 last_report_ms，下一轮继续使用。 */
}
```

循环外的初始化只执行一次。如果把 `uint32_t last_report_ms = 0u;` 放到循环体里，每轮重新初始化，就不能正确记住上次输出时刻。静态局部变量具有不同的存储期，这不等于“循环体里绝对不能声明变量”：本轮临时快照和 now 就适合定义在需要它们的代码块里。

### 4.5 用时间差安排后台工作

```c
if ((uint32_t)(now - last_report_ms) >= 1000u)
{
    last_report_ms = now;
    /* 安排一次输出。 */
}
```

now 和 last_report_ms 单位都是毫秒，先作无符号差，再比较。`u` 表示无符号整数常量。

例如 last=4294967290、now=14，32 位无符号差是 20 ms。这个写法可处理自然回绕，前提是没有漏过整整一个 2³² ms 周期，约 49.7 天。

这是主循环中“至少间隔 1000 ms 执行一次”的安排；主循环其他工作可能让它稍晚执行。它与 TIM4 精确配置的 1 ms 更新事件是两种不同机制。

### 4.6 两个最容易混淆的表达式

```c
last_samples = snapshot.sensor_samples;        /* =：赋值，更新记忆。 */
snapshot.sensor_samples != last_samples        /* !=：比较是否不同。 */
condition_a && condition_b                     /* &&：两个条件同时成立。 */
```

打印前的 `(unsigned long)` 是类型转换，让 `%lu` 的格式与实际参数类型相符；`snprintf(line, sizeof(line), ...)` 用缓冲区长度限制写入。串口函数会复制文本到发送队列，局部 line 返回后不需要继续保存。

## 5. 把正式 main 拆成三段

### 第一段：先建立条件

```c
AppParams params;
board_init();
uint8_t loaded = settings_load(&params);
motor_init(&params);
as5600_init();
ir_receiver_init();
console_init();
```

| 调用 | 作用 | 顺序依据 |
| --- | --- | --- |
| board_init | GPIO、时基、串口、PWM/ADC 与定时器配置 | 后续模块要用这些底层资源 |
| settings_load | 填好参数对象 | motor_init 需要输入参数 |
| motor_init | 建立 STOP，复位控制/跟踪/偏置状态 | 采样中断开始前要有完整状态 |
| as5600_init | 准备编码器总线 | TIM4 周期读角前要先准备总线 |
| ir_receiver_init | 配置红外输入捕获 | 主循环随后消费事件 |
| console_init | 初始化命令解析状态，输出版本提示 | UART 硬件已由 board_init 配好 |

注意：board_init 结束时 SysTick、串口和 TIM3 已可工作；TIM2/TIM4 控制触发尚未启动。不要概括成“初始化期间所有中断都关闭”。

### 第二段：启动周期任务，再初始化交互与看门狗

```c
board_start_control();
ui_init();
board_watchdog_start();
```

board_start_control 启动 TIM2/TIM4 与 ADC 外部触发，不主动置高 PA8。采样计数和反馈开始推进，电机仍为 STOP。

ui_init 根据刚刚加载的屏幕配置初始化显示。当前样机已保存 SSD1306 兼容配置；正式版 1.1.6 的默认值也为 SSD1306。已有 Flash 参数优先于默认值，不能认为“改了宏就自动覆盖旧设置”。

看门狗在这些初始化之后启动。控制采样先于显示初始化开启，所以此时控制相关中断已经可以抢占显示初始化。

### 第三段：循环处理交互与存活检查

```c
console_poll();
ui_poll();
/* 到检查时刻时读取状态快照、决定是否喂狗。 */
```

正式入口与学习入口都在主循环调用 console_poll 和 ui_poll，分别处理串口以及遥控和界面。

## 6. while 不调用 FOC，控制为何仍执行？

```mermaid
flowchart TD
    PWM[TIM2 15 kHz] --> ADC[ADC 注入转换完成]
    ADC --> A[ADC1_2_IRQHandler → motor_adc_isr]
    A --> P[每 5 帧发布采样并挂起 PendSV]
    P --> C[PendSV_Handler → motor_current_task]
    T[TIM4 1 kHz] --> S[as5600_sample → motor_sensor_isr]
    S --> F[角度与速度反馈；分频更新外环]
    F --> C
    U[USART1 中断] --> Q[串口字节队列]
    I[TIM3 红外中断] --> R[遥控事件队列]
    Q --> M[main 中 console_poll / ui_poll]
    R --> M
    M --> D[目标设置与 OLED 分块刷新]
```

| 工作 | 本项目入口 | 配置频率/周期 | 第一课记住什么 |
| --- | --- | --- | --- |
| PWM 载波 | TIM2 | 15 kHz，约 66.7 μs | 硬件重复生成波形 |
| 两相 ADC | ADC1_2_IRQHandler | 15 kHz | 采样、偏置、原始过流检查，每 5 帧发布一次 |
| 电流任务 | PendSV_Handler | 目标 3 kHz，约 333 μs | 完成坐标变换、控制、调制与 PWM 更新 |
| 角度任务 | TIM4_IRQHandler | 1 kHz，1 ms | 状态+原始角度一次连续读，再更新反馈与外环 |
| 速度目标/速度环 | motor_sensor_isr 内分频 | 500 Hz，2 ms | 根据所选模式生成 Iq 请求 |
| 位置环 | motor_sensor_isr 内分频 | 100 Hz，10 ms | 位置模式下生成速度目标 |
| 常规串口遥测 | console_poll | 约 10 Hz | 显示状态，不代表控制只在打印时执行 |
| OLED 生成新画面 | ui_poll | 上限约 5 Hz | 每轮发送一小块数据 |
| 本课 L1 日志 | 学习入口 | 约 1 Hz | 帮助观察任务计数 |

这些是设计配置，运行频率和执行耗时仍需测量。STOP 时任务依然执行，但电流任务不会按 RUN 状态计算并输出闭环驱动。计数增加不等于电机已使能。

优先级数值越小越高：ADC=0，USART1=1，PendSV=2，TIM4/红外=3，SysTick=4。PendSV 是 Cortex-M 内核异常，本项目用它承接控制工作，并未运行 RTOS。

在 [board.c](../../BSP/board.c) 找 ADC、PendSV、TIM4、USART1 的处理函数；TIM3 红外处理函数在 [ir_receiver.c](../../BSP/ir_receiver.c)。中断实现不要求一定放在名为 stm32f10x_it.c 的文件中，名字、向量表、链接及外设使能要对应。

## 7. 用一个真实问题理解协作

你已经遇到过“菜单能操作，电机却不转”。要分别查：

1. **输入是否到了？** 串口是否出现 `IR addr=... cmd=...`？
2. **目标是否改变？** 屏幕 REF 是否变为 5？
3. **状态是否允许驱动？** STOP、RUN 还是 FAULT？
4. **执行链是否满足条件？** mag、off、cal、fault、timing 是什么？
5. **实际反馈是什么？** RPM 和位置是否变化？

REF=5 不能证明电机已经达到 5 rpm；OLED 有 I²C 应答也不能证明画面已经点亮。参数有效、任务存活、输入被接受、控制效果是不同层面的证据。

1.1.6 已把 AS5600 状态与角度合并为一次连续读取，替换旧的每 100 帧追加状态事务。第一课只需要知道这个改变发生在 BSP/board.c → as5600_sample，具体寄存器与时序在编码器课程展开。

## 8. 看门狗为什么检查两个计数？

```c
if (snapshot.sensor_samples != last_sensor_samples &&
    snapshot.current_steps != last_current_steps)
{
    board_watchdog_feed();
}
```

- sensor_samples：角度任务进入次数，不等于有效角度次数。
- current_steps：独立电流任务执行次数，偏置无效时也继续维护心跳。
- 两者均与上次不同，说明两类任务都在推进；main 仅仅还能循环不足以说明它们都活着。
- 是否能用于控制仍由 sensor_ok、magnet_ok、offsets_ready 等状态判断。

本工程看门狗按 LSI 标称频率估算超时约 1 秒，主循环约每 100 ms 检查一次。100 ms 是检查周期，不是看门狗超时时间，也不是电流控制周期。

## 9. 准备写代码：先写动作，再换成函数

合上完整参考，先完成以下伪代码。此时不要求从头写驱动。

```text
声明参数对象和需要跨循环记忆的变量
初始化板级资源
读取有效参数；无有效记录则生成默认参数
用参数初始化电机模块
准备编码器与遥控输入
初始化命令交互并打印本课标记
启动周期采样
初始化界面并启动看门狗
循环：
    处理串口与菜单
    取得当前毫秒计数
    每至少 100 ms 检查任务计数并决定是否喂狗
    每至少 1000 ms 输出一次 L1 状态
```

遇到不知道如何调用的动作，按下面三问落笔：

1. 需要传入什么？例如 motor_init 需要参数对象地址。
2. 函数返回什么？例如 settings_load 返回参数来源。
3. 状态放在哪里，下次还要不要用？例如 last_report_ms 要保留上一轮时刻。

### 先补这两个空

```c
AppParams params;
uint8_t loaded = settings_load(/* A：传入什么？ */);

/* now/last_report_ms 都是 uint32_t，单位 ms。 */
if (/* B：每至少 1000 ms 进入一次 */)
{
    last_report_ms = now;
    MotorStatus snapshot;
    motor_snapshot(&snapshot);
    lesson_report(now, &snapshot);
}
```

A 的参考为 `&params`；B 的参考为 `(uint32_t)(now - last_report_ms) >= 1000u`。写对后再对照完整入口，重点检查语句的顺序。

## 10. 完整中文注释代码

以下内容与本目录 main.c 一致，复用实际工程模块，不含占位函数。学习工程只链接这个入口。

```c
/*
 * 第一课：读懂 main，组织初始化顺序与前后台任务。
 * 对应 v1.1.7：无旋钮，SSD1306 兼容 OLED、红外遥控与串口。
 * 本文件复用现有项目的真实驱动与控制代码，不在此重复实现 FOC。
 * 使用工程根目录 ControlPanel_Learning.uvprojx 编译，避免同时链接两个 main。
 */
#include "board.h"       /* 板级初始化、毫秒时基、控制外设启动和看门狗接口 */
#include "params.h"      /* AppParams 参数结构体的定义 */
#include "settings.h"    /* 从 Flash 读取参数；无有效记录时填入默认参数 */
#include "motor.h"       /* 电机状态机、控制初始化和状态快照 */
#include "as5600.h"      /* 编码器总线初始化 */
#include "ir_receiver.h" /* 红外输入捕获初始化 */
#include "console.h"     /* 串口命令和状态输出 */
#include "ui.h"          /* OLED 页面、遥控菜单及后台刷新 */
#include "oled.h"        /* 只查询显示通信是否可用，不在本课重写显示驱动 */
#include <stdio.h>       /* snprintf：把状态整理成一行有长度限制的文本 */

/* static 表示本函数只在当前 .c 文件内使用。
 * const MotorStatus *s：通过指针读取快照，不在这里修改快照内容。
 * 这条学习日志约每秒输出一次，打印计数不代表已经使能功率桥。
 */
static void lesson_report(uint32_t now, const MotorStatus *s)
{
    char line[160];
    /* Cortex-M3/本工程中 unsigned long 为 32 位。
     * %lu 对应 unsigned long，显式转换使格式与参数类型一致。
     * %s 对应字符串；motor_state_name 将枚举转换成 STOP/RUN 等文字。
     */
    (void)snprintf(line, sizeof(line),
                   "L1 t_ms=%lu st=%s sensor=%lu current=%lu oled=%u\r\n",
                   (unsigned long)now, motor_state_name(s->state),
                   (unsigned long)s->sensor_samples, (unsigned long)s->current_steps,
                   (unsigned)oled_available());
    console_message(line); /* 复制到串口发送队列，再由 USART 中断逐字节发送 */
}

int main(void)
{
    /* params 是一组电压、电流、速度限值、PID 增益和校准结果。
     * 这条声明本身没有初始化局部对象；后面的 settings_load 负责完整赋值。 */
    AppParams params;
    uint8_t loaded;

    /* 这些变量放在循环外初始化一次，保留上一轮观察到的状态。
     * 毫秒时基负责“何时检查”，计数器负责“任务是否仍在推进”。 */
    uint32_t last_watchdog_ms = 0u;
    uint32_t last_sensor_samples = 0u;
    uint32_t last_current_steps = 0u;
    uint32_t last_report_ms = 0u; /* 学习日志自己的时间基准，不复用看门狗时间基准 */

    /* 第一步：先建立硬件运行条件。
     * PA8 先置低，再配置为输出；同时配置 GPIO、SysTick、串口、PWM 和 ADC。
     * 此时 TIM2/TIM4 尚未启动，PA8 仍为低；SysTick/串口及 TIM3 已可工作。
     * 因此不能把“控制触发尚未启动”解释成“所有中断都关闭”。 */
    board_init();

    /* &params 表示把对象地址交给函数，让函数填写这个对象。
     * loaded=1：采用有效 Flash 参数；loaded=0：采用默认参数，并非没有参数。 */
    loaded = settings_load(&params);

    /* 先把参数复制进控制模块，建立 STOP 状态、清控制器历史，再允许采样中断工作。 */
    motor_init(&params);

    /* 先准备 AS5600 的软件 I²C，再启动后面的周期读角任务。
     * v1.1.7 的 TIM4 中使用 as5600_sample 一次读取磁场状态及原始角度。
     * 红外初始化配置 PB4/TIM3_CH1，遥控事件由主循环中的 ui_poll 消费。 */
    as5600_init();
    ir_receiver_init();

    /* 串口硬件已经在 board_init 中初始化；这里启动应用层交互提示。 */
    console_init();
    console_message("Lesson01 v1.1.7: remote + UART; L1 report every 1 s\r\n");
    if (loaded)
        console_message("Settings loaded; still STOPPED\r\n");
    else
        console_message("Defaults loaded; calibration required\r\n");

    /* 开启 TIM2 PWM 触发 ADC，以及 TIM4 的周期角度任务。
     * “采样开始”与“使能功率桥”是不同操作；这里不执行 run 或 cal。 */
    board_start_control();

    /* 生成 OLED 初始页面。控制中断已能抢占初始化/刷新过程。
     * 屏幕不在线时，项目仍可通过串口观察和操作。 */
    ui_init();

    /* 初始化完成后启动看门狗。主循环每约 100 ms 检查采样/控制计数是否变化。 */
    board_watchdog_start();
    last_watchdog_ms = board_millis();
    last_report_ms = last_watchdog_ms;

    while (1)
    {
        /* 主循环依次处理低速交互任务：解析命令、安排遥测发送、消费遥控事件、刷新 OLED。
         * 电流环和角度任务由中断触发，不由这两行函数决定执行频率。 */
        console_poll();
        ui_poll();

        /* 读取毫秒计数本身不等待；此处没有 Delay_ms(100)。 */
        uint32_t now = board_millis();

        /* 先做 uint32_t 无符号差，再与 100 ms 比较，兼容计数自然回绕。
         * 主循环检查周期是“至少 100 ms”，会受到本轮交互任务耗时影响。 */
        if ((uint32_t)(now - last_watchdog_ms) >= 100u)
        {
            last_watchdog_ms = now;

            /* 快照函数在短临界区内复制共享状态，避免读到中断更新一半的数据。
             * &snapshot 传递输出对象地址，snapshot.xxx 访问其中一个成员。 */
            MotorStatus snapshot;
            motor_snapshot(&snapshot);

            /* 两类计数都在增长才喂狗；仅仅主循环还能转，不能代表采样任务正常。
             * 该检查关注任务存活，真实执行周期和控制效果由后续测量验证。 */
            if (snapshot.sensor_samples != last_sensor_samples &&
                snapshot.current_steps != last_current_steps)
            {
                board_watchdog_feed();
            }

            last_sensor_samples = snapshot.sensor_samples;
            last_current_steps = snapshot.current_steps;
        }

        /* 另一项后台任务：至少间隔 1000 ms 输出一次学习日志。
         * 计时检查本身不等待，不改变 TIM2/TIM4 的 PSC、ARR 或控制频率。
         * log 0 只关闭正式的 10 Hz 遥测，本课 L1 日志仍每秒输出。
         */
        if ((uint32_t)(now - last_report_ms) >= 1000u)
        {
            last_report_ms = now;
            MotorStatus snapshot;
            motor_snapshot(&snapshot);
            lesson_report(now, &snapshot);
        }
    }
}
```

## 11. 编译与一次代表性观察

### 11.1 编译

打开 `ControlPanel_Learning.uvprojx`，Target 选择 **Lesson01_NoKnob**，编译器为本机 ARM Compiler 6.18。

- 本课入口：Learning/Lesson01/main.c。
- 输出：Objects/Lesson01/Lesson01_NoKnob.hex。
- 正式控制台入口是 App/main.c，两个入口不能同时加入同一个 Target。
- 学习 HEX 与正式 Firmware/ControlPanel.hex 是不同输出。本课新增的 L1 行只在学习入口中存在。

本课不要求重新校准或重新整定 PID。参数读取仍使用现有 Flash 记录，上电初始仍为 STOP。后续若下载学习 HEX，先确认 `Lesson01 v1.1.7` 启动标记。

### 11.2 怎样读本课新增日志

格式示例，**以下数字仅用于解释字段，不是本轮上板实测记录**：

```text
L1 t_ms=1200 st=STOP sensor=1000 current=3000 oled=1
L1 t_ms=2200 st=STOP sensor=2000 current=6000 oled=1
```

| 字段 | 含义 | 从两行示例能说明什么？ |
| --- | --- | --- |
| t_ms | 毫秒时基 | 两次观察间隔 1000 ms |
| st | 运行状态 | 仍为 STOP |
| sensor | 累计进入角度任务的次数 | 示例中增加 1000 |
| current | 累计执行电流任务的次数 | 示例中增加 3000 |
| oled | 最近一次显示初始化/传输可用标志 | 不能单凭 1 证明肉眼画面正确 |

用“计数差÷实际时间差”估算观察区间内的平均执行频率，不用第一帧总数直接除以 1 秒。STOP 时两类计数继续增加，就是本课要观察的关键现象。

常规 `t=...` 遥测仍由 console_poll 约每 100 ms 输出。发送 `log 0` 会暂停这些常规行，但 L1 行仍每秒出现；串口命令、采样和控制任务也没有因此关闭。

### 11.3 一个小练习

只把学习日志的 `1000u` 改为 `500u`，重新编译。预期是 L1 行约每 0.5 秒出现一次，每两行之间的任务计数差约减半。TIM2、TIM4 和电流控制的配置频率都不变。

完成后恢复为 1000u。把“修改了什么、预期什么、实际观察什么”写成三句话即可，本课不增加转动实验。

## 12. 自测题

先写答案，再看下一节。

1. settings_load 返回 0 后，为什么还能调用 motor_init(&params)？
2. motor_init 与 as5600_init 为什么在 board_start_control 之前？
3. board_init 结束后，能否说所有中断都还没开始？
4. main 没调用 motor_current_task，它由谁触发？从 ADC 开始写出调用链。
5. STOP、sensor 增加、current 增加能否同时成立？
6. SPEED STOP 和 CURRENT PID 同时显示，是否表示程序模式混乱？
7. 把 L1 输出周期从 1000 ms 改为 500 ms，会不会把电流环变成 2 Hz？
8. last=4294967290、now=14，uint32_t 时间差是多少？
9. sensor_samples 增加，能否证明每次传感器读取都有效？
10. REF=5、cal=1 能否证明电机正在以 5 rpm 转动？还要看什么？

## 13. 参考答案与完成标准

1. 返回值说明配置来源；函数在返回 0 前已经填入默认参数。
2. 周期任务运行前必须先建立控制状态并准备通信总线。
3. 不能。SysTick、串口及 TIM3 已可工作；控制 TIM2/TIM4 在后面启动。
4. ADC1_2_IRQHandler→motor_adc_isr→每 5 帧发布采样并请求 PendSV→PendSV_Handler→motor_current_task。
5. 可以。停机不关闭正常采样/计数，计数增长不等于功率桥使能。
6. 正常。前者是模式与状态，后者是参数页面。
7. 不会。只改变后台日志安排，硬件触发及控制分频保持原值。
8. 20 ms。
9. 不能，它统计任务进入次数；读取有效性、磁场与累计错误另行检查。
10. 不能。看 state/fault 与实际 RPM、位置变化，必要时结合物理转动观察。

完成本课的标准：

- 能不看参考写出 main 的主要调用顺序。
- 能画出 ADC→PendSV 与 TIM4→读角两条路径。
- 能区分参数来源、校准有效、控制模式、显示页面和运行状态。
- 学习工程编译零错误；知道新增 L1 与正式遥测的区别。

## 14. 求职积累与下一课

保留你自己的启动图、任务频率表、修改后的学习入口和一段一分钟讲解。可以这样开始复述，再换成自己的话：

> 我的项目采用裸机主循环与中断协作。上电先准备板级资源、装入参数并建立停机状态，再启动 PWM 同步采样。ADC 发布采样，由 PendSV 执行电流控制；TIM4 负责角度和外环。主循环处理串口、红外菜单与 OLED。参数保存不会自动恢复运行状态，任务心跳也不等于反馈一定有效。

这是一课读懂的架构，不等于已经独立实现了所有控制模块。后续按你亲手完成的代码、调试和实测补充个人贡献。

**下一课：board_init 与 STM32 时钟/GPIO。** 从实际的 72 MHz、APB 定时器时钟、PA8 输出初值、推挽/开漏和外设复用开始。
