/*
 * 第一课：读懂 main，组织初始化顺序与前后台任务。
 * 对应 v1.1.7：无旋钮，SSD1306 兼容 OLED、红外遥控与串口。
 * 本文件复用现有项目的真实驱动与控制代码，不在此重复实现 FOC。
 * 使用工程根目录 ControlPanel_Learning.uvprojx 编译，避免同时链接两个 main。
 */
#include "board.h"       /* 板级初始化、毫秒时基、控制外设启动和看门狗接口 */
#include "params.h"      /* AppParams 参数结构体的定义 */
#include "settings.h"    /* 从 Flash 读取参数；无有效记录时填入默认参数 */
#include "motor.h"       /* 电机状态机、控制初始化和状态快照 */
#include "as5600.h"      /* 编码器总线初始化 */
#include "ir_receiver.h" /* 红外输入捕获初始化 */
#include "console.h"     /* 串口命令和状态输出 */
#include "ui.h"          /* OLED 页面、遥控菜单及后台刷新 */
#include "oled.h"        /* 只查询显示通信是否可用，不在本课重写显示驱动 */
#include <stdio.h>       /* snprintf：把状态整理成一行有长度限制的文本 */

/* static 表示本函数只在当前 .c 文件内使用。
 * const MotorStatus *s：通过指针读取快照，不在这里修改快照内容。
 * 这条学习日志约每秒输出一次，打印计数不代表已经使能功率桥。
 */
static void lesson_report(uint32_t now, const MotorStatus *s)
{
    char line[160];
    /* Cortex-M3/本工程中 unsigned long 为 32 位。
     * %lu 对应 unsigned long，显式转换使格式与参数类型一致。
     * %s 对应字符串；motor_state_name 将枚举转换成 STOP/RUN 等文字。
     */
    (void)snprintf(line, sizeof(line),
                   "L1 t_ms=%lu st=%s sensor=%lu current=%lu oled=%u\r\n",
                   (unsigned long)now, motor_state_name(s->state),
                   (unsigned long)s->sensor_samples, (unsigned long)s->current_steps,
                   (unsigned)oled_available());
    console_message(line); /* 复制到串口发送队列，再由 USART 中断逐字节发送 */
}

int main(void)
{
    /* params 是一组电压、电流、速度限值、PID 增益和校准结果。
     * 这条声明本身没有初始化局部对象；后面的 settings_load 负责完整赋值。 */
    AppParams params;
    uint8_t loaded;

    /* 这些变量放在循环外初始化一次，保留上一轮观察到的状态。
     * 毫秒时基负责“何时检查”，计数器负责“任务是否仍在推进”。 */
    uint32_t last_watchdog_ms = 0u;
    uint32_t last_sensor_samples = 0u;
    uint32_t last_current_steps = 0u;
    uint32_t last_report_ms = 0u; /* 学习日志自己的时间基准，不复用看门狗时间基准 */

    /* 第一步：先建立硬件运行条件。
     * PA8 先置低，再配置为输出；同时配置 GPIO、SysTick、串口、PWM 和 ADC。
     * 此时 TIM2/TIM4 尚未启动，PA8 仍为低；SysTick/串口及 TIM3 已可工作。
     * 因此不能把“控制触发尚未启动”解释成“所有中断都关闭”。 */
    board_init();

    /* &params 表示把对象地址交给函数，让函数填写这个对象。
     * loaded=1：采用有效 Flash 参数；loaded=0：采用默认参数，并非没有参数。 */
    loaded = settings_load(&params);

    /* 先把参数复制进控制模块，建立 STOP 状态、清控制器历史，再允许采样中断工作。 */
    motor_init(&params);

    /* 先准备 AS5600 的软件 I²C，再启动后面的周期读角任务。
     * v1.1.7 的 TIM4 中使用 as5600_sample 一次读取磁场状态及原始角度。
     * 红外初始化配置 PB4/TIM3_CH1，遥控事件由主循环中的 ui_poll 消费。 */
    as5600_init();
    ir_receiver_init();

    /* 串口硬件已经在 board_init 中初始化；这里启动应用层交互提示。 */
    console_init();
    console_message("Lesson01 v1.1.7: remote + UART; L1 report every 1 s\r\n");
    if (loaded)
        console_message("Settings loaded; still STOPPED\r\n");
    else
        console_message("Defaults loaded; calibration required\r\n");

    /* 开启 TIM2 PWM 触发 ADC，以及 TIM4 的周期角度任务。
     * “采样开始”与“使能功率桥”是不同操作；这里不执行 run 或 cal。 */
    board_start_control();

    /* 生成 OLED 初始页面。控制中断已能抢占初始化/刷新过程。
     * 屏幕不在线时，项目仍可通过串口观察和操作。 */
    ui_init();

    /* 初始化完成后启动看门狗。主循环每约 100 ms 检查采样/控制计数是否变化。 */
    board_watchdog_start();
    last_watchdog_ms = board_millis();
    last_report_ms = last_watchdog_ms;

    while (1)
    {
        /* 主循环依次处理低速交互任务：解析命令、安排遥测发送、消费遥控事件、刷新 OLED。
         * 电流环和角度任务由中断触发，不由这两行函数决定执行频率。 */
        console_poll();
        ui_poll();

        /* 读取毫秒计数本身不等待；此处没有 Delay_ms(100)。 */
        uint32_t now = board_millis();

        /* 先做 uint32_t 无符号差，再与 100 ms 比较，兼容计数自然回绕。
         * 主循环检查周期是“至少 100 ms”，会受到本轮交互任务耗时影响。 */
        if ((uint32_t)(now - last_watchdog_ms) >= 100u)
        {
            last_watchdog_ms = now;

            /* 快照函数在短临界区内复制共享状态，避免读到中断更新一半的数据。
             * &snapshot 传递输出对象地址，snapshot.xxx 访问其中一个成员。 */
            MotorStatus snapshot;
            motor_snapshot(&snapshot);

            /* 两类计数都在增长才喂狗；仅仅主循环还能转，不能代表采样任务正常。
             * 该检查关注任务存活，真实执行周期和控制效果由后续测量验证。 */
            if (snapshot.sensor_samples != last_sensor_samples &&
                snapshot.current_steps != last_current_steps)
            {
                board_watchdog_feed();
            }

            last_sensor_samples = snapshot.sensor_samples;
            last_current_steps = snapshot.current_steps;
        }

        /* 另一项后台任务：至少间隔 1000 ms 输出一次学习日志。
         * 计时检查本身不等待，不改变 TIM2/TIM4 的 PSC、ARR 或控制频率。
         * log 0 只关闭正式的 10 Hz 遥测，本课 L1 日志仍每秒输出。
         */
        if ((uint32_t)(now - last_report_ms) >= 1000u)
        {
            last_report_ms = now;
            MotorStatus snapshot;
            motor_snapshot(&snapshot);
            lesson_report(now, &snapshot);
        }
    }
}
