/*
 * 第五课：实际定时与 ADC 初始化模块。
 * 配置逻辑与正式 board.c 的 pwm_adc_init 一致，只增加知识点注释。
 * 生成的 board_lesson05.c 调用本函数，其他板级实现仍与正式版本一致。
 */
#include "lesson05_timing.h"
#include "board.h"
#include "app_config.h"
#include "console.h"
#include <stdio.h>

void lesson05_timing_init(void)
{
    TIM_TimeBaseInitTypeDef t;
    TIM_OCInitTypeDef oc;
    ADC_InitTypeDef a;
    NVIC_InitTypeDef n;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 | RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    /* TIM2 输入 72 MHz：fPWM=72000000/((0+1)×(4799+1))=15 kHz。 */
    /* 标准库补齐未显式赋值的字段：向上计数、CKD=DIV1。
     * 对象 t 可重复用来配置不同定时器，但每次要明确修改本次不同的字段。
     */
    TIM_TimeBaseStructInit(&t);
    t.TIM_Period = BOARD_PWM_COUNTS - 1u;
    t.TIM_Prescaler = 0;
    TIM_TimeBaseInit(TIM2, &t);
    /* 补齐比较结构体，默认输出有效极性为高。
     * TIM2 是通用定时器，本例不配置 TIM1 的互补输出/死区功能。
     */
    TIM_OCStructInit(&oc);
    oc.TIM_OCMode = TIM_OCMode_PWM1;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    oc.TIM_Pulse = 0;
    TIM_OC1Init(TIM2, &oc);
    TIM_OC2Init(TIM2, &oc);
    TIM_OC3Init(TIM2, &oc);
    /* CCR 预装载：软件先写待用值，更新事件再送入实际比较逻辑。
     * ARR 预装载是另一组配置；不要把两者当成一个开关。
     */
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
    /* CH4 在 CNT=4400（约 61.1 μs）触发 ADC，避开 50% 附近的三相开关沿。
     * 参数限制电压幅值不超过母线 25%，最高相占空比不超过 75%：
     * 最晚开关约在 50 μs，采样前留约 11.1 μs，两个 ADC 转换约 3.33 μs，
     * 仍早于下周期 66.7 μs 的开关。PA3 保持 GPIO 低，不输出 CH4 波形。 */
    oc.TIM_OCMode = TIM_OCMode_PWM2;
    oc.TIM_Pulse = BOARD_ADC_TRIGGER_TICKS;
    TIM_OC4Init(TIM2, &oc);
    /* TRGO 选择内部 OC4REF，不需要将 CH4 复用输出到 PA3。
     * PWM2 在 CNT 到 CCR4 时从无效变有效，给 ADC 提供内部上升沿。
     */
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_OC4Ref);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    ADC_StructInit(&a);
    a.ADC_Mode = ADC_Mode_Independent;
    a.ADC_ScanConvMode = ENABLE;
    a.ADC_ContinuousConvMode = DISABLE;
    a.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    a.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &a);
    /* 注入组依次采 PB0/ADC_IN8、PB1/ADC_IN9；不沿用旧例程的自由连续转换。 */
    /* 一次触发按 rank1、rank2 顺序转换，不是两路同时采样。
     * 规则组结构体的 NbrOfChannel=1 不决定注入组长度，这里单独设为 2。
     */
    ADC_InjectedSequencerLengthConfig(ADC1, 2);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_7Cycles5);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_9, 2, ADC_SampleTime_7Cycles5);
    ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_T2_TRGO);
    /* 电流采样仅使用注入组，由 TIM2 事件触发。 */
    ADC_Cmd(ADC1, ENABLE);
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1))
    {
    }
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1))
    {
    }
    ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
    /* JEOC 表示本次注入序列完成。ADC 中断取 JDR1/JDR2 后才发布数据。
     * ADC 每 PWM 周期处理一次，但控制任务每五次才请求一次。
     */
    ADC_ITConfig(ADC1, ADC_IT_JEOC, ENABLE);
    n.NVIC_IRQChannel = ADC1_2_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 0;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
    /* TIM3：72 MHz/(71+1)=1 MHz，每计数 1 μs，供红外输入捕获使用。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 65535;
    TIM_TimeBaseInit(TIM3, &t);
    TIM_Cmd(TIM3, ENABLE);
    /* TIM4：1 MHz/(999+1)=1 kHz，每 1 ms 触发一次角度任务。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 999;
    TIM_TimeBaseInit(TIM4, &t);
    /* 时基初始化可能产生更新标志；先清掉，避免开启后把旧标志当新节拍。
     * TIM_ITConfig、NVIC_Init、TIM_Cmd 分别控制中断源、NVIC 通路和计数器。
     */
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    n.NVIC_IRQChannel = TIM4_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_Init(&n);
    /* 此处不启动 TIM2/TIM4；board_start_control 统一启用触发与计数器。 */
}

/* 向上、边沿对齐定时器的配置推算。先转 float 避免整数除法截断和乘积溢出。
 * 这不是通过 GPIO 或示波器测出的实际频率，不能据此证明中断都按时处理。
 */
float lesson05_timer_hz(uint32_t timer_clock, uint16_t psc, uint16_t arr)
{
    return (float)timer_clock / ((float)psc + 1.0f) / ((float)arr + 1.0f);
}

void lesson05_print_config(void)
{
    RCC_ClocksTypeDef clocks;
    RCC_GetClocksFreq(&clocks);
    /* 本工程使用内部 APB1 时钟；PCLK1 不是 HCLK 时，APB1 有分频，定时器乘 2。 */
    uint32_t timer_clock = clocks.PCLK1_Frequency;
    if (clocks.PCLK1_Frequency != clocks.HCLK_Frequency)
        timer_clock *= 2u;
    char line[160];
    (void)snprintf(line, sizeof(line),
                   "L5 CONFIG timclk=%lu adcclk=%lu current_div=%u\r\n",
                   (unsigned long)timer_clock, (unsigned long)clocks.ADCCLK_Frequency,
                   (unsigned)BOARD_CURRENT_DIV);
    console_message(line);
    /* 标准库没有独立的 PSC/ARR 读取接口，下面只读 CMSIS 寄存器字段用于观察。
     * 外设配置仍由上面的标准库函数完成，不使用 HAL。
     */
    (void)snprintf(line, sizeof(line),
                   "L5 TIM2 psc=%u arr=%u hz=%lu ccr4=%u\r\n",
                   (unsigned)TIM2->PSC, (unsigned)TIM2->ARR,
                   (unsigned long)(lesson05_timer_hz(timer_clock, (uint16_t)TIM2->PSC,
                                                   (uint16_t)TIM2->ARR) + 0.5f),
                   (unsigned)TIM_GetCapture4(TIM2));
    console_message(line);
    (void)snprintf(line, sizeof(line),
                   "L5 TIM4 psc=%u arr=%u hz=%lu\r\n",
                   (unsigned)TIM4->PSC, (unsigned)TIM4->ARR,
                   (unsigned long)(lesson05_timer_hz(timer_clock, (uint16_t)TIM4->PSC,
                                                   (uint16_t)TIM4->ARR) + 0.5f));
    console_message(line);
}
