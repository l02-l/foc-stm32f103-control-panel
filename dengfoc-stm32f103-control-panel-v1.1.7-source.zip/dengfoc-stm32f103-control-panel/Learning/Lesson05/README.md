# 第五课：PWM、同步采样与多速率任务调度

日期：2026-11-05。基线：**v1.1.7，无旋钮，STM32F103C8T6 标准外设库**。建议 10～12 小时，分三次完成。

## 0. 本课目标与代码入口

第四课知道了角度反馈怎样产生。本课把整机放进一张时间表，回答：**电机的 PWM、ADC、控制运算、读角和打印，分别由谁触发，为什么不使用同一个频率？**

学习产出：

1. 能从 PSC、ARR、CCR 算出 PWM 周期、占空比和 ADC 触发时刻。
2. 能解释 CCR 预装载及更新事件。
3. 能沿 TIM2→ADC→PendSV 说明采样与电流控制的关系。
4. 能解释 TIM4 的 1 kHz、速度环 500 Hz、位置环 100 Hz 和串口约 10 Hz。
5. 能写出 TIM4 配置，读懂优先级、计数差和耗时预算。

| 文件 | 本课用途 |
| --- | --- |
| [正式 BSP/board.c](../../BSP/board.c) | pwm_adc_init、board_pwm、控制启动、中断入口 |
| [lesson05_timing.c](lesson05_timing.c) / [头文件](lesson05_timing.h) | 详细中文注释的实际初始化，配置查询与频率计算 |
| [board_lesson05.c](board_lesson05.c) | 从正式 board 生成，初始化调用接入本课模块 |
| [Control/motor.c](../../Control/motor.c) | 采样发布、current_sequence、电流任务与外环分频 |
| [Config/app_config.h](../../Config/app_config.h) | PWM、控制分频与预算配置 |
| [main.c](main.c) | 复用实际任务，每秒观察一次计数差 |
| [第五课 Keil 工程](../../ControlPanel_Lesson05.uvprojx) | Target 为 Lesson05_NoKnob |
| [编译记录](build.log) | ARM Compiler 6.18，0 错误、0 警告 |

本轮已编译课程，**尚未烧录、测量 PWM 波形或实测 L5 日志**。下文时间值由当前配置推算，日志是预期格式。课程工程复用实际控制代码，正式工程保持原样。

建议三次学习：先学第 1～6 节的定时器和预装载，再学第 7～12 节的触发与调度，最后读完整代码、完成 TIM4 练习与自测。

## 1. 先看整张时间表

| 对象 | 正常配置频率 | 标称间隔 | 触发来源/执行位置 |
| --- | ---: | ---: | --- |
| 三相 PWM 载波 | 15 kHz | 66.667 μs | TIM2 硬件计数与比较，PA0/PA1/PA2 |
| 两相电流采样序列 | 15 kHz | 66.667 μs | TIM2_CH4 内部 OC4REF→TRGO→ADC1 注入组 |
| 电流任务请求 | 3 kHz | 333.333 μs | ADC 中断每 5 帧发布，PendSV 执行 |
| AS5600 角度任务 | 1 kHz | 1 ms | TIM4 更新中断 |
| 速度环/电流目标更新 | 500 Hz | 2 ms | RUN 时角度任务每 2 帧分频 |
| 位置环 | 100 Hz | 10 ms | RUN 且位置模式时每 10 帧分频 |
| 常规串口遥测 | 约 10 Hz | 至少约 100 ms | 主循环 console_poll 时间检查 |
| OLED 新画面组织 | 最快约 5 Hz | 至少约 200 ms | 主循环 ui_poll，分块发送 |
| 本课 L5 观察 | 约 1 Hz | 至少约 1000 ms | 主循环，只读状态快照 |

表中是当前配置和正常任务处理条件下的节奏。STOP 下仍采电流、读角并进入电流任务，但不会完整执行运行中的 PI/PWM 更新；并非每项在所有状态都执行同样的工作。

两个核心区别：

- **载波在硬件中持续生成。** CPU 不必每 66.7 μs 用 GPIO 手动翻一次电平。
- **控制算法更新比较值。** 两次更新之间，硬件会按上一组有效比较值重复生成 PWM。

## 2. 定时器不是直接用 PSC 的数值除时钟

本机 SYSCLK/HCLK=72 MHz，PCLK1=36 MHz。APB1 分频为 2，因此 TIM2/3/4 输入为 2×PCLK1=72 MHz。

本课都是内部时钟、向上计数、边沿对齐：

\[
f_{CNT}=\frac{f_{TIM}}{PSC+1},\qquad
f_{period}=\frac{f_{TIM}}{(PSC+1)(ARR+1)}
\]

PSC 设置的是分频系数减一；CNT 从 0 经过 ARR，总共 ARR+1 个计数时间。

| 定时器 | PSC | ARR | 计数频率 | 计满周期/用途 |
| --- | ---: | ---: | ---: | --- |
| TIM2 | 0 | 4799 | 72 MHz | 4800/72 MHz≈66.667 μs，PWM 15 kHz |
| TIM3 | 71 | 65535 | 1 MHz | 65536 μs 回绕，用于红外捕获计时 |
| TIM4 | 71 | 999 | 1 MHz | 1000 μs，1 kHz 读角节拍 |

TIM3 的 **1 MHz 是计数频率**，不是当前启用了一百万次每秒的中断。它按红外输入捕获事件进入中断，计数器每步 1 μs。

标准库 `TIM_TimeBaseStructInit` 默认向上计数，`TIM_ClockDivision=TIM_CKD_DIV1`。CKD 字段关联定时器采样滤波等使用的 tDTS，不能把它当作 PSC 一样随意乘进上面的计数分频公式。

这些结论限于本课配置。以后改为中心对齐、外部时钟或其他芯片，需要重新按相应计数方式计算。寄存器机制依据 [ST RM0008：TIM2～TIM5 时基、PWM 和寄存器章节](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf)。

## 3. CNT、ARR、CCR 分别控制什么？

- CNT：当前走到哪一个计数位置。
- ARR：走到哪里结束一轮并回绕。
- CCR1/2/3：各相在一轮中何时改变输出。

本机 CH1/2/3 为 PWM1，有效高，向上计数时正常稳态高电平区间为 CNT<CCR：

\[
duty=\frac{CCR}{ARR+1}=\frac{CCR}{4800}
\]

| CCR | 稳态高电平计数数目 | 占空比 |
| ---: | ---: | ---: |
| 0 | 0 | 0% |
| 1200 | 1200 | 25% |
| 2400 | 2400 | 50% |
| 3600 | 3600 | 75% |
| 4800 | 4800 | 100% |

CNT 的正常范围虽然只有 0～4799，CCR 写 4800 仍有意义：整轮 CNT 都小于 CCR。不能把 CCR 也硬限制为 ARR，导致 100% 无法表示。[ST PWM1/PWM2 与比较寄存器规则](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)

这里只是在理解比较逻辑，**本课不把三相设置为 100% 来试转电机**。实际调制值来自控制层，不由观察代码改写。

占空比更新示例：如果有效 CCR 从 1200 变为 2400，载波仍为 15 kHz，只是每轮的高电平比例从 25% 变为 50%。改变转速目标不等于直接改变这个载波频率。

## 4. 三路共用一个 CNT；CH4 没有第四个计数器

```text
TIM2 共同的 CNT：0 ------------------------------------ 4799
                  |       |             |        |
CH1 PWM1          CCR1 决定 A 路比较位置
CH2 PWM1                  CCR2 决定 B 路比较位置
CH3 PWM1                                CCR3 决定 C 路比较位置
CH4 PWM2                                         CCR4=4400
                                                   ↓
                                              内部 ADC 触发
```

CH1/2/3 分别连接 PA0/PA1/PA2，用于 M0。CH4 只使用内部参考信号，**PA3 仍由 GPIO 固定为低，作为未使用 M1 的输入之一**。内部 OC4REF 可送 TRGO，不需要把 CH4 波形接到外部 PA3 才能触发 ADC。

TIM2 是通用定时器；本项目不是用它直接输出六路互补桥臂和死区波形。实际驱动板如何处理每相输入属于硬件路径，不应在此套用 TIM1 的六路互补配置。

PA8 是驱动使能，和 PWM 信号配置分开。启动 TIM2、产生 PA0 波形，不等于已经使能功率桥。

## 5. CCR 预装载：写入与生效不是同一时刻

控制运算可能在 PWM 一轮的中间完成。如果立即改变比较条件，当前脉冲可能被从中间改动。当前启用：

```c
TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
TIM_ARRPreloadConfig(TIM2, ENABLE);
```

CCR 预装载和 ARR 预装载各管各的字段。正常情况下：

```text
CPU 写新的 CCR 预装载值
 → 本轮仍按旧的有效比较值输出
 → 下一次更新事件 UEV
 → 预装载值进入有效比较逻辑
```

例如在一轮 30 μs 附近写 CCR=2400，若赶在下一次更新前完成，新值从下一轮生效；不是写函数返回后立即改变当前高低电平。

实际更新接口：

```c
void board_pwm(uint16_t a, uint16_t b, uint16_t c)
{
    TIM_SetCompare1(TIM2, a);
    TIM_SetCompare2(TIM2, b);
    TIM_SetCompare3(TIM2, c);
}
```

函数里三次写 CCR，不是重配 PSC/ARR，也没有等待下一轮。开启预装载时读 CCR 看到的是可访问的预装载值，不能把一次寄存器读取当作示波器证明“正在输出这一占空比”。

**预装载不自动让三次 CPU 写入变成不可分割的一次操作。** 如果更新事件恰好夹在三次写之间，新值可能跨两个更新边界生效。当前控制层短临界区防止 ADC 故障关桥与旧计算结果回写竞争，关中断本身并不会停止 TIM2 计数。理解这一边界即可，本课不另加同步改造与测试分支。

### 为什么有 board_pwm_latch？

```c
void board_pwm_latch(void)
{
    TIM_GenerateEvent(TIM2, TIM_EventSource_Update);
}
```

启动桥前，当前代码先写三路 2400，主动产生一次更新锁存，再置高 PA8。UG 还会影响计数器/分频器重新初始化，不能把它当作每次控制更新都要调用的普通“提交按钮”。正常连续调制通过自然更新事件生效。

## 6. 配置和启动：三个开关不能混淆

初始化只建立配置；随后统一启动：

```c
void board_start_control(void)
{
    ADC_ExternalTrigInjectedConvCmd(ADC1, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
    TIM_Cmd(TIM4, ENABLE);
}
```

对 TIM4 中断来说：

| 操作 | 控制的环节 |
| --- | --- |
| TIM_TimeBaseInit | 设置时基参数，初始化可能带来更新标志 |
| TIM_ClearITPendingBit | 清除已有标志，不等于启动计时 |
| TIM_ITConfig(...Update,ENABLE) | 打开外设更新中断源 |
| NVIC_Init | 设置 CPU 异常通路和优先级 |
| TIM_Cmd(...ENABLE) | 让计数器开始运行 |

同理，ADC 的时钟、校准、JEOC 中断、外部触发允许是不同环节。只做 `NVIC_Init` 不能凭空产生采样。TIM2 本课依靠硬件 PWM/触发，不需要每次溢出都进入一个 TIM2 软件中断。

## 7. 为什么用 CH4 在 CNT=4400 触发采样？

当前 CH4 设为 PWM2，CCR4=4400，TRGO 选择 OC4REF。向上计数中 OC4REF 在该比较点由低到高，ADC 注入组接收内部触发；它不是 `TIM_IT_CC4` 软件回调再去启动 ADC。

\[
t_{trigger}=\frac{4400}{72\times10^6}\approx61.111\ \mu s
\]

当前控制参数限定电压矢量幅值不超过母线的 25%，这套调制使相占空比处于约 25%～75%。按理想 PWM 时序推算：

```text
一轮开始      最晚相比较下降沿      CH4 触发       两次转换结束    下一轮
0 μs             ≤50 μs            61.111 μs      ≈64.444 μs     66.667 μs
                   └─约11.111 μs─┘                 └约2.222 μs┘
```

这让采样避开当前调制范围内主要开关沿。ADC 时钟为 PCLK2/6=12 MHz；每路采样时间设 7.5 周期，转换另需 12.5 周期：

\[
t_{one}=\frac{7.5+12.5}{12\times10^6}\approx1.667\ \mu s
\]

两路顺序转换约 3.333 μs。这是按转换周期算出的名义时间，实际窗口还涉及触发同步、模拟前端建立和开关瞬态，不能替代波形实测。ADC 周期公式、注入组外部触发与上升沿规则见 [ST RM0008 ADC 章节](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)。

PB0/ADC_IN8 是 rank1，PB1/ADC_IN9 是 rank2，**它们不是同一瞬间采样**。电流换算、零点和前端电路留到下一课。

如果擅自改变 PWM 频率、触发点或电压限值，原采样窗口推算就不再自动成立。练习时只重写等价配置，不改变这些运行参数。

## 8. 从 15 kHz 采样到 3 kHz 电流任务

```mermaid
flowchart LR
    TIM[TIM2 CH4 OC4REF] --> TRGO[TRGO 内部触发]
    TRGO --> ADC[ADC 注入组 rank1/2]
    ADC --> IRQ[ADC1_2_IRQHandler 取结果]
    IRQ --> CHECK[零点 / 原始过流 / 五分频]
    CHECK --> PUB[发布最新电流对 + sequence]
    PUB --> PEND[请求 PendSV]
    PEND --> CTRL[motor_current_task]
    CTRL --> CCR[写三相 CCR 预装载]
    CCR --> PWM[后续更新事件生效]
```

实际中断入口与 PendSV：

```c
void ADC1_2_IRQHandler(void)
{
    if (ADC_GetITStatus(ADC1, ADC_IT_JEOC))
    {
        uint16_t a = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
        uint16_t b = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
        ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
        motor_adc_isr(a, b);
    }
}
```

```c
void board_current_request(void)
{
    SCB->ICSR = SCB_ICSR_PENDSVSET_Msk;
}
```

```c
void PendSV_Handler(void)
{
    motor_current_task();
}
```

ADC 中断每次都处理采样结果，并在需要时检查原始过流；每五次才发布一份电流对：

```c
static void publish_current_sample(uint16_t a, uint16_t b)
{
    if (++current_div < BOARD_CURRENT_DIV)
        return;
    current_div = 0u;
    current_pair = (uint32_t)a | ((uint32_t)b << 16);
    __DMB();
    ++current_sequence;
    board_current_request();
}
```

这里发布的是第 5 帧当时的最新 a/b，**不是五帧求平均**。把两个 uint16_t 打包进一个 uint32_t，低 16 位保存 a，高 16 位保存 b。`__DMB()` 用于约束数据发布的内存访问顺序，不是延时函数或互斥锁。

\[
f_{current}=15000/5=3000\ Hz,\qquad T_{current}\approx333.333\ \mu s
\]

每次电流更新之间平均有 5 个 PWM 周期；计算和锁存存在延迟，不能理解成“第 5 次 ADC 结果刚出现，新的 PWM 已经立即生效”。

## 9. PendSV 挂起位不是任务队列

请求 PendSV 时设置的是一个 pending 标志，不是给硬件队列添加一条带完整样本的数据包。连续请求可能合并，只有这个位无法知道错过多少帧。[ST PM0056：ICSR/PENDSVSET](https://www.st.com/resource/en/programming_manual/pm0056-stm32f10xxx20xxx21xxxl1xxxx-cortexm3-programming-manual-stmicroelectronics.pdf)

本工程另用 current_sequence/current_processed 判断：

```c
/* motor_current_task 函数内部摘录，后续计算省略。 */
    uint32_t key = board_lock();
    uint32_t sequence = current_sequence, pair = current_pair;
    board_unlock(key);
    uint32_t passed = sequence - current_processed;
    if (!passed)
        return;
    current_processed = sequence;
    if (passed > 1u && (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING))
    {
        motor_timing_fault(TIMING_BACKLOG, passed);
        return;
    }
```

要点：

- passed=0：没有新发布数据，本次不处理。
- passed=1：正常消费一次最新发布。
- passed>1：落后于发布；RUN/CAL 中锁存 BACKLOG 类型的 TIMING 故障。
- 当前只有最新一对采样，不具备把中间每个旧样本重新逐帧计算的条件。

例如 sequence=43、processed=40，passed=3，说明有三次发布尚未消费；若本次只拿最新一次，中间两次没有逐次处理。STOP 下代码不会因该条件锁存运行故障，但这也不能用于证明运行负载下一定满足时序。

current_steps 在任务消费新发布数据后增加，后面可能因零点未就绪或 STOP 而提前返回。因此它更适合表示任务处理活动，不等于完整 PI 执行次数。

当前电流 PI 的 dt 取 `BOARD_CURRENT_DIV/BOARD_PWM_HZ`，即标称 1/3000 s；并非所有环都从同一个 DWT 差值求 dt。角度差分用实际时间戳，速度/位置 PI 在各自更新点用实际差值。理解不同路径各自的时间依据，不能把其中一种写法套到所有模块。

## 10. TIM4 1 kHz 与外环分频

TIM4：PSC=71、ARR=999，计数步长 1 μs，每 1000 步更新一次。中断完成 AS5600 读取后，由 motor_sensor_isr 更新角度、速度及外环。

RUN 时的分频结构：

```c
++outer_div;
if (status.mode == MODE_POSITION && (outer_div % 10u) == 0u)
{
    /* 位置环：每十个角度任务执行一次，标称 100 Hz。 */
}
if ((outer_div % 2u) == 0u)
{
    /* 速度环或电流目标斜坡：每两个角度任务一次，标称 500 Hz。 */
}
if (outer_div >= 100u)
    outer_div = 0u;
```

位置模式形成位置→速度→电流级联；速度模式不运行位置 PI；电流模式在这条 500 Hz 路径更新电流给定斜坡，而内层电流任务仍是 3 kHz。不同模式选择的工作不同，不能用“所有环一直执行”来描述。

outer_div 到 100 清零，保持二分频、十分频的整齐节奏。当前使用 uint8_t，如果只依赖 255→0 自然回绕，256 不是 10 的整数倍，会打乱十分频间隔。

名义上 1 ms 中有 15 个 PWM 周期，10 ms 中有 150 个；TIM2/TIM4 通过软件先后启动，当前没有建立两者的硬件相位锁定。**整数频率比不等于二者每次都从同一相位开始。** ADC 则由 TIM2 内部信号直接关联到载波。

## 11. 抢占优先级：数字小，先响应

当前 `NVIC_PriorityGroup_4` 使用四位抢占优先级，子优先级不参与细分：

| 优先级 | 异常/中断 | 工作 |
| ---: | --- | --- |
| 0 | ADC1_2 | 取电流、零点/原始过流、分频发布 |
| 1 | USART1 | 收发字节 |
| 2 | PendSV | 电流控制计算 |
| 3 | TIM4 / TIM3 | 读角与外环 / 红外捕获 |
| 4 | SysTick | 毫秒计数 |
| 后台 | main | 命令解析、菜单、OLED、周期日志和喂狗 |

例如 PendSV 可打断 TIM4 的软件 I²C，ADC 又可打断 PendSV。优先级影响 CPU 何时服务中断，不会把 TIM2 的硬件计数频率改掉。

TIM3 与 TIM4 同级，不能按抢占优先级互相打断；同时挂起时还有内核仲裁规则，不能凭两者函数在文件中的先后顺序推断。

当前 PendSV 是人为安排为优先级 2 的控制异常，不是套用“PendSV 必须最低优先级”的 RTOS 上下文切换写法。本工程没有靠操作系统调度这些任务。

提高优先级不是免费增加 CPU 算力：高优先级工作太长，低优先级任务就会延迟。PRIMASK 临界区还会暂时屏蔽可屏蔽异常，所以临界区只做短操作，不放串口整行等待或 I²C 传输。

## 12. 周期、耗时、响应延迟与抖动

| 概念 | 本课例子 |
| --- | --- |
| 周期 | 控制任务标称每 333.333 μs 请求一次 |
| 执行耗时 | 这次控制计算从计时起点到终点占多少经过时间 |
| 响应延迟 | 发布请求到 CPU 真正开始处理之间的等待 |
| 抖动 | 实际相邻时刻围绕标称间隔的变化 |

200 μs 电流任务预算不是 200 μs 控制周期；900 μs 传感器预算也不是 900 μs 采样周期。两者各有对应的 333.333 μs、1 ms 标称周期。

DWT 计时以 CPU 周期数差计算，72 个 count≈1 μs：

```c
uint32_t begin = board_cycles();
/* 需要计时的工作 */
uint32_t elapsed = board_cycles() - begin;
```

若高优先级中断在中间抢占，elapsed 包含这段经过时间，并非只统计本函数独占 CPU 的指令耗时。程序记录的 us/fast_us 是控制段已观察到的最大值；sens_us 是包含 I²C 的传感器段最大值。

控制函数在 STOP 或零点未就绪时可能在记录最大值之前返回，所以 **STOP 下 fast_us=0 不能解释成该任务完全不耗时**。此外该计时起点位于取出最新采样之后，不覆盖请求到开始处理的全部延迟。

两项最大值相加不能严格当作一秒 CPU 占用率：频率不同，记录窗口不同，且抢占时间可能重复计入。需要性能证据时另做符合目的的测量，本课只学习现有统计的含义。

定时器更新标志和 NVIC 挂起位都不是无限事件队列。CPU 长时间不能服务时，硬件仍计数，但软件不一定逐次看到每次溢出；不能靠“中断最终进来了”证明从未漏过时序。

## 13. C 语言与标准库结构体：如何开始写配置？

不用一次背下整段初始化。先写四项需求，再对应函数：

```text
需要哪个定时器？TIM4
计数步长？1 μs → 72 MHz/(PSC+1)=1 MHz → PSC=71
多久更新？1 ms → ARR+1=1000 → ARR=999
在哪里处理？Update 中断 → 外设中断源 + NVIC + ISR
```

再写结构体：

```c
TIM_TimeBaseInitTypeDef t;
TIM_TimeBaseStructInit(&t);  /* 先得到完整默认字段。 */
t.TIM_Prescaler = 71u;
t.TIM_Period = 999u;
TIM_TimeBaseInit(TIM4, &t);  /* &t 是配置对象的地址。 */
```

局部结构体声明本身不自动给所有成员合适的值。StructInit 是标准库提供的“填默认参数”，TimeBaseInit 才把参数用于目标外设。

本项目复用 t 配置多个定时器，oc 配置四个通道，n 配置多个 IRQ。这节省重复代码，但未重写的字段保留旧值；阅读时应沿赋值顺序追踪。例如切 CH4 前将 oc.TIM_OCMode 改为 PWM2，而 CH1/2/3 已经按此前的 PWM1 配好。

宏同样不会自动重配硬件：当前 ARR 使用 BOARD_PWM_COUNTS，控制 dt 使用 BOARD_PWM_HZ；TIM4 的 ARR 在初始化中写 999。只改一个频率宏，不能假定所有实际配置和算法时间都跟着变化。

## 14. 本课完整中文注释模块

以下初始化的有效配置与正式 pwm_adc_init 相同。只是独立成可学习的模块，增加解释及配置查询。

```c
/*
 * 第五课：实际定时与 ADC 初始化模块。
 * 配置逻辑与正式 board.c 的 pwm_adc_init 一致，只增加知识点注释。
 * 生成的 board_lesson05.c 调用本函数，其他板级实现仍与正式版本一致。
 */
#include "lesson05_timing.h"
#include "board.h"
#include "app_config.h"
#include "console.h"
#include <stdio.h>

void lesson05_timing_init(void)
{
    TIM_TimeBaseInitTypeDef t;
    TIM_OCInitTypeDef oc;
    ADC_InitTypeDef a;
    NVIC_InitTypeDef n;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 | RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    /* TIM2 输入 72 MHz：fPWM=72000000/((0+1)×(4799+1))=15 kHz。 */
    /* 标准库补齐未显式赋值的字段：向上计数、CKD=DIV1。
     * 对象 t 可重复用来配置不同定时器，但每次要明确修改本次不同的字段。
     */
    TIM_TimeBaseStructInit(&t);
    t.TIM_Period = BOARD_PWM_COUNTS - 1u;
    t.TIM_Prescaler = 0;
    TIM_TimeBaseInit(TIM2, &t);
    /* 补齐比较结构体，默认输出有效极性为高。
     * TIM2 是通用定时器，本例不配置 TIM1 的互补输出/死区功能。
     */
    TIM_OCStructInit(&oc);
    oc.TIM_OCMode = TIM_OCMode_PWM1;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    oc.TIM_Pulse = 0;
    TIM_OC1Init(TIM2, &oc);
    TIM_OC2Init(TIM2, &oc);
    TIM_OC3Init(TIM2, &oc);
    /* CCR 预装载：软件先写待用值，更新事件再送入实际比较逻辑。
     * ARR 预装载是另一组配置；不要把两者当成一个开关。
     */
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
    /* CH4 在 CNT=4400（约 61.1 μs）触发 ADC，避开 50% 附近的三相开关沿。
     * 参数限制电压幅值不超过母线 25%，最高相占空比不超过 75%：
     * 最晚开关约在 50 μs，采样前留约 11.1 μs，两个 ADC 转换约 3.33 μs，
     * 仍早于下周期 66.7 μs 的开关。PA3 保持 GPIO 低，不输出 CH4 波形。 */
    oc.TIM_OCMode = TIM_OCMode_PWM2;
    oc.TIM_Pulse = BOARD_ADC_TRIGGER_TICKS;
    TIM_OC4Init(TIM2, &oc);
    /* TRGO 选择内部 OC4REF，不需要将 CH4 复用输出到 PA3。
     * PWM2 在 CNT 到 CCR4 时从无效变有效，给 ADC 提供内部上升沿。
     */
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_OC4Ref);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    ADC_StructInit(&a);
    a.ADC_Mode = ADC_Mode_Independent;
    a.ADC_ScanConvMode = ENABLE;
    a.ADC_ContinuousConvMode = DISABLE;
    a.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    a.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &a);
    /* 注入组依次采 PB0/ADC_IN8、PB1/ADC_IN9；不沿用旧例程的自由连续转换。 */
    /* 一次触发按 rank1、rank2 顺序转换，不是两路同时采样。
     * 规则组结构体的 NbrOfChannel=1 不决定注入组长度，这里单独设为 2。
     */
    ADC_InjectedSequencerLengthConfig(ADC1, 2);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_7Cycles5);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_9, 2, ADC_SampleTime_7Cycles5);
    ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_T2_TRGO);
    /* 电流采样仅使用注入组，由 TIM2 事件触发。 */
    ADC_Cmd(ADC1, ENABLE);
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1))
    {
    }
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1))
    {
    }
    ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
    /* JEOC 表示本次注入序列完成。ADC 中断取 JDR1/JDR2 后才发布数据。
     * ADC 每 PWM 周期处理一次，但控制任务每五次才请求一次。
     */
    ADC_ITConfig(ADC1, ADC_IT_JEOC, ENABLE);
    n.NVIC_IRQChannel = ADC1_2_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 0;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
    /* TIM3：72 MHz/(71+1)=1 MHz，每计数 1 μs，供红外输入捕获使用。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 65535;
    TIM_TimeBaseInit(TIM3, &t);
    TIM_Cmd(TIM3, ENABLE);
    /* TIM4：1 MHz/(999+1)=1 kHz，每 1 ms 触发一次角度任务。 */
    t.TIM_Prescaler = 71;
    t.TIM_Period = 999;
    TIM_TimeBaseInit(TIM4, &t);
    /* 时基初始化可能产生更新标志；先清掉，避免开启后把旧标志当新节拍。
     * TIM_ITConfig、NVIC_Init、TIM_Cmd 分别控制中断源、NVIC 通路和计数器。
     */
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    n.NVIC_IRQChannel = TIM4_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_Init(&n);
    /* 此处不启动 TIM2/TIM4；board_start_control 统一启用触发与计数器。 */
}

/* 向上、边沿对齐定时器的配置推算。先转 float 避免整数除法截断和乘积溢出。
 * 这不是通过 GPIO 或示波器测出的实际频率，不能据此证明中断都按时处理。
 */
float lesson05_timer_hz(uint32_t timer_clock, uint16_t psc, uint16_t arr)
{
    return (float)timer_clock / ((float)psc + 1.0f) / ((float)arr + 1.0f);
}

void lesson05_print_config(void)
{
    RCC_ClocksTypeDef clocks;
    RCC_GetClocksFreq(&clocks);
    /* 本工程使用内部 APB1 时钟；PCLK1 不是 HCLK 时，APB1 有分频，定时器乘 2。 */
    uint32_t timer_clock = clocks.PCLK1_Frequency;
    if (clocks.PCLK1_Frequency != clocks.HCLK_Frequency)
        timer_clock *= 2u;
    char line[160];
    (void)snprintf(line, sizeof(line),
                   "L5 CONFIG timclk=%lu adcclk=%lu current_div=%u\r\n",
                   (unsigned long)timer_clock, (unsigned long)clocks.ADCCLK_Frequency,
                   (unsigned)BOARD_CURRENT_DIV);
    console_message(line);
    /* 标准库没有独立的 PSC/ARR 读取接口，下面只读 CMSIS 寄存器字段用于观察。
     * 外设配置仍由上面的标准库函数完成，不使用 HAL。
     */
    (void)snprintf(line, sizeof(line),
                   "L5 TIM2 psc=%u arr=%u hz=%lu ccr4=%u\r\n",
                   (unsigned)TIM2->PSC, (unsigned)TIM2->ARR,
                   (unsigned long)(lesson05_timer_hz(timer_clock, (uint16_t)TIM2->PSC,
                                                   (uint16_t)TIM2->ARR) + 0.5f),
                   (unsigned)TIM_GetCapture4(TIM2));
    console_message(line);
    (void)snprintf(line, sizeof(line),
                   "L5 TIM4 psc=%u arr=%u hz=%lu\r\n",
                   (unsigned)TIM4->PSC, (unsigned)TIM4->ARR,
                   (unsigned long)(lesson05_timer_hz(timer_clock, (uint16_t)TIM4->PSC,
                                                   (uint16_t)TIM4->ARR) + 0.5f));
    console_message(line);
}
```

查询代码读取 PSC/ARR 等寄存器字段只是为了报告配置，外设初始化仍使用标准库。`lesson05_timer_hz` 是配置计算函数，没有改变硬件。它先转 float 做除法，避免整数除法过早截断。

本课生成的 board_lesson05.c 删除原私有 pwm_adc_init，并在 board_init 调用 lesson05_timing_init；GPIO、串口、中断、DWT、看门狗等其余逻辑保留。

## 15. 完整学习入口与预期输出

```c
/* 第五课：实际多速率任务照常运行；后台每秒观察一次任务计数差。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include "lesson05_timing.h"
#include <stdio.h>

int main(void)
{
    AppParams params;
    board_init(); /* 本课生成的 board 改为调用 lesson05_timing_init。 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson05 v1.1.7: PWM / ADC / PendSV / TIM4\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");
    lesson05_print_config(); /* 此时 TIM2/TIM4 尚未启动，只观察配置值。 */
    board_start_control();
    ui_init();
    board_watchdog_start();

    MotorStatus initial;
    motor_snapshot(&initial);
    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t print_sensor = initial.sensor_samples, print_current = initial.current_steps;
    uint32_t check_sensor = initial.sensor_samples, check_current = initial.current_steps;

    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 1000u)
        {
            MotorStatus s;
            motor_snapshot(&s);
            uint32_t dt_ms = now - last_print_ms;
            uint32_t ds = s.sensor_samples - print_sensor;
            uint32_t dc = s.current_steps - print_current;
            last_print_ms = now;
            print_sensor = s.sensor_samples;
            print_current = s.current_steps;
            char line[224];
            /* ds/dc 是当前观察窗口内计数差，不把“每秒打印”当成精确采样时间。
             * STOP 时任务也会增加；这不表示电流 PI 已完整执行或电机已使能。
             */
            (void)snprintf(line, sizeof(line),
                           "L5 dt_ms=%lu ds=%lu dc=%lu st=%s fault=%s "
                           "fast_us=%lu sens_us=%lu\r\n",
                           (unsigned long)dt_ms, (unsigned long)ds, (unsigned long)dc,
                           motor_state_name(s.state), motor_fault_name(s.fault),
                           (unsigned long)(s.fast_max_cycles / (BOARD_CPU_HZ / 1000000u)),
                           (unsigned long)(s.sensor_max_cycles / (BOARD_CPU_HZ / 1000000u)));
            console_message(line);
        }
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != check_sensor && s.current_steps != check_current)
                board_watchdog_feed();
            check_sensor = s.sensor_samples;
            check_current = s.current_steps;
        }
    }
}
```

打开 **ControlPanel_Lesson05.uvprojx → Lesson05_NoKnob**。本课只链接 board_lesson05.c 和 lesson05_timing.c，不再同时链接正式 board.c。入口也只保留本课这一份 main。

HEX 在 Objects/Lesson05/Lesson05_NoKnob.hex。Tools/make_learning_project.py 可重新生成独立课程工程及连接文件；修改初始化练习时编辑 lesson05_timing.c。

本轮未烧录。后续上板保持 STOP，观察一次配置与每秒计数差即可，不需要再做多轮占空比测量。可发送 `log 0` 关闭普通遥测，L5 行仍保留；本课不含第三课 echo/uart 命令或第四课 L4 行。

下面是**预期格式与理想示例，不是本轮实测**：

```text
L5 CONFIG timclk=72000000 adcclk=12000000 current_div=5
L5 TIM2 psc=0 arr=4799 hz=15000 ccr4=4400
L5 TIM4 psc=71 arr=999 hz=1000
L5 dt_ms=1000 ds=1000 dc=3000 st=STOP fault=NONE fast_us=0 sens_us=...
```

- CONFIG 中频率由时钟和寄存器推算，不代表示波器量到的结果。
- ds 是 sensor_samples 的窗口增量，正常约每秒 1000。
- dc 是 current_steps 的窗口增量，正常约每秒 3000；不代表每次都完整运行 PI。
- 若 dt_ms=1002，应按 ds×1000/1002 估算该窗口平均每秒计数，不要求机械照抄 1000/3000。
- 主循环时间、快照和计数的取样边界有偏差，所以一帧计数差不是逐周期抖动测量。
- 传感器尝试次数增加也不证明每次通信成功，需结合 err/mag 等正常状态输出。

这类观察能检查任务是否持续活动，不能单独证明动态闭环质量、PWM 波形或运行时最坏负载的时序。

## 16. 本课主要编码练习：独立补写 TIM4 配置

先根据第 13 节需求写伪代码，再合上参考补全：

```c
/* 前提：TIM4 外设时钟已开启，t/n 已声明。下面是独立练习片段。 */
TIM_TimeBaseStructInit(&t);
t.TIM_Prescaler = /* A */;
t.TIM_Period = /* B */;
TIM_TimeBaseInit(/* C */, &t);
TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
n.NVIC_IRQChannel = /* D */;
n.NVIC_IRQChannelPreemptionPriority = /* E */;
n.NVIC_IRQChannelSubPriority = 0u;
n.NVIC_IRQChannelCmd = ENABLE;
NVIC_Init(&n);
/* TIM_Cmd(TIM4, ENABLE) 留在 board_start_control，不在这里重复启动。 */
```

参考：A=71u，B=999u，C=TIM4，D=TIM4_IRQn，E=3u。

将自己写出的等价配置放回本课模块对应位置后编译。复习一处 PWM 配置即可：解释 `t.TIM_Period=BOARD_PWM_COUNTS-1u` 为什么减一，以及 CCR 为什么按 BOARD_PWM_COUNTS 换算。

只做一个任务观察：后续把一组 L5 配置行和计数行记录下来，写明“哪些是寄存器推算、哪些是任务计数观察”。暂不改变频率、控制分频或采样触发点。

## 17. 自测题与参考答案

1. TIM2CLK=72 MHz、PSC=0、ARR=4799，计数频率、PWM 频率与周期各是多少？
2. CCR=1200、2400、4800 对应什么占空比？为何 4800 大于 ARR 仍可用？
3. 开启 CCR 预装载后，写 CCR 是否立即改变正在进行的这一轮？预装载是否保证三次写绝对原子？
4. CH4 的 CCR4=4400，触发位置约为一轮开始后多少 μs？PA3 是否必须输出这路信号？
5. ADC 12 MHz、7.5 周期采样，顺序转换两路约需多久？两路是否同一瞬间采样？
6. ADC 每秒 15000 次，每 5 次发布一次。电流任务标称频率/周期、每次之间的 PWM 周期数是多少？是否平均五个样本？
7. sequence=43、processed=40，passed 是多少？只拿最新数据时中间几次未逐次处理？
8. TIM4 每 1 ms，outer_div 每 2/10 帧触发时分别是多少 Hz？为什么到 100 清零？
9. USART1=1、PendSV=2、TIM4=3，谁可以抢占谁？TIM3 与 TIM4 同为 3 呢？
10. STOP 下 dc≈3000、fast_us=0，能否证明完整 PI 每秒运行 3000 次且不耗时？
11. dt_ms=1002、ds=1001，窗口平均处理频率约多少 Hz？能否据此保证每个间隔都精确？
12. 只把 BOARD_PWM_HZ 改成 20000，为什么不能认定输出就是 20 kHz？

参考答案：

1. 72 MHz；15 kHz；约 66.667 μs。
2. 25%、50%、100%；CNT 始终小于 4800，所以整轮有效。
3. 等更新事件生效；不保证三次 CPU 写不可分割，硬件更新可以夹在写之间。
4. 约 61.111 μs；不需要，内部 OC4REF 经 TRGO 触发，PA3 仍固定低。
5. 两次 (7.5+12.5)/12 MHz≈3.333 μs；顺序采样。
6. 3 kHz、约 333.333 μs、5 个 PWM 周期；发布最新一帧，不是求平均。
7. passed=3，中间两次没有逐次处理；RUN/CAL 会按 BACKLOG 处理。
8. 500 Hz、100 Hz；100 同时是 2 和 10 的整数倍，避免 uint8_t 的 256 回绕破坏十分频。
9. USART1 可抢占后二者，PendSV 可抢占 TIM4；TIM3/TIM4 同抢占级别，不能按优先级互相打断。
10. 不能，计数增加后可提前返回，且耗时最大值的记录不覆盖这些返回路径。
11. 1001×1000/1002≈999.002 Hz；只能反映窗口平均，不能证明逐周期间隔。
12. 载波由实际 TIM2 时钟、PSC、ARR 决定，当前 ARR 根据 BOARD_PWM_COUNTS 配置；算法 dt 与采样窗口也要一致。

## 18. 本课产出与面试表达

保存：整机任务频率表、自己补写的 TIM4 配置、一份后续真实 L5 计数记录，以及“预装载/控制更新/载波”的简短解释。

面试的一分钟讲解：

> 我把 PWM 载波、同步 ADC 采样和控制运算分成不同时间尺度。TIM2 在硬件中生成 15 kHz PWM，并用内部 CH4 触发两路电流顺序采样；ADC 中断处理采样与原始过流，每五帧发布数据，由 PendSV 运行 3 kHz 电流任务。TIM4 负责 1 kHz 角度任务，再分频运行外环。比较值通过预装载在更新边界生效，后台显示不承担控制调度；任务序号与耗时统计用于观察积压和时序预算。

这些是当前设计与代码能力。实际最坏耗时、抖动和控制性能仍按后续实测记录表述，不把理论频率当作性能验收。

**下一课：两相电流测量。** 从 V3P 的采样电阻、INA240 增益到 ADC 零点、原始计数换算为 A、电流符号和残差，接上本课的同步采样链。
