/* 第五课：实际多速率任务照常运行；后台每秒观察一次任务计数差。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include "lesson05_timing.h"
#include <stdio.h>

int main(void)
{
    AppParams params;
    board_init(); /* 本课生成的 board 改为调用 lesson05_timing_init。 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson05 v1.1.7: PWM / ADC / PendSV / TIM4\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");
    lesson05_print_config(); /* 此时 TIM2/TIM4 尚未启动，只观察配置值。 */
    board_start_control();
    ui_init();
    board_watchdog_start();

    MotorStatus initial;
    motor_snapshot(&initial);
    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t print_sensor = initial.sensor_samples, print_current = initial.current_steps;
    uint32_t check_sensor = initial.sensor_samples, check_current = initial.current_steps;

    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 1000u)
        {
            MotorStatus s;
            motor_snapshot(&s);
            uint32_t dt_ms = now - last_print_ms;
            uint32_t ds = s.sensor_samples - print_sensor;
            uint32_t dc = s.current_steps - print_current;
            last_print_ms = now;
            print_sensor = s.sensor_samples;
            print_current = s.current_steps;
            char line[224];
            /* ds/dc 是当前观察窗口内计数差，不把“每秒打印”当成精确采样时间。
             * STOP 时任务也会增加；这不表示电流 PI 已完整执行或电机已使能。
             */
            (void)snprintf(line, sizeof(line),
                           "L5 dt_ms=%lu ds=%lu dc=%lu st=%s fault=%s "
                           "fast_us=%lu sens_us=%lu\r\n",
                           (unsigned long)dt_ms, (unsigned long)ds, (unsigned long)dc,
                           motor_state_name(s.state), motor_fault_name(s.fault),
                           (unsigned long)(s.fast_max_cycles / (BOARD_CPU_HZ / 1000000u)),
                           (unsigned long)(s.sensor_max_cycles / (BOARD_CPU_HZ / 1000000u)));
            console_message(line);
        }
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != check_sensor && s.current_steps != check_current)
                board_watchdog_feed();
            check_sensor = s.sensor_samples;
            check_current = s.current_steps;
        }
    }
}
