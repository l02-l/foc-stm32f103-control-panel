#ifndef LESSON05_TIMING_H
#define LESSON05_TIMING_H
#include <stdint.h>

/* 使用标准外设库配置 TIM2/3/4 与 ADC，替代本课 board 中的 pwm_adc_init。 */
void lesson05_timing_init(void);
/* 仅适用于本课这种向上、边沿对齐计数；返回配置推算的频率，单位 Hz。 */
float lesson05_timer_hz(uint32_t timer_clock, uint16_t psc, uint16_t arr);
/* 查询配置并打印；不改变 PWM、使能状态或采样节拍，不代表示波器实测。 */
void lesson05_print_config(void);
#endif
