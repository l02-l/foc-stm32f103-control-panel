# 第四课：AS5600 软件 I²C、连续角度与速度估计

日期：2026-11-04。基线：**v1.1.7，无旋钮，STM32F103C8T6 标准外设库**。建议 10～12 小时，可分三次完成。

## 0. 本课解决什么问题？

前一课已经知道怎样向电脑传输字符。本课回答：**日志中的 r、pos100、rpm10，究竟从哪里来？**

不是重新堆一套读取程序，而是沿当前可运行工程追踪：

```mermaid
flowchart LR
    M[轴端磁铁] --> AS[AS5600 状态和单圈角]
    AS --> I2C[PB10/PB11 软件 I2C]
    I2C --> SAMPLE[as5600_sample]
    SAMPLE --> IRQ[TIM4 每 1 ms 读取]
    IRQ --> TRACK[跨零累计与实际 dt]
    TRACK --> POS[相对多圈位置]
    TRACK --> SPEED[速度及低通滤波]
    POS --> SNAP[状态快照]
    SPEED --> SNAP
    SNAP --> VIEW[OLED / 串口]
```

本课完成后，应能独立解释一次寄存器读取、组合两个字节、写出跨零增量，讲清位置原点和测速时间。闭环使用这些反馈；本课不展开 PI 运算。

| 文件 | 实际用途 |
| --- | --- |
| [BSP/soft_i2c.c](../../BSP/soft_i2c.c) / [头文件](../../BSP/soft_i2c.h) | GPIO 电平、起止条件、字节和寄存器事务 |
| [正式 BSP/as5600.c](../../BSP/as5600.c) | 正式传感器接口对照 |
| [lesson04_sensor.c](lesson04_sensor.c) | 同接口、同行为的详细中文注释实现，实际参与本课编译 |
| [Control/control_math.c](../../Control/control_math.c) / [头文件](../../Control/control_math.h) | cm_angle_delta、AngleTracker 与累计更新 |
| [Control/motor.c](../../Control/motor.c) | motor_sensor_isr 中的实际 dt、方向、原点与滤波 |
| [BSP/board.c](../../BSP/board.c) | TIM4_IRQHandler 与 DWT 计时 |
| [main.c](main.c) | 复用真实任务，500 ms 输出一帧 L4 观察日志 |
| [第四课 Keil 工程](../../ControlPanel_Lesson04.uvprojx) | Target：Lesson04_NoKnob |
| [编译记录](build.log) | ARM Compiler 6.18，0 错误、0 警告 |

本轮已编译课程，**尚未烧录或实测 L4 输出**。文中的寄存器和手算是解释，日志是预期格式；不作为本轮硬件测试记录。

## 1. 硬件与物理量：AS5600 告诉我们什么？

当前 M0 传感器由 V3P 的 3V3/GND 供电，经转接板连接：

| 信号 | STM32 引脚 | 含义 |
| --- | --- | --- |
| SCL0 | PB10 | STM32 产生读取时钟 |
| SDA0 | PB11 | 主机发送地址、传感器返回数据，分时使用 |
| 3V3 | 传感器 3V3 | 本项目采用 3.3 V 接法 |
| GND | 公共地 | 供电和信号共同参考 |

软件对象与接线对应：

```c
const SoftI2c sensor_bus = {GPIOB, GPIO_Pin_10, GPIO_Pin_11};
```

这是 GPIO 软件模拟 I²C，**并没有启用硬件 I2C2 外设来完成事务**。不能仅因为 PB10/PB11 具备 I²C 复用功能，就认定当前走的是硬件 I²C。

AS5600 读取轴端磁铁的单圈绝对角，12 位提供 4096 个计数位置。它不记录转过了多少整圈，不直接输出 rpm，也不知道定子电角零位。相关器件信息参见 [ams OSRAM AS5600 数据手册，第 10、13、18～20 页（厂商文档镜像）](https://www.mouser.com/datasheet/2/588/AS5600_DS000365_5_00-1877365.pdf)。

\[
\theta_m=raw\frac{2\pi}{4096},\qquad
\theta_{m,deg}=raw\frac{360}{4096}
\]

一 count 约 0.087890625°；raw=4095 对应约 359.9121°，不是 360°。分母是位置总数 4096，而非最大读数 4095。

12 位是分辨率，不等于安装后角度准确到一 count。磁铁对中、磁场、芯片误差和滤波均会影响实际反馈。

## 2. 开漏：为什么写 1 之后仍要读引脚？

本项目将 SCL/SDA 设为 GPIO_Mode_Out_OD：

- 写 0：拉低线路。
- 写 1：释放线路，由上拉形成高电平。
- 读输入寄存器：观察线路实际上是否为高。

SDA 在主机发送后要交给传感器驱动，因此不能一直由 STM32 推挽输出高电平。`scl_high()` 也是先释放再检查实际电平；其等待上限由代码给出。AS5600 本身不提供时钟延展，该通用检查仍可发现时钟线被拉低的情况。

I²C 采用最高位先传。普通数据位在 SCL 高期间保持稳定；START 是 SCL 高时 SDA 高→低，STOP 是 SCL 高时 SDA 低→高。协议依据：[NXP UM10204，第 3.1 节](https://www.nxp.com/docs/en/user-guide/UM10204.pdf)。

`board_delay_us(1)` 只是软件时序的一部分。GPIO 函数、循环和中断抢占也耗时，所以不能用这一行宣布总线准确运行在某个频率；要测 SCL 波形才能确认实际速率。

## 3. ACK/NACK：先区分线路电平与函数返回值

每传完 8 位，接收方在第 9 个时钟回答：低电平是 ACK，释放为高是 NACK。当前 send_byte 把“读到 ACK”转换成逻辑成功：

```c
uint8_t ack = GPIO_ReadInputDataBit(b->port, b->sda) == Bit_RESET;
return ack;
```

因此 ACK 线路电平为 0 时，这个函数返回 **1**。早期诊断日志里的 ack=0 是否表示成功，要回到打印变量的定义，不能混用不同函数的约定。

读取数据时 STM32 是接收方。读前两个字节后由 STM32 ACK，读最后一个字节后由 STM32 NACK，再 STOP；最后的 NACK 表示本次读完，是正常结束。见 [NXP ACK/NACK 规则](https://www.nxp.com/docs/en/user-guide/UM10204.pdf)。

## 4. 地址有两层：0x36 与 0x0B 不能互换

| 数值 | 本项目中的含义 |
| --- | --- |
| 0x36 | AS5600 七位设备地址：选择哪颗芯片 |
| 0x6C | 在线上传输的写方向地址字节：(0x36<<1)\|0 |
| 0x6D | 在线上传输的读方向地址字节：(0x36<<1)\|1 |
| 0x0B | STATUS 寄存器地址：芯片内部哪个位置 |
| 0x0C / 0x0D | RAW ANGLE 高/低字节 |

接口 `soft_i2c_read_reg` 接收七位地址，内部完成左移。传入 0x6C 会被再次左移，不能套用另一个库的八位地址习惯。

本工程的一次 sample：

```text
START
主机发 0x6C        从机 ACK
主机发 0x0B        从机 ACK（设置内部寄存器指针）
重复 START
主机发 0x6D        从机 ACK
从机发 STATUS      主机 ACK
从机发 RAW_H       主机 ACK
从机发 RAW_L       主机 NACK
STOP
```

“先写”只是在选择寄存器地址，不是改写 STATUS，也没有烧写 OTP 参数。三字节分别落到 data[0]、data[1]、data[2]。

数据手册允许顺序读；对 RAW ANGLE 等高字节起始地址另有重复读取的指针规则。本项目每笔事务重新设置起始地址为 STATUS=0x0B，只取接下来三个字节，不依赖上一笔事务结束后的地址指针。[厂商数据手册 Reading 与 Automatic Increment 小节](https://www.mouser.com/datasheet/2/588/AS5600_DS000365_5_00-1877365.pdf)

这是一笔事务连续读完三个字节，不应进一步声称“磁场状态和角度在同一硬件瞬间被锁存”。

## 5. 读懂通用读取函数

```c
uint8_t soft_i2c_read_reg(const SoftI2c *b, uint8_t addr, uint8_t reg, uint8_t *out, uint16_t n)
{
    uint8_t ok = start_bus(b) && send_byte(b, (uint8_t)(addr << 1)) && send_byte(b, reg) &&
                 start_bus(b) && send_byte(b, (uint8_t)((addr << 1) | 1u));
    while (ok && n)
    {
        --n;
        ok = receive_byte(b, out++, n == 0u);
    }
    stop_bus(b);
    return ok;
}
```

逐步阅读：

1. `&&` 从左向右短路求值，前一步失败就不执行后一步。
2. `uint8_t *out` 接收调用者数组首地址。
3. 每读一字节前 `--n`，最后一字节时 n==0，给 receive_byte 传入 last=1。
4. `out++` 把本次地址交给函数，随后指针前进一个字节；不是把字节内容加一。
5. 即使中途失败，也会走 stop_bus，返回 ok。

对应接收字节函数：

```c
static uint8_t receive_byte(const SoftI2c *b, uint8_t *out, uint8_t last)
{
    uint8_t value = 0u;
    sda(b, 1u);
    for (unsigned i = 0; i < 8u; i++)
    {
        pause_bus(b);
        if (!scl_high(b))
            return 0u;
        value = (uint8_t)((value << 1) | GPIO_ReadInputDataBit(b->port, b->sda));
        scl_low(b);
    }
    sda(b, last);
    pause_bus(b);
    if (!scl_high(b))
        return 0u;
    scl_low(b);
    sda(b, 1u);
    *out = value;
    return 1u;
}
```

`value=(value<<1)|新的一位` 是按最高位先到的顺序拼八位。例如先到 1、再到 0，两次之后低位累计内容为二进制 10。

初始化中有 9 个时钟加 STOP 的总线释放尝试，scl_high 有超时。理解它们解决的问题即可，本课不增加新的故障注入流程。

## 6. 从字节到 raw：先手算，再写代码

给定一笔读取的结果：

```c
uint8_t data[3] = {0x20u, 0x01u, 0xB3u};
```

高字节左移、与低字节按位或：

```text
0x01 << 8 = 0x0100
0x0100 | 0x00B3 = 0x01B3 = 435
机械角 = 435 × 360 / 4096 ≈ 38.2324°
```

参考表达式：

```c
*raw = ((uint16_t)data[1] << 8) | data[2];
```

`|` 是按位或，不是 `||`；`<<` 是位移，不是乘以 8。这里各段位不重叠，相加恰好也能得到同值，但按位或更直接表达“拼字段”。

高字节只使用低四位。当前代码发现 `data[1]&0xF0` 非零就返回失败；直接 `&0x0F` 虽能得到范围内数字，却会抹去这个异常线索。合法 raw=0 可以是真实零位，也可能是错误过程产生的零，必须结合返回值和磁场标志。

## 7. 三个层次的“有效”

| 层次 | 当前代码怎样判断 | 不能据此证明什么 |
| --- | --- | --- |
| 通信与格式 | sample 返回 1；I²C 事务成功且高字节格式通过 | 不保证磁铁合适，不是 CRC 校验 |
| 磁场状态 | STATUS 的 MD=1、ML=0、MH=0，输出 magnet_ok=1 | 不保证安装精度或电角零位已校准 |
| 可用于驱动 | 控制层结合校准、测流零点、状态和故障判断 | 不由一个 raw 数字单独决定 |

STATUS 的 bit5 是 MD、bit4 是 ML、bit3 是 MH，所以：

```c
*magnet_ok = (data[0] & 0x38u) == 0x20u;
```

例：STATUS=0x20 通过；STATUS=0x30 虽 MD=1，但 ML=1，不通过。芯片位定义依据 [AS5600 STATUS Register](https://www.mouser.com/datasheet/2/588/AS5600_DS000365_5_00-1877365.pdf)。

调用示例：

```c
uint16_t raw = 0u;
uint8_t magnet = 0u;
uint8_t ok = as5600_sample(&raw, &magnet);
```

`ok` 接收函数返回值，raw/magnet 通过输出指针修改。**返回值和两个输出值承担不同含义。** 失败时 raw 可能仍是调用前的值，不能不检查 ok 就当作新数据。

## 8. 本课完整中文注释传感器模块

以下文件实际替代本课 Target 的 BSP/as5600.c，接口及行为相同。正式项目仍使用正式文件。

```c
/*
 * 第四课：AS5600 传感器模块，接口及行为与正式 BSP/as5600.c 一致。
 * 本文件替代 as5600.c 参与本课编译；不要将两份实现同时加入同一个 Target。
 * 软件 I2C 时序仍复用 BSP/soft_i2c.c，PB10=SCL，PB11=SDA。
 */
#include "as5600.h"
#include "soft_i2c.h"

void as5600_init(void)
{
    /* sensor_bus 是 const SoftI2c 对象，& 取得它的地址。
     * 函数通过该对象知道 GPIO 端口及 SCL/SDA 位掩码。
     */
    soft_i2c_init(&sensor_bus);
}

/* 返回值：1=事务成功且角度格式有效；0=通信失败或高字节格式异常。
 * 输出：*raw 是 0~4095 单圈计数；*magnet_ok 是独立的磁场状态。
 * 调用方必须提供两个有效的输出指针；实际 TIM4 调用用 &raw、&magnet。
 */
uint8_t as5600_sample(uint16_t *raw, uint8_t *magnet_ok)
{
    uint8_t data[3];
    /* 提前清零磁场标志，失败时不能沿用上次的“磁场正常”。 */
    *magnet_ok = 0u;

    /* 0x36 是七位设备地址，函数内部生成 0x6C 写方向和 0x6D 读方向。
     * 从 STATUS=0x0B 开始，依次读 STATUS、RAW_H=0x0C、RAW_L=0x0D。
     * 数组名 data 在调用表达式中转换为指向第一个元素的指针。
     */
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, data, 3u))
        return 0u;

    /* 12 位角度的高字节只有低四位有效。
     * 检测到高四位非零就拒绝，不用 &0x0F 把异常隐藏成合法角度。
     */
    if (data[1] & 0xF0u)
        return 0u;

    /* 左移 8 位为低字节留位置，再按位或：0x01 和 0xB3 组合为 0x01B3=435。
     * *raw 修改调用者的变量；raw 本身是地址。
     */
    *raw = ((uint16_t)data[1] << 8) | data[2];

    /* STATUS 位：bit5=MD，bit4=ML，bit3=MH。
     * 掩码 0x38 只保留这三位；要求 MD=1、ML=0、MH=0，即结果为 0x20。
     * 因而返回 1 时，*magnet_ok 仍可能为 0：通信与磁场是两个条件。
     */
    *magnet_ok = (data[0] & 0x38u) == 0x20u;
    return 1u;
}

/* 保留正式接口。TIM4 的正常采样使用上面的 sample，不再另做这一笔读取。 */
uint8_t as5600_raw(uint16_t *raw)
{
    uint8_t data[2];
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Cu, data, 2u) || (data[0] & 0xF0u))
        return 0u;
    *raw = ((uint16_t)data[0] << 8) | data[1];
    return 1u;
}

/* 独立读磁场状态的备用接口；正常 sample 已同时返回状态，无须每帧再调用。 */
uint8_t as5600_magnet_ok(void)
{
    uint8_t status = 0u;
    return soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, &status, 1u) &&
           ((status & 0x38u) == 0x20u);
}
```

读代码时先关注 sample；raw 和 magnet_ok 两个独立接口作为对照保留。TIM4 使用 sample，正常周期不会再额外调用这两个接口。

## 9. 调用者：TIM4 每 1 ms 做什么？

```c
void TIM4_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM4, TIM_IT_Update))
    {
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
        uint32_t begin = board_cycles();
        uint16_t raw = 0u;
        uint8_t magnet = 0u;
        /* 单次连续读同时取得状态和角度，消除每 100 帧第二次事务造成的耗时尖峰。 */
        uint8_t ok = as5600_sample(&raw, &magnet);
        motor_sensor_isr(raw, ok, magnet, board_cycles(), board_millis());
        uint32_t elapsed = board_cycles() - begin;
        motor_record_sensor_time(elapsed);
        if (elapsed > BOARD_SENSOR_BUDGET_US * 72u)
            motor_timing_fault(TIMING_SENSOR_TASK, elapsed);
    }
}
```

注意三点：

1. 真正读取总线的唯一正常采样入口在这里；main 不再重复读。
2. 传给 motor_sensor_isr 的 cycles 是这次 I²C 返回后取到的 CPU 周期时间戳，ms 是系统毫秒计数。
3. 任务耗时从读取前到处理后，包含 I²C 和更高优先级中断抢占。900 μs 是当前工程预算，任务频率和预算不是同一个量。

连续读取同时取得状态和角度，省去旧方案周期性增加的一笔状态事务，避免该事务形成额外耗时尖峰。这是已有工程修订的原因，不是本轮新做的性能实验。

当前采样在 TIM4 中断里执行，是本工程为 1 kHz 反馈与任务优先级作出的实现选择；不能推广成“所有 I²C 都应该放中断”。OLED 的软件 I²C 在主循环，USART1、ADC 和 PendSV 的优先级与工作划分在后续调度课展开。

## 10. 跨零与 AngleTracker：从单圈变成累计计数

先复习最容易遗漏的前提：**相邻有效采样的真实机械位移绝对值必须小于半圈。** 真实转过 +230° 时，最短路径算法会解释成 -130°；恰好半圈也无法靠两次角度判方向。

```c
int32_t cm_angle_delta(uint16_t now, uint16_t before)
{
    int32_t d = (int32_t)now - (int32_t)before;
    if (d > 2048)
        d -= 4096;
    else if (d < -2048)
        d += 4096;
    return d;
}
```

4095→3：直接差值 -4092，修正后 +4。

3→4092：直接差值 +4089，修正后 -7。

工程结构体：

```c
typedef struct
{
    uint16_t previous;
    int64_t continuous;
    uint8_t valid;
} AngleTracker;
```

`valid` 表示有没有上一帧，previous 数值恰好为 0 也可以完全有效。`AngleTracker t={0};` 把各成员初始化为零，所以最初 valid=0。

```c
uint8_t cm_tracker_update(AngleTracker *t, uint16_t raw, int32_t *delta)
{
    if (!t->valid)
    {
        t->continuous = raw;
        t->previous = raw;
        t->valid = 1u;
        *delta = 0;
        return 0u;
    }
    *delta = cm_angle_delta(raw, t->previous);
    t->continuous += *delta;
    t->previous = raw;
    return 1u;
}
```

连续计数要容纳负数和多圈，使用 int64_t 扩大累计范围。输出 delta 只是一帧的增量，int32_t 足够。每次成功累计后必须写回 previous，不能仍拿首次角度做所有差分。

| raw 序列 | 返回 has_delta | delta | continuous |
| --- | ---: | ---: | ---: |
| 4095（首帧） | 0 | 0 | 4095 |
| 3 | 1 | 4 | 4099 |
| 4092 | 1 | -7 | 4092 |

首帧返回 0 只表示本帧还没有可测速的两点差分，不表示传感器通信失败。

64 位累计并不使后续 float 获得 64 位精度。当前先计算 `continuous-position_origin` 再转 float，减少直接转巨大累计值导致的精度损失；相对转动范围极大时，float 仍有精度限制。

## 11. 三种“零位”：不要把 raw 与位置混在一起

工程位置公式：

\[
position_{rad}=direction\,(continuous-origin)\frac{2\pi}{4096}
\]

| 概念 | 来源 | 当前用途 |
| --- | --- | --- |
| 传感器单圈零 | AS5600 对磁铁的参考方向 | raw 从 4095 回绕到 0 |
| 项目位置原点 | position_origin 保存某一累计计数 | 位置模式的相对机械位置 |
| 电角零偏 | 对齐校准得到 electrical_zero | FOC 坐标系，后续校准课详讲 |

本项目在 tracker 首帧建立时，把 origin 设为 continuous，因此启动的 raw 可以是 3000，但相对 position 为 0。`zero` 操作更新位置原点，不改变 AS5600 内部 raw。

direction 是软件坐标符号，通常由校准确定为 +1 或 -1，作用于位置和速度。raw 自身仍按传感器原有方向变化。

例：首帧 raw=4095，下一帧 raw=3，origin=4095。累计值为 4099：

- direction=+1：相对位置 +4 count，约 +0.3515625°。
- direction=-1：相对位置约 -0.3515625°。
- raw=3 的单圈角始终约 0.263671875°。

## 12. 实际时间差：1 kHz 不意味着永远精确 1 ms

当前 DWT 以 CPU 周期计数，72 MHz 下 72000 count 对应 1 ms：

```c
float dt = (float)(uint32_t)(cycles - sensor_previous_cycles) /
           (float)BOARD_CPU_HZ;
sensor_previous_cycles = cycles;
```

减法先在无符号 32 位整数范围完成，再转浮点。计数回绕时，只要相邻有效时间戳间隔小于一个完整计数周期，差值仍能表示真实经过的计数。72 MHz 下完整周期约 59.65 s。

例如 previous=0xFFFF0000、now=0x00001940：无符号差为 72000，仍是 1 ms。不要先把两个大时间戳各自转 float 再相减，否则可能丢失低位时间分辨率。

当前时间戳位于读取完成附近，因此 dt 包括不同轮次读数完成时刻的间隔，比固定代入 0.001 s 更合理；它不是 AS5600 内部转换瞬间的硬件时间戳，也不消除传感器本身延迟。

原始速度：

\[
\omega=direction\frac{delta\,(2\pi/4096)}{dt}\quad[rad/s]
\]

\[
n=direction\frac{delta\,60}{4096\,dt}\quad[rpm]
\]

| delta | dt | direction | 原始速度 |
| ---: | ---: | ---: | ---: |
| 1 | 1 ms | +1 | 14.6484375 rpm |
| 1 | 10 ms | +1 | 1.46484375 rpm |
| 4 | 1 ms | -1 | -58.59375 rpm |

采样更快会使相邻帧每 count 对应的瞬时 rpm 台阶更大，低速时容易出现 0 与较大数值交替。提高采样频率不自动提高差分测速的低速分辨能力；这也是要滤波的原因之一。

## 13. 当前滤波：按 dt 计算，不固定 alpha

实际代码保留内部速度单位 rad/s：

```c
float speed = (float)config.sensor_direction * (float)delta * counts_to_rad / dt;
speed_filtered += (dt / (BOARD_SPEED_FILTER_TAU_S + dt)) *
                  (speed - speed_filtered);
status.speed_rpm = speed_filtered * (60.0f / APP_TAU);
```

当前 tau=0.02 s，采用一阶低通的后向欧拉离散形式：

\[
\alpha=\frac{dt}{\tau+dt},\qquad y_k=y_{k-1}+\alpha(x_k-y_{k-1})
\]

dt=0.001 s 时 alpha=1/21≈0.047619。旧滤波值 10 rpm，新原始值 0 rpm，更新一次约为 9.52381 rpm。公式是线性的，同一系数可用于手算 rpm；实际代码在 rad/s 下计算，最后转换单位。

以前讲过的 `alpha=1-exp(-dt/tau)` 是另一种离散方式，两者小 dt 时接近，但不完全相等。**本课解释当前工程实际采用的 dt/(tau+dt)，不要把两个系数混填。**

tau 增大：更平滑，跟随更慢。tau 减小：响应更快，噪声更容易进入反馈。滤波后的速度可能在刚反转时仍保留旧符号，不能仅凭这一帧认定方向配置反了。

## 14. 通信失败、首帧与异常 dt：按真实代码理解

motor_sensor_isr 的角度反馈部分如下；省略了后面的校准/速度环/位置环计算：

```c
/* motor_sensor_isr 函数内部摘录；反馈发布及外环代码未列出。 */
    ++status.sensor_samples;
    status.sensor_ok = ok;
    status.magnet_ok = magnet;
    if (!ok)
    {
        ++status.sensor_errors;
        tracker.valid = 0u;
        if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
            motor_fault(FAULT_SENSOR);
        return;
    }
    if (!magnet && (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING))
    {
        motor_fault(FAULT_MAGNET);
        return;
    }
    int32_t delta = 0;
    uint8_t has_delta = cm_tracker_update(&tracker, raw, &delta);
    /* CPU 周期差转为秒；先做无符号减法，再转浮点，兼容 32 位周期计数回绕。 */
    float dt = (float)(uint32_t)(cycles - sensor_previous_cycles) / (float)BOARD_CPU_HZ;
    sensor_previous_cycles = cycles;
    if (!has_delta)
    {
        speed_filtered = 0.0f;
        position_origin = tracker.continuous;
    }
    else if (dt > 0.004f || dt < 0.0002f)
    {
        if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
            motor_timing_fault(TIMING_SENSOR_INTERVAL, (uint32_t)(dt * (float)BOARD_CPU_HZ));
        speed_filtered = 0.0f;
    }
    else
    {
        float speed = (float)config.sensor_direction * (float)delta * counts_to_rad / dt;
        /* 系数随实际 dt 计算；20 ms 时间常数减少低速速度环的反馈滞后。 */
        speed_filtered += (dt / (BOARD_SPEED_FILTER_TAU_S + dt)) * (speed - speed_filtered);
    }
    float position = (float)config.sensor_direction *
                     (float)(tracker.continuous - position_origin) * counts_to_rad;
    status.raw = raw;
    status.position_rad = position;
    status.speed_rpm = speed_filtered * (60.0f / APP_TAU);
```

| 情形 | 当前工程的实际处理 |
| --- | --- |
| 通信或角度格式失败，ok=0 | sensor_errors 增加，tracker.valid=0；运行/校准中锁存 SENSOR 故障；本次提前返回 |
| 恢复后的首帧 | 重建 tracker，更新 previous 时间戳，速度滤波清零，并重新建立 position_origin |
| 磁场无效但通信成功 | 运行/校准中锁存 MAGNET 故障并返回；STOP 下仍可更新数值，因此数值要与 mag 一起看 |
| has_delta=0 | 是差分起点，不能声称计算出本帧真实零转速 |
| 有增量但 dt<0.2 ms 或 dt>4 ms | 当前帧滤波速度清零；运行/校准中锁存相应 TIMING；tracker 在此前已经更新 |

有两个容易读错的细节：

1. **通信失败后首帧会重建相对位置原点。** 它不保证继续保留故障前多圈位置；离线期间轴转了几圈也无法由单圈 AS5600 恢复。
2. **dt 越界分支没有把 tracker.valid 清零。** 不能把它描述成“全部状态复位”；这是当前实现的具体行为。时间门限也不能数学证明期间位移小于半圈。

传感器失败时 raw、position、speed 可能保留旧值；ok=0 时这些旧数值不能被当作新鲜有效反馈。sensor_samples 记录任务尝试次数，不是成功读取次数。

## 15. 本课完整入口：观察快照，不重复读取

```c
/* 第四课：使用真实 TIM4 采样链；主循环只观察状态，不再次读取 AS5600。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include <stdio.h>

/* 500 ms 观察一次，不把打印周期当作采样周期。
 * snapshot 在原接口内部同步复制，避免跨中断读取不一致的结构体。
 */
static void print_sensor_snapshot(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    char line[224];
    (void)snprintf(line, sizeof(line),
                   "L4 t=%lu r=%u single100=%ld pos100=%ld rpm10=%ld "
                   "ok=%u mag=%u n=%lu err=%lu sens_us=%lu\r\n",
                   (unsigned long)board_millis(), (unsigned)s.raw,
                   (long)((float)s.raw * (36000.0f / 4096.0f)),
                   (long)(s.position_rad * (18000.0f / APP_PI)),
                   (long)(s.speed_rpm * 10.0f),
                   (unsigned)s.sensor_ok, (unsigned)s.magnet_ok,
                   (unsigned long)s.sensor_samples, (unsigned long)s.sensor_errors,
                   (unsigned long)(s.sensor_max_cycles / (BOARD_CPU_HZ / 1000000u)));
    console_message(line);
}

int main(void)
{
    AppParams params;
    board_init();
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init(); /* 本课实际链接 lesson04_sensor.c 中的同名接口。 */
    ir_receiver_init();
    console_init();
    console_message("Lesson04 v1.1.7: AS5600 -> tracker -> speed -> snapshot\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");
    board_start_control();
    ui_init();
    board_watchdog_start();

    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t last_samples = 0u, last_steps = 0u;
    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 500u)
        {
            last_print_ms = now;
            print_sensor_snapshot();
        }
        /* 保留实际工程的任务心跳检查；界面循环运行不等于采样与控制都活着。 */
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != last_samples && s.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = s.sensor_samples;
            last_steps = s.current_steps;
        }
    }
}
```

相比正式入口，本课增加 500 ms 一条 L4 日志。板级调度、控制与菜单复用当前模块，传感器同名接口链接到 lesson04_sensor.c。

学习工程单独打开 **ControlPanel_Lesson04.uvprojx → Lesson04_NoKnob**。不能把本课 main 和正式 App/main.c、两份 as5600 实现同时加入一个 Target。

Tools/make_learning_project.py 可生成各课独立工程。练习时修改 lesson04_sensor.c；正式 BSP/as5600.c 是对照。HEX 在 Objects/Lesson04/Lesson04_NoKnob.hex。

后续上板仅保持 STOP，沿用已经确认的接线，用手缓慢正反向转轴观察一次即可，不需要重新做整套边界和故障注入。本轮未执行烧录。

预期日志格式，以下不是实测：

```text
L4 t=... r=... single100=... pos100=... rpm10=... ok=1 mag=1 n=... err=0 sens_us=...
```

| 字段 | 含义与单位 |
| --- | --- |
| r | 最近一次更新到状态的单圈 raw |
| single100 | raw 对应的单圈机械角×100，整数截断 |
| pos100 | 含 direction 与原点的相对多圈机械角×100 |
| rpm10 | 滤波后的机械转速×10，整数截断 |
| ok / mag | 最近任务记录的通信格式结果 / 磁场状态 |
| n | sensor_samples，尝试次数；正常约每秒增加 1000 |
| err | 通信/格式失败累计次数，不是串口 drop |
| sens_us | 已观察到的传感器任务最大耗时，含 I²C，不是每帧即时耗时 |

相邻 L4 行约相隔 500 ms；内部采样仍约 1 ms。不能拿两行 raw 的差配上 1 ms 求瞬时速度，更不能在可能转过多圈的 500 ms 中仅由单圈差恢复真实位移。

`log 0` 可关掉常规 10 Hz 遥测，让 L4 更容易看；它不关闭本课专用 L4 行。第三课的 echo/uart 命令只在第三课独立工程，本课使用正式 console 命令。

## 16. 从“能读懂”到“能下手写”

本课只完成一个主要编码任务：**合上参考，自己写 as5600_sample 的函数体。**

先写清输入输出：输入是两个输出变量的地址；中间数据来自一次三字节读取；返回值表示通信和格式结果，磁场结果另写到指针。

伪代码：

```text
建立 3 字节局部数组
先把调用者的 magnet_ok 清零
从设备 0x36、寄存器 0x0B 读三个字节
如果失败，返回 0
如果 RAW_H 的高四位非零，返回 0
组合 RAW_H 和 RAW_L，写入调用者 raw
按位掩码判断磁场，写入调用者 magnet_ok
返回 1
```

先填三个表达式：

```c
/* data[0]=STATUS，data[1]=RAW_H，data[2]=RAW_L。 */
if (data[1] & /* A：高四位掩码 */)
    return 0u;
*raw = /* B：组合两个字节 */;
*magnet_ok = /* C：只接受 MD=1、ML=MH=0 */;
```

参考：A=`0xF0u`；B=`((uint16_t)data[1]<<8)|data[2]`；C=`(data[0]&0x38u)==0x20u`。

写完后对照模块检查一遍，再编译。已有跨零学习不必重复写另一套板级追踪器；本次能解释 cm_tracker_update 和实际调用者即可。

## 17. 自测题

1. PB10/PB11 当前走硬件 I2C2 还是 GPIO 软件 I²C？为什么？
2. 七位地址 0x36 对应线上写/读地址字节各是多少？0x0B 又是什么？
3. 读取三个字节时，最后一个字节为什么由 STM32 发 NACK？是否代表通信出错？
4. data={0x20,0x01,0xB3} 时 raw、磁场结果及单圈角约是多少？
5. 若把 STATUS 改为 0x30，sample 能否返回 1？magnet_ok 是多少？
6. AngleTracker 哪个成员表示“已有上一帧”？首帧返回 0 是通信失败吗？
7. 首帧 4095，第二帧 3，第三帧 4092：后两帧 delta 和 continuous 各是多少？
8. origin=4095、continuous=4099、direction=-1，位置约多少度？
9. delta=1、dt=1 ms，原始机械速度多少 rpm？dt=10 ms 呢？
10. tau=20 ms、dt=1 ms，alpha 是多少？y_old=10 rpm、x=0，y_new 是多少？
11. 通信失败后恢复，为什么不能承诺保留断线前多圈位置？当前原点怎样变化？
12. L4 每 500 ms 输出一次，能否用两行 raw 之差除以 1 ms？n 是否是成功次数？

### 参考答案

1. 软件 I²C；代码通过 GPIO 写电平并读引脚，而非硬件 I2C2 事务接口。
2. 写 0x6C、读 0x6D；0x0B 是芯片内部 STATUS 地址。
3. 表示主机已取够字节，正常结束读取，随后 STOP。
4. raw=435，magnet_ok=1，约 38.2324°。
5. 能，通信和角度格式仍通过；磁场输出为 0。
6. valid；不是，首帧建立差分起点。
7. 第二帧 delta=4、continuous=4099；第三帧 delta=-7、continuous=4092。
8. -0.3515625°；raw 的单圈零与相对位置原点不同。
9. +14.6484375 rpm、+1.46484375 rpm（direction=+1）。
10. 1/21≈0.047619；约 9.52381 rpm。
11. AS5600 不记录断线期间整圈数；恢复首帧重建 tracker，并把 origin 设为该帧累计起点。
12. 不能，两个时间尺度不同且可能已多圈回绕；n 是任务尝试次数。

## 18. 本课产出与简历积累

留下三样东西：

1. 一张“磁铁→I²C 字节→raw→累计计数→位置/速度→日志”的数据链图。
2. 自己重写并编译通过的 sample 函数，以及上述自测答案。
3. 后续实际手转时的一组正反向或跨零日志，注明 STOP、方向参数、采样和打印周期。实测前写“待测”。

面试的一分钟讲解：

> 我通过软件 I²C 一次连续读取 AS5600 状态和 12 位角度，分别判断通信格式与磁场状态。相邻单圈角按最短增量跨零累计，再按校准方向和软件原点得到机械位置；用读取完成时间戳的实际间隔测速，并按时间常数滤波。通信恢复后重建差分起点，不把断线前的多圈坐标当作仍然可靠。串口只抽样显示反馈，读取与计算频率独立。

能解释和实现这些内容后，再把对应能力写进个人贡献；已有工程运行结果与自己完成的模块学习记录分开保存。

**下一课：PWM 与定时调度。** 把 TIM2 的 15 kHz 载波、ADC 的采样触发、TIM4 的 1 kHz 角度任务和分频控制放进同一张时间表，解释 PSC/ARR/CCR 与预装载。
