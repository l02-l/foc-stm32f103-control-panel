/* 第四课：使用真实 TIM4 采样链；主循环只观察状态，不再次读取 AS5600。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include <stdio.h>

/* 500 ms 观察一次，不把打印周期当作采样周期。
 * snapshot 在原接口内部同步复制，避免跨中断读取不一致的结构体。
 */
static void print_sensor_snapshot(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    char line[224];
    (void)snprintf(line, sizeof(line),
                   "L4 t=%lu r=%u single100=%ld pos100=%ld rpm10=%ld "
                   "ok=%u mag=%u n=%lu err=%lu sens_us=%lu\r\n",
                   (unsigned long)board_millis(), (unsigned)s.raw,
                   (long)((float)s.raw * (36000.0f / 4096.0f)),
                   (long)(s.position_rad * (18000.0f / APP_PI)),
                   (long)(s.speed_rpm * 10.0f),
                   (unsigned)s.sensor_ok, (unsigned)s.magnet_ok,
                   (unsigned long)s.sensor_samples, (unsigned long)s.sensor_errors,
                   (unsigned long)(s.sensor_max_cycles / (BOARD_CPU_HZ / 1000000u)));
    console_message(line);
}

int main(void)
{
    AppParams params;
    board_init();
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init(); /* 本课实际链接 lesson04_sensor.c 中的同名接口。 */
    ir_receiver_init();
    console_init();
    console_message("Lesson04 v1.1.7: AS5600 -> tracker -> speed -> snapshot\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");
    board_start_control();
    ui_init();
    board_watchdog_start();

    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t last_samples = 0u, last_steps = 0u;
    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 500u)
        {
            last_print_ms = now;
            print_sensor_snapshot();
        }
        /* 保留实际工程的任务心跳检查；界面循环运行不等于采样与控制都活着。 */
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != last_samples && s.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = s.sensor_samples;
            last_steps = s.current_steps;
        }
    }
}
