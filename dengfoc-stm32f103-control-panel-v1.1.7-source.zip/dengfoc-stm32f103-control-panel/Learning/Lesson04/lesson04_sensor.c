/*
 * 第四课：AS5600 传感器模块，接口及行为与正式 BSP/as5600.c 一致。
 * 本文件替代 as5600.c 参与本课编译；不要将两份实现同时加入同一个 Target。
 * 软件 I2C 时序仍复用 BSP/soft_i2c.c，PB10=SCL，PB11=SDA。
 */
#include "as5600.h"
#include "soft_i2c.h"

void as5600_init(void)
{
    /* sensor_bus 是 const SoftI2c 对象，& 取得它的地址。
     * 函数通过该对象知道 GPIO 端口及 SCL/SDA 位掩码。
     */
    soft_i2c_init(&sensor_bus);
}

/* 返回值：1=事务成功且角度格式有效；0=通信失败或高字节格式异常。
 * 输出：*raw 是 0~4095 单圈计数；*magnet_ok 是独立的磁场状态。
 * 调用方必须提供两个有效的输出指针；实际 TIM4 调用用 &raw、&magnet。
 */
uint8_t as5600_sample(uint16_t *raw, uint8_t *magnet_ok)
{
    uint8_t data[3];
    /* 提前清零磁场标志，失败时不能沿用上次的“磁场正常”。 */
    *magnet_ok = 0u;

    /* 0x36 是七位设备地址，函数内部生成 0x6C 写方向和 0x6D 读方向。
     * 从 STATUS=0x0B 开始，依次读 STATUS、RAW_H=0x0C、RAW_L=0x0D。
     * 数组名 data 在调用表达式中转换为指向第一个元素的指针。
     */
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, data, 3u))
        return 0u;

    /* 12 位角度的高字节只有低四位有效。
     * 检测到高四位非零就拒绝，不用 &0x0F 把异常隐藏成合法角度。
     */
    if (data[1] & 0xF0u)
        return 0u;

    /* 左移 8 位为低字节留位置，再按位或：0x01 和 0xB3 组合为 0x01B3=435。
     * *raw 修改调用者的变量；raw 本身是地址。
     */
    *raw = ((uint16_t)data[1] << 8) | data[2];

    /* STATUS 位：bit5=MD，bit4=ML，bit3=MH。
     * 掩码 0x38 只保留这三位；要求 MD=1、ML=0、MH=0，即结果为 0x20。
     * 因而返回 1 时，*magnet_ok 仍可能为 0：通信与磁场是两个条件。
     */
    *magnet_ok = (data[0] & 0x38u) == 0x20u;
    return 1u;
}

/* 保留正式接口。TIM4 的正常采样使用上面的 sample，不再另做这一笔读取。 */
uint8_t as5600_raw(uint16_t *raw)
{
    uint8_t data[2];
    if (!soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Cu, data, 2u) || (data[0] & 0xF0u))
        return 0u;
    *raw = ((uint16_t)data[0] << 8) | data[1];
    return 1u;
}

/* 独立读磁场状态的备用接口；正常 sample 已同时返回状态，无须每帧再调用。 */
uint8_t as5600_magnet_ok(void)
{
    uint8_t status = 0u;
    return soft_i2c_read_reg(&sensor_bus, 0x36u, 0x0Bu, &status, 1u) &&
           ((status & 0x38u) == 0x20u);
}
