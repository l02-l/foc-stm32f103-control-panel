# 第六课：两相电流测量、ADC 零点与安培换算

日期：2026-11-07。基线：**v1.1.7，无旋钮，STM32F103C8T6 标准外设库**。建议 10～12 小时，分三次完成。

## 0. 本课目标与文件

第五课把电流采样放进 PWM 时间轴。本课解释：**ADC 读到 2050，怎样知道这是多少安培？为什么零电流不是 ADC=0？**

学完应能推导计数到电流的比例，独立写换算函数，解释启动零点平均、第三相重建与原始过流检查。先读第 1～7 节的电路和公式，再读真实代码，最后完成一个函数和一次停机观察。

| 文件 | 用途 |
| --- | --- |
| [V3P 驱动板原理图](../../Docs/HARDWARE_REFERENCE.md) | R15/R16、U6/U7、参考端和信号方向 |
| [STM32 转接板原理图](../../Docs/HARDWARE_REFERENCE.md) | M0_OUT1_CS/M0_OUT2_CS 与主控连接 |
| [BSP/board.c](../../BSP/board.c) | PB0/PB1 模拟输入、ADC 注入组与中断 |
| [Control/motor.c](../../Control/motor.c) | 实际启动校零、计数发布、相电流换算和故障处理 |
| [lesson06_current.c](lesson06_current.c) / [头文件](lesson06_current.h) | 本课实际接入的中文注释换算函数 |
| [motor_lesson06.c](motor_lesson06.c) | 从正式 motor 生成，将两相换算接入本课函数 |
| [main.c](main.c) | 每 500 ms 输出一帧原始计数、零点和计算电流 |
| [第六课 Keil 工程](../../ControlPanel_Lesson06.uvprojx) | Target：Lesson06_NoKnob |
| [编译记录](build.log) | ARM Compiler 6.18，0 错误、0 警告 |

本轮已核对原理图并编译学习工程，**尚未烧录、测量实际电流或实测 L6 日志**。手算使用标称参数；不把理论换算系数作为精度标定结果。

## 1. ADC 测的是电压，电流先经过采样电阻

```mermaid
flowchart LR
    I[电机相电流 A] --> R[0.01Ω 采样电阻]
    R --> V[毫伏级差分电压]
    V --> AMP[INA240A2 放大与中点偏置]
    AMP --> PIN[PB0/PB1 模拟电压]
    PIN --> ADC[ADC1 注入组 12位计数]
    ADC --> ZERO[减实际零点]
    ZERO --> SCALE[按比例和符号换算]
    SCALE --> PHASE[Ia/Ib 单位 A]
```

欧姆定律：

\[
V_{shunt}=I\,R_{shunt}
\]

0.2 A 通过 0.01 Ω，只产生 0.002 V，也就是 **2 mV**。为了让 ADC 更容易分辨，需要把这个小差分电压放大。

| 量 | 常用单位 | 本机例子 |
| --- | --- | --- |
| 电流 I | A、mA | 0.2 A=200 mA |
| 电阻 R | Ω、mΩ | 0.01 Ω=10 mΩ |
| 差分电压 | V、mV | 2 mV=0.002 V |
| ADC 原始量 | count | 0～4095，不是电压或电流单位 |

不要把采样电阻与电机绕组电阻混为一谈；也不要把母线电压 12 V 直接代入 ADC 电流换算。

## 2. 原理图：两路相内采样，而非母线总电流

下图摘自驱动板原理图，仅裁出 M0 两路测量前端：

本节的 R15/R16、U6/U7 说明来自原套件原理图；仓库不附原理图截图，见 [硬件资料来源](../../Docs/HARDWARE_REFERENCE.md)。

| 元件/信号 | 原理图所示 |
| --- | --- |
| R15、R16 | 分别串在 M0_OUT1、M0_OUT2 相线上，标值 0.01 Ω |
| U6、U7 | INA240A2PWR |
| IN+ / IN- | 分别接相线的 N / P 侧 |
| REF1 / REF2 | REF1 接 GND，REF2 接 3V3 |
| VS | 3V3 |
| OUT | M0_OUT1_CS、M0_OUT2_CS 模拟采样信号 |

电流检测在相线上，放大器观察电阻两端的电压差。这两端的对地电压会随桥臂开关变化，称为共模变化；它与小幅差分压降不是一个量。

例如两端都在约 12 V 附近，彼此只相差几 mV。放大器的任务是提取这几 mV，并把结果转成 ADC 可接收的对地电压。ADC 不直接连接那两根 12 V 相线。

INA240A2 的固定增益为 50 V/V；一参考端接地、另一端接电源时，无差分输入的输出约为半电源。器件特性依据 [TI INA240 数据手册，增益与参考端章节](https://www.ti.com/lit/ds/symlink/ina240.pdf)。

这解释了为什么板子在零电流时，输出可能接近 1.65 V，ADC 接近 2048。它是为了在单电源下同时表示正负电流，并非输出一直应该为 0 V。

## 3. 为什么软件对 A/B 都乘 -1？

按原理图，选取从桥臂 P 侧流向电机 N 侧为本段推导的正方向。电阻压降满足：

\[
V_P-V_N=I\,R
\]

但放大器 IN+=N、IN-=P，所以差分输入：

\[
V_{IN+}-V_{IN-}=V_N-V_P=-I\,R
\]

名义输出因此是：

\[
V_{out}\approx V_0-GRI
\]

本机 GR=50×0.01=0.5 V/A。以 V0=1.65 V 为例：

| 选定方向的相电流 | 名义输出 |
| ---: | ---: |
| +0.2 A | 1.55 V |
| 0 A | 1.65 V |
| -0.2 A | 1.75 V |

**电流沿正方向增大时，这种接法下采样输出下降。** 当前例程和完整项目对 A/B 使用 -1，把输出变化转回相电流的方向约定。

电流方向符号不是 AS5600 的 sensor_direction；前者属于电流测量坐标，后者属于轴角坐标。也不能因为电流出现负数就随意反号或取绝对值。

## 4. ADC 引脚、通道与“注入组”

当前代码连接：

| 相 | 引脚 | ADC 通道 | 注入序列次序 | 读取位置 |
| --- | --- | --- | --- | --- |
| A | PB0 | ADC_Channel_8 | rank1 | ADC_InjectedChannel_1 / JDR1 |
| B | PB1 | ADC_Channel_9 | rank2 | ADC_InjectedChannel_2 / JDR2 |

通道 8 不等于第 8 个注入结果。通道是输入选择，rank 是本次序列中的位置。PB0/PB1 的 ADC 功能见 [ST STM32F103x8/xB 引脚表](https://www.st.com/resource/en/datasheet/stm32f103c8.pdf)。

```c
ADC_InjectedSequencerLengthConfig(ADC1, 2);
ADC_InjectedChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_7Cycles5);
ADC_InjectedChannelConfig(ADC1, ADC_Channel_9, 2, ADC_SampleTime_7Cycles5);
ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_T2_TRGO);
```

沿用第五课配置：TIM2 每 66.667 μs 触发一组，两路按顺序完成，再在 JEOC 中断取出结果：

```c
void ADC1_2_IRQHandler(void)
{
    if (ADC_GetITStatus(ADC1, ADC_IT_JEOC))
    {
        uint16_t a = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
        uint16_t b = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
        ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
        motor_adc_isr(a, b);
    }
}
```

本项目采用 PWM 触发注入转换，不是早期教程的连续扫描加 DMA。不要重新加第二套 AD_Init 或在主循环重复软件启动 ADC。

两路不是严格同一瞬间采样；但每次中断读到的是该序列的两个结果，不是随意轮询两次 ADC。后面第三相重建要记住这个时间差。

## 5. 从计数推导到安培：只需三步

12 位 ADC 的理想量化步长：

\[
V_{LSB}=\frac{V_{ref}}{4096}
\]

本机 BOARD_ADC_VREF=3.3 V，因此一 count 约 0.805664 mV。4096 是量化级数，最大码为 4095。某些旧例程按端点近似使用 4095；本工程统一按 4096 推导，二者约 0.0244% 的差异并不是几十 mA 零点残差的主要解释。

第一步，减掉零电流时实际平均计数：

\[
\Delta N=N_{ADC}-N_0
\]

第二步，换成放大器输出的电压变化：

\[
\Delta V=\Delta N\frac{V_{ref}}{4096}
\]

第三步，除以增益与采样电阻，再考虑方向：

\[
I=sign\frac{\Delta V}{GR}
=sign\,(N_{ADC}-N_0)\frac{V_{ref}}{4096GR}
\]

按当前参数：

\[
K_I=\frac{3.3}{4096\times50\times0.01}
=0.001611328125\ A/count
\]

也就是 **每 count 约 1.61133 mA**，A/B 的 sign=-1。

### 先做一个完整手算

给定 offset=2048、ADC=1984：

```text
计数差：1984-2048 = -64 count
输出变化：-64 × 3.3/4096 = -0.0515625 V
相电流：-0.0515625/(50×0.01) × (-1) = +0.103125 A
显示：约 +103 mA（转整数时截断）
```

不要把 offset=2048 count 写成 offset=1.65 V 传入同一个函数；单位不同，不能直接相减。

## 6. 为什么不能把零点写死为 2048？

2048 来自理想中点假设。实际放大器失调、参考端、电源/地、ADC 偏置以及温度会改变零点。上电后应在已知无驱动电流条件下平均真实读数，得到 offset_a/offset_b。

本机模拟前端与 ADC 参考都标称 3.3 V，但仍不能据此认定实际比例和零点完全理想。减零点主要消除加性偏移，不会自动校准采样电阻误差、增益误差或 ADC 参考电压比例。

**零点标定和比例标定不同：**

- 零点：0 A 时输出落在哪里，决定减多少。
- 比例：已知电流变化对应多少 count，决定每 count 是多少 A。

本课做零点与换算学习，未用已知电流做比例/符号实测标定。

### 三种“校准”也要分开

| 名称 | 当前入口 | 处理的问题 |
| --- | --- | --- |
| ADC 内部校准 | board 中 ADC_ResetCalibration / ADC_StartCalibration | ADC 自身校准，不知道外部放大器的零点 |
| 电流启动校零 | motor_adc_isr 累积 4096 次采样 | 得到外部测量链的零电流平均计数 |
| 电角/方向校准 | 串口 cal / motor_calibrate | 建立转子方向和 FOC 电角零偏 |

已保存电角校准参数，不代表电流零点也从 Flash 恢复。当前 motor_init 每次启动都清除零点累计并重新采样；cal 命令不等同于重新执行启动电流校零。

## 7. 当前启动校零：跨真实采样帧平均

前 4096 个 ADC 序列，在 ADC 中断里逐帧累加两路结果。按 15 kHz 标称采样率，收集所需时间约：

\[
4096/15000\approx0.2731\ s
\]

不是主循环空转 4096 次，也不是每轮 Delay_ms。ISR 每次处理新采样，后台仍可执行其他任务。

```text
motor_init 清空 sum_a/sum_b/count，offsets_ready=0
 → 启动 PWM 同步采样，驱动仍 STOP
 → 每一帧累加 a/b，count 加一
 → 达到 4096：浮点除法求平均
 → 平均值在宽范围内：offsets_ready=1
 → 后续用固定 offset 换算电流
```

现有 ADC 入口完整代码：

```c
void motor_adc_isr(uint16_t a, uint16_t b)
{
    status.adc_a = a;
    status.adc_b = b;
    if (!status.offsets_ready)
    {
        /* 此阶段 PA8 关闭，4096 次停机采样的平均值作为电流零点。 */
        offset_sum_a += a;
        offset_sum_b += b;
        if (++offset_count >= BOARD_OFFSET_SAMPLES)
        {
            status.offset_a = (float)offset_sum_a / (float)BOARD_OFFSET_SAMPLES;
            status.offset_b = (float)offset_sum_b / (float)BOARD_OFFSET_SAMPLES;
            if (status.offset_a < 512 || status.offset_a > 3584 || status.offset_b < 512 ||
                status.offset_b > 3584)
            {
                motor_fault(FAULT_ADC);
                offset_count = 0u;
                offset_sum_a = offset_sum_b = 0u;
            }
            else
                status.offsets_ready = 1u;
        }
        publish_current_sample(a, b);
        return;
    }
    if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
    {
        int da = (int)a - (int)status.offset_a, db = (int)b - (int)status.offset_b;
        /* 每次采样检查三相电流；A/B 同向增益下，C 相由 Ic=-Ia-Ib 推算。 */
        if (da > (int)trip_counts || da < -(int)trip_counts || db > (int)trip_counts ||
            db < -(int)trip_counts || (da + db) > (int)trip_counts || (da + db) < -(int)trip_counts)
        {
            motor_fault(FAULT_OVERCURRENT);
            return;
        }
    }
    /* 每 5 帧发布一次双相采样，请求 3 kHz PendSV 控制任务。 */
    publish_current_sample(a, b);
}
```

理解四处 C 细节：

1. 累加器是 uint32_t，最大和 4095×4096=16773120，当前样本数下可容纳；uint16_t 不够。
2. `++offset_count` 先加一再判断，首帧计数变 1。
3. 先转 float 再除，保留平均值小数。平均零点可以为 2050.5 count，不必是某次实际 ADC 码。
4. 如果写整数除法或先右移 12 位再转 float，会丢掉平均值小数。

512～3584 是当前代码给零点平均值的宽范围检查，不是精度标准，也没有检查每个样本的方差。混入扰动的平均值仍可能通过该范围；因此 off=1 只表示当前校零流程已通过这些条件。

平均值异常时当前代码锁存 ADC 故障、清空累加器重新尝试；后续平均成功不会自动解除先前故障。正常就绪后，当前代码不在每帧继续追踪零点，以免把真实相电流误当成新的零点。

## 8. 从 15 kHz 到 3 kHz：原始值和相电流不是同一个更新频率

ADC 入口每帧更新 status.adc_a/b；每 5 帧发布最新采样，PendSV 取出这一对并换算相电流：

```c
/* motor_current_task 内部摘录；此前完成序号检查，后续坐标变换与控制省略。 */
    uint16_t a = (uint16_t)pair, b = (uint16_t)(pair >> 16);
    uint32_t begin = board_cycles();
    ++status.current_steps;
    if (!status.offsets_ready)
    {
        status.ia = status.ib = status.id = status.iq = 0.0f;
        return;
    }
    status.ia = ((float)a - status.offset_a) * amps_per_count * BOARD_CURRENT_A_SIGN;
    status.ib = ((float)b - status.offset_b) * amps_per_count * BOARD_CURRENT_B_SIGN;
    SensorFrame f = sensor_frames[active_frame];
    uint8_t running = status.state == MOTOR_RUNNING,
            calibrating = status.state == MOTOR_CALIBRATING;
    if (!running && !calibrating)
    {
        status.ud = status.uq = status.iq_target = 0.0f;
        status.id = status.iq = 0.0f; /* 停机不保留最后一帧 CAL/RUN 的旧 d/q 电流显示。 */
        current_filter_valid = 0u;
        return;
    }
```

此处是正式代码摘录。本课将两条换算语句替换为 lesson06_amps_from_adc 调用，公式和参数保持一致。其他采样、校零、保护与控制逻辑不改。

STOP 时 ia/ib 仍可按零点计算，id/iq 则由当前代码清零。所以普通日志 `iq_mA=0 id_mA=0` 不能证明原始 A/B 测量残差恰好为零。

motor_snapshot 可以同步复制结构体，避免中断写一半时读到不完整状态；但它不会让 15 kHz 的 adc_a/b 与 3 kHz 的 ia/ib 自动属于同一采样帧。运行中不要拿两者逐项强行验证瞬时算式。

本课 L6 用同一快照中的最新 ADC 与零点在后台计算一组 calc_mA，因此这组计算值与该行 ADC 对应；真实控制任务也调用相同换算函数。

## 9. 无符号 ADC 为什么能得到负电流？

ADC 原始值是 uint16_t，只表示非负计数。负号来自“测量相对零点的差值”，与负电压直接进入 ADC 不是一回事。

正确顺序：

```c
float delta = (float)adc - offset;
return delta * amps_per_count * sign;
```

这样 delta 可正可负，还保留 offset 小数。不要把负差值先存进 uint16_t；也不要用 unsigned 类型包装差值后再指望它代表负数。

在某些 C 表达式中，小位宽整数会先提升为 int，并非所有 uint16_t 相减都必然无符号回绕。关键是**明确中间结果及保存对象的类型**，本课直接按 float 的计算路径写清楚。

## 10. 为什么两路测量能重建第三相？

对本机三线电机的端口电流，采用统一参考方向，理想情况下：

\[
i_a+i_b+i_c=0\quad\Rightarrow\quad i_c=-i_a-i_b
\]

例如 Ia=+103.125 mA、Ib=-51.5625 mA，则 Ic 估计为 -51.5625 mA。

限制：

- 这是第三相估计，不是第三个电阻或 ADC 独立量到的值。
- 两路顺序采样、开关瞬态、偏置与比例误差会影响估计。
- 由于 Ic 就按负和计算，“三相求和为零”是构造结果，不能反过来证明测量准确。

当前控制的 Clarke/Park 可直接使用 A/B 两路，不必先存一份 Ic 再变换；下一课详细讲坐标变换。本课的 Ic 主要用于理解三相关系和现有过流检查。

## 11. 零点残差、分辨率与噪声：怎样解释小电流？

每 count≈1.61133 mA。即使电机不驱动，ADC 在零点附近变化 1～2 count，就可能看到几 mA 的计算变化。平均 offset 有小数，所以单次残差也可以小于一 count 对应电流。

示例：offset=2050.5，ADC=2048，sign=-1：

\[
I=(-2.5)\times0.001611328125\times(-1)
\approx0.00402832\ A
\]

输出整数 mA 后显示 4，而不是程序自动知道真实有 4 mA。`(long)(amps*1000)` 截去小数部分，显示 0 也不意味着严格为零。

若零电流显示约 -35 mA，约相当于 +21.7 count 的残差。先区分零点漂移、采样耦合、供电/地、比例与符号问题，不要直接改增益把它调成 0。

启动平均有助于降低随机零点估计波动，但不能消除确定性偏差、相关噪声或后续温漂。实际精度不能仅由 12 位分辨率或一条平稳静态日志推断。

## 12. 目标限流与原始过流检查不是一件事

| 当前参数/路径 | 作用 |
| --- | --- |
| current_limit | 限制控制器的电流目标范围，默认参数为 0.20 A |
| trip_current | 原始测量超过阈值时锁存故障，默认参数为 0.60 A |
| d/q 电流反馈滤波 | 平滑 PI 使用的反馈，不用于延迟原始过流判断 |

保存参数可能覆盖默认值，实际使用值以当前配置为准。不能把默认数值当作每次上电保证不变的参数。

阈值换算使用相同比例：

```c
trip_counts = (uint16_t)(config.trip_current / amps_per_count);
```

按标称 0.60 A 计算约为 372.36 count，转换后 trip_counts=372。现有检查比较整数化零点后的 da/db 以及 da+db 的正负幅值；超过阈值才锁存过流。

为什么还检查 da+db？本机 A/B 使用同一比例、同一方向符号，第三相幅值可由二者负和估计。若只检查 A/B，可能漏掉两者同向叠加时 C 相较大的情况。若以后两路增益/方向不一致，不能直接沿用这个计数和公式。

当前检查在 RUN/CAL 中执行，使用未经过 d/q 低通的原始计数。它是 **ADC 中断中的软件故障处理**，不是独立模拟比较器的硬件瞬时关断，也不意味着电流波形永远不会越过目标或阈值。

本课理解现有路径，不通过制造大电流来验证过流。

## 13. 完整中文注释换算模块

```c
/*
 * 第六课：把“ADC 计数 -> 相电流”拆成可独立编写的函数。
 * 本课生成的 motor_lesson06.c 在真实 3 kHz 电流任务中调用此函数两次。
 * ADC 配置、启动零点平均、原始过流检查和控制状态逻辑沿用正式工程。
 */
#include "lesson06_current.h"
#include "app_config.h"

/* 每个 ADC count 对应多少 A。4096 是 12 位 ADC 的量化级数。
 * 3.3 / (4096 * 0.01 * 50) = 0.001611328125 A/count。
 * 它是按标称参数推算的比例，不表示实际测量准确到这个小数位。
 */
static const float amps_per_count =
    BOARD_ADC_VREF / (4096.0f * BOARD_SHUNT_OHMS * BOARD_CURRENT_GAIN);

float lesson06_amps_from_adc(uint16_t adc, float offset, float sign)
{
    /* 先转 float 再减零点，保留平均零点的小数部分，也能表示负差值。
     * offset 单位是 count，不能误传成 1.65 V。
     */
    float delta = (float)adc - offset;
    /* 本机 A/B 的 sign 都是 -1：电流正方向对应采样输出下降。
     * 不取绝对值，也不为让显示好看而把小电流强制清零。
     */
    return delta * amps_per_count * sign;
}

float lesson06_reconstruct_c(float ia, float ib)
{
    /* 三线电机满足 ia+ib+ic=0，第三相由前两相估计。
     * 顺序采样、偏置和瞬态会影响重建；求和为零是公式的结果，不能证明精度。
     */
    return -ia - ib;
}
```

换算函数只处理单位、零点与方向，不负责采 ADC，不猜测 offset 是否已经就绪。真实调用者在 offsets_ready 之后进入它。

重建函数供本课观察使用。为了保持控制行为，正式控制的 Clarke/Park 与原始过流逻辑仍按原实现运行。

## 14. 完整学习入口与工程接入

```c
/* 第六课：复用实际采样任务，后台每 500 ms 用一份快照观察电流换算。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include "lesson06_current.h"
#include <stdio.h>

static void print_current_snapshot(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    char line[224];
    if (!s.offsets_ready)
    {
        /* 未就绪时没有可用零点，不用默认 offset=0 算出虚假的几安培电流。 */
        (void)snprintf(line, sizeof(line),
                       "L6 off=0 adc=%u,%u calc_mA=NA st=%s fault=%s\r\n",
                       (unsigned)s.adc_a, (unsigned)s.adc_b,
                       motor_state_name(s.state), motor_fault_name(s.fault));
    }
    else
    {
        /* 同一快照里的最新 ADC 与零点用于本行计算，数值与下方原始计数对应。
         * 不将 3 kHz 的 s.ia/s.ib 和 15 kHz 的最新 ADC 冒充同一帧。
         */
        float ia = lesson06_amps_from_adc(s.adc_a, s.offset_a, BOARD_CURRENT_A_SIGN);
        float ib = lesson06_amps_from_adc(s.adc_b, s.offset_b, BOARD_CURRENT_B_SIGN);
        float ic = lesson06_reconstruct_c(ia, ib);
        (void)snprintf(line, sizeof(line),
                       "L6 off=1 adc=%u,%u z100=%ld,%ld calc_mA=%ld,%ld,%ld st=%s fault=%s\r\n",
                       (unsigned)s.adc_a, (unsigned)s.adc_b,
                       (long)(s.offset_a * 100.0f), (long)(s.offset_b * 100.0f),
                       (long)(ia * 1000.0f), (long)(ib * 1000.0f), (long)(ic * 1000.0f),
                       motor_state_name(s.state), motor_fault_name(s.fault));
    }
    console_message(line);
}

int main(void)
{
    AppParams params;
    board_init();
    uint8_t loaded = settings_load(&params);
    motor_init(&params); /* 清零平均累加器和 offsets_ready，仍处于 STOP。 */
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson06 v1.1.7: shunt -> amplifier -> ADC -> phase current\r\n");
    console_message(loaded ? "Settings loaded; current offsets still recalibrate at boot\r\n"
                           : "Defaults loaded; current offsets calibrate at boot\r\n");
    board_start_control(); /* ADC 同步采样逐帧累积零点，不用主循环忙等。 */
    ui_init();
    board_watchdog_start();
    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t last_samples = 0u, last_steps = 0u;
    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 500u)
        {
            last_print_ms = now;
            print_current_snapshot();
        }
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != last_samples && s.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = s.sensor_samples;
            last_steps = s.current_steps;
        }
    }
}
```

本课打开 **ControlPanel_Lesson06.uvprojx → Lesson06_NoKnob**。只链接 motor_lesson06.c，不同时链接正式 Control/motor.c；board、ADC 配置、AS5600 和 console 继续用正式模块。

Tools/make_learning_project.py 从正式 motor.c 生成连接文件：加入本课头文件，并将 status.ia/status.ib 的两条换算改为函数调用。实际公式相同，只拆出模块接口；本课尚未实测新增调用后的运行耗时。

练习修改 lesson06_current.c，不编辑生成文件。HEX 位于 Objects/Lesson06/Lesson06_NoKnob.hex。正式工程源码和固件保持原样。

## 15. 只做一次停机观察

后续上板保持 STOP，沿用已有接线和正常供电，不发送 run/cal；观察启动后约 1 秒的 3～5 条 L6 行即可。不要求重新飞线或串入电流表。本轮未执行烧录。

预期格式如下，**不是本轮实测**：

```text
L6 off=1 adc=2048,2050 z100=204800,205000 calc_mA=0,0,0 st=STOP fault=NONE
```

这是用 ADC 恰好等于各自零点构造的解释示例，实际值不要求与示例相同。

| 字段 | 如何读 |
| --- | --- |
| off | offsets_ready；1 表示当前启动校零已通过代码条件 |
| adc=A,B | 最新一组原始计数 |
| z100=A,B | offset 的 count×100，例如 205050 表示 2050.50 count |
| calc_mA=A,B,C | 用该快照 ADC 和 offset 计算；C 是重建估计，整数截断 |
| st / fault | 当前状态和故障锁存 |

未就绪会输出 calc_mA=NA，不把默认零点当成有效标定。由于专用日志每 500 ms 才输出，正常约 273 ms 的校零过程可能在第一条 L6 前就已完成；没有看到 off=0 并不表示没做校零。

`log 0` 关闭常规遥测，不关闭 L6。学习工程不带前几课的 L4/L5/echo/uart 扩展。

本次结果只能用于观察零点与静态残差。它不能证明带载电流比例、方向、动态带宽或保护响应已经标定完成。

## 16. 从“会算”到“会写”：一个主要编码任务

合上完整模块，独立写 lesson06_amps_from_adc：

```text
输入：adc 原始计数、offset 平均计数、sign 方向
输出：带符号电流，单位 A
步骤：算 A/count → 浮点减零点 → 乘比例 → 乘方向 → 返回
```

填空：

```c
float lesson06_amps_from_adc(uint16_t adc, float offset, float sign)
{
    float scale = BOARD_ADC_VREF /
                  (/* A */ * BOARD_SHUNT_OHMS * BOARD_CURRENT_GAIN);
    float delta = /* B */;
    return /* C */;
}
```

参考：A=4096.0f；B=`(float)adc-offset`；C=`delta*scale*sign`。完整模块把恒定比例放在文件内 static const，避免每次调用重复表达标称常量计算。

写好后手算验证一个例子即可：adc=1984、offset=2048、sign=-1，得到 +0.103125 A。再编译本课 Target，理解两条函数调用如何进入实际电流任务。

不用重复写一套 ADC 初始化或新增第二个零点采样循环。主要练习是换算函数；启动平均沿真实代码阅读完成。

## 17. 自测与参考答案

1. 0.2 A 通过 0.01 Ω，压降是多少 mV？50 倍放大后相对零点变化幅度是多少 V？
2. 为什么本机零电流时 ADC 可能接近 2048，而非 0？
3. BOARD_ADC_VREF=3.3、R=0.01、G=50 时，每 count 约多少 mA？
4. adc=1984、offset=2048、sign=-1，相电流是多少 A？
5. offset=2050.5、adc=2048、sign=-1，约多少 mA？为什么不能把 offset 先取整？
6. 4096 个 15 kHz 样本约多久？累加器为什么用 uint32_t？
7. off=1、平均零点落在 512～3584，是否证明测量精度合格？
8. ADC 内部校准、电流启动校零和 cal 命令分别解决什么问题？
9. Ia=+0.10 A、Ib=-0.04 A，Ic 估计是多少？求和为零能否证明准确？
10. 为什么 STOP 下 iq_mA=id_mA=0 不能代替 A/B 零点残差检查？
11. current_limit 与 trip_current 有什么区别？原始过流检查是否先经过 d/q 滤波？
12. 为什么 adc_a 与 status.ia 来自同一个结构体快照，也不保证属于同一采样帧？L6 如何处理？

### 参考答案

1. 2 mV；幅度 0.1 V，本机选定正电流方向对应输出下降。
2. INA240 参考端设定零点约为半电源，便于表示正负电流。
3. 约 1.611328 mA/count。
4. +0.103125 A。
5. 约 +4.02832 mA；取整会丢掉平均零点小数并引入附加偏置。
6. 约 273.1 ms；最大和 16773120，uint16_t 不够。
7. 不能，这是宽范围流程判断，不检验比例精度和方差。
8. ADC 自身校准；外部测量链零电流偏置；电角零位与轴角方向。
9. -0.06 A；不能，负和重建本来就强制满足代数关系。
10. 当前 STOP 分支主动清零 d/q 显示，A/B 仍可能有测量残差。
11. 前者限制控制目标，后者触发测量越限故障；原始检查不经过 d/q 低通。
12. ADC 按 15 kHz 更新，ia 按 3 kHz 更新；L6 用快照里最新 ADC/offset 重新计算对应的 calc_mA。

## 18. 产出与面试表达

本课保存：一份从原理图到公式的推导、自己实现的换算函数、后续一次 STOP 状态 L6 日志及单位说明。

一分钟讲解：

> 我沿两路相内采样电阻和 INA240 前端建立 ADC 到电流的换算模型。启动在停机状态下逐帧平均 4096 组同步 ADC 数据，获得带小数的两路零点；再按参考电压、电阻、增益和方向转换为 A。三线条件下可重建第三相，但求和为零不能证明精度。控制反馈与原始越限检查走不同路径，串口只观察抽样快照；零点、比例和电角校准也分别处理。

实测前把带载精度和动态响应写为“待测”，不把标称分辨率或停机零残差当作电流环性能指标。

**下一课：FOC 坐标变换与调制。** 将测得 Ia/Ib 经 Clarke/Park 变为 Id/Iq，再沿反变换回到三相电压与占空比。
