/* 第六课：复用实际采样任务，后台每 500 ms 用一份快照观察电流换算。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"
#include "app_config.h"
#include "lesson06_current.h"
#include <stdio.h>

static void print_current_snapshot(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    char line[224];
    if (!s.offsets_ready)
    {
        /* 未就绪时没有可用零点，不用默认 offset=0 算出虚假的几安培电流。 */
        (void)snprintf(line, sizeof(line),
                       "L6 off=0 adc=%u,%u calc_mA=NA st=%s fault=%s\r\n",
                       (unsigned)s.adc_a, (unsigned)s.adc_b,
                       motor_state_name(s.state), motor_fault_name(s.fault));
    }
    else
    {
        /* 同一快照里的最新 ADC 与零点用于本行计算，数值与下方原始计数对应。
         * 不将 3 kHz 的 s.ia/s.ib 和 15 kHz 的最新 ADC 冒充同一帧。
         */
        float ia = lesson06_amps_from_adc(s.adc_a, s.offset_a, BOARD_CURRENT_A_SIGN);
        float ib = lesson06_amps_from_adc(s.adc_b, s.offset_b, BOARD_CURRENT_B_SIGN);
        float ic = lesson06_reconstruct_c(ia, ib);
        (void)snprintf(line, sizeof(line),
                       "L6 off=1 adc=%u,%u z100=%ld,%ld calc_mA=%ld,%ld,%ld st=%s fault=%s\r\n",
                       (unsigned)s.adc_a, (unsigned)s.adc_b,
                       (long)(s.offset_a * 100.0f), (long)(s.offset_b * 100.0f),
                       (long)(ia * 1000.0f), (long)(ib * 1000.0f), (long)(ic * 1000.0f),
                       motor_state_name(s.state), motor_fault_name(s.fault));
    }
    console_message(line);
}

int main(void)
{
    AppParams params;
    board_init();
    uint8_t loaded = settings_load(&params);
    motor_init(&params); /* 清零平均累加器和 offsets_ready，仍处于 STOP。 */
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson06 v1.1.7: shunt -> amplifier -> ADC -> phase current\r\n");
    console_message(loaded ? "Settings loaded; current offsets still recalibrate at boot\r\n"
                           : "Defaults loaded; current offsets calibrate at boot\r\n");
    board_start_control(); /* ADC 同步采样逐帧累积零点，不用主循环忙等。 */
    ui_init();
    board_watchdog_start();
    uint32_t last_print_ms = board_millis(), last_check_ms = last_print_ms;
    uint32_t last_samples = 0u, last_steps = 0u;
    while (1)
    {
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_print_ms) >= 500u)
        {
            last_print_ms = now;
            print_current_snapshot();
        }
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus s;
            last_check_ms = now;
            motor_snapshot(&s);
            if (s.sensor_samples != last_samples && s.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = s.sensor_samples;
            last_steps = s.current_steps;
        }
    }
}
