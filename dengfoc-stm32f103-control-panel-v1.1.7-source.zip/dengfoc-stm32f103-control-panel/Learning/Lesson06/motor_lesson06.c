/* Generated from Control/motor.c; edit lesson06_current.c for current-conversion practice. */
/*
 * 电机控制：组织电流内环、速度环、位置环以及校准、运行、停机和故障状态。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "motor.h"
#include "lesson06_current.h"
#include "board.h"
#include "app_config.h"
#include <math.h>
#include <string.h>

/* mechanical 为带方向的单圈机械角 rad；speed 为 rad/s；position 为相对原点的多圈角 rad。 */
typedef struct
{
    uint32_t cycles;
    float mechanical, speed, position;
    uint8_t ok;
} SensorFrame;
/* TIM4 写入非活动缓冲，最后切换索引；PendSV 始终读取一份完整反馈。 */
static SensorFrame sensor_frames[2];
static volatile uint8_t active_frame;
static volatile MotorStatus status;
static AppParams config;
static AngleTracker tracker;
static PidState pid_d, pid_q, pid_speed, pid_position;
static volatile float iq_request, cal_theta;
static float speed_filtered, speed_reference, current_reference, position_speed;
static float id_filtered, iq_filtered;
static uint8_t current_filter_valid;
static int64_t position_origin, cal_start_counts;
static uint32_t sensor_previous_cycles, cal_start_ms, offset_sum_a, offset_sum_b, offset_count;
static uint32_t speed_update_cycles, position_update_cycles;
static uint16_t trip_counts;
static uint8_t outer_div, current_div;
/* ADC 打包发布最近一组双相采样；PendSV 在短临界区内取得完整快照。 */
static volatile uint32_t current_pair, current_sequence;
static uint32_t current_processed;
static const float counts_to_rad = APP_TAU / 4096.0f; /* 每个编码器计数对应的机械弧度 */
/* 电流 = (ADC计数-零点)×(3.3/4096)/(0.01×50)，最后乘硬件规定的方向符号。 */
static const float amps_per_count =
    BOARD_ADC_VREF / (4096.0f * BOARD_SHUNT_OHMS * BOARD_CURRENT_GAIN);

/* 清除四个控制器的内部状态、斜坡参考值和外环计时，防止重新启动时带入旧积分。 */
static void reset_pids(void)
{
    cm_pid_reset(&pid_d);
    cm_pid_reset(&pid_q);
    cm_pid_reset(&pid_speed);
    cm_pid_reset(&pid_position);
    iq_request = 0.0f;
    speed_reference = 0.0f;
    current_reference = 0.0f;
    position_speed = 0.0f;
    id_filtered = iq_filtered = 0.0f;
    current_filter_valid = 0u;
    speed_update_cycles = position_update_cycles = board_cycles();
    outer_div = 0u;
}
/* 装载有效参数并建立初始状态；初始化结束仍保持 STOP 和 PA8 低电平。 */
void motor_init(const AppParams *p)
{
    uint32_t key = board_lock();
    board_gate(0u);
    board_pwm(0u, 0u, 0u);
    memset((void *)&status, 0, sizeof(status));
    memset(sensor_frames, 0, sizeof(sensor_frames));
    memset(&tracker, 0, sizeof(tracker));
    active_frame = 0u;
    sensor_previous_cycles = cal_start_ms = 0u;
    offset_sum_a = offset_sum_b = offset_count = 0u;
    position_origin = cal_start_counts = 0;
    speed_filtered = cal_theta = 0.0f;
    config = *p;
    config.reserved_input = 0u;
    current_div = 0u;
    current_pair = current_sequence = current_processed = 0u;
    status.mode = MODE_SPEED;
    status.calibrated = (uint8_t)config.calibrated;
    trip_counts = (uint16_t)(config.trip_current / amps_per_count);
    reset_pids();
    board_unlock(key);
}
/* 短暂屏蔽中断后复制状态，保证界面不会读到中断只更新了一半的结构体。 */
void motor_snapshot(MotorStatus *out)
{
    uint32_t key = board_lock();
    *out = status;
    board_unlock(key);
}
/* 取得当前运行参数的完整副本，供菜单编辑或保存。 */
void motor_get_params(AppParams *out)
{
    uint32_t key = board_lock();
    *out = config;
    board_unlock(key);
}
/* 检查新参数再整体更新；运行中允许调增益，但不允许改变极对数、方向或电角零偏。 */
uint8_t motor_apply_params(const AppParams *p)
{
    if (!params_valid(p))
        return 0u;
    uint32_t key = board_lock();
    if (status.state == MOTOR_CALIBRATING ||
        (status.state == MOTOR_RUNNING &&
         (p->pole_pairs != config.pole_pairs ||
          p->sensor_direction != config.sensor_direction ||
          p->electrical_zero != config.electrical_zero || p->calibrated != config.calibrated)))
    {
        board_unlock(key);
        return 0u;
    }
    config = *p;
    config.reserved_input = 0u;
    status.calibrated = (uint8_t)p->calibrated;
    trip_counts = (uint16_t)(p->trip_current / amps_per_count);
    status.speed_target_rpm =
        cm_clamp(status.speed_target_rpm, -p->speed_limit_rpm, p->speed_limit_rpm);
    status.current_target = cm_clamp(status.current_target, -p->current_limit, p->current_limit);
    board_unlock(key);
    return 1u;
}
/* 锁存首个故障并关闭驱动，清空电流请求；临界区保证不同中断不会互相覆盖故障。 */
void motor_fault(MotorFault fault)
{
    uint32_t key = board_lock();
    board_gate(0u);
    board_pwm(0u, 0u, 0u);
    if (status.fault == FAULT_NONE)
        status.fault = fault;
    status.state = MOTOR_FAULT;
    iq_request = 0.0f;
    board_unlock(key);
}
void motor_timing_fault(MotorTimingReason reason, uint32_t value)
{
    uint32_t key = board_lock();
    if (status.fault == FAULT_NONE)
    {
        status.timing_reason = reason;
        status.timing_cycles = value;
    }
    motor_fault(FAULT_TIMING);
    board_unlock(key);
}
/* 关闭 PA8、清零输出和旧目标，再清控制器状态；已有故障标志会保留。 */
void motor_stop(void)
{
    uint32_t key = board_lock();
    board_gate(0u);
    board_pwm(0u, 0u, 0u);
    if (status.state != MOTOR_FAULT)
        status.state = MOTOR_STOPPED;
    status.speed_target_rpm = 0.0f;
    status.current_target = 0.0f;
    status.iq_target = 0.0f;
    status.position_target_rad = status.position_rad;
    reset_pids();
    board_unlock(key);
}
/* 传感器、磁场和电流偏置恢复后才清故障；清除后停在 STOP，不自动继续运行。 */
uint8_t motor_clear_fault(void)
{
    uint32_t key = board_lock();
    if (!status.offsets_ready || !status.sensor_ok || !status.magnet_ok)
    {
        board_unlock(key);
        return 0u;
    }
    board_gate(0u);
    status.state = MOTOR_STOPPED;
    status.fault = FAULT_NONE;
    status.timing_reason = TIMING_NONE;
    status.timing_cycles = 0u;
    reset_pids();
    board_unlock(key);
    return 1u;
}
/* 检查启动条件：STOP、无故障、偏置完成、角度与磁场有效，反馈时间不超过约 3 ms。 */
static uint8_t ready(void)
{
    SensorFrame f = sensor_frames[active_frame];
    return status.state == MOTOR_STOPPED && status.fault == FAULT_NONE && status.offsets_ready &&
           status.sensor_ok && status.magnet_ok && f.ok &&
           ((uint32_t)(board_cycles() - f.cycles) < 216000u);
}
/* 先给三路相同的 50% 占空比并立即锁存，再置高 PA8；随后由电流中断更新输出。 */
static void enable_bridge(void)
{
    board_pwm(2400u, 2400u, 2400u);
    board_pwm_latch();
    board_gate(1u);
}
/* 仅在已校准且满足条件时启动；旧目标清零，遥控/串口随后重新给定目标。 */
uint8_t motor_start(void)
{
    uint32_t key = board_lock();
    if (!ready() || !config.calibrated)
    {
        board_unlock(key);
        return 0u;
    }
    reset_pids();
    status.position_target_rad = status.position_rad;
    /* RUN 后重新给目标，防止旧目标突然生效。 */
    status.speed_target_rpm = 0.0f;
    status.current_target = 0.0f;
    status.state = MOTOR_RUNNING;
    enable_bridge();
    board_unlock(key);
    return 1u;
}
/* 请求一次约 2.9 s 的 d 轴对齐和电角旋转校准；成功结束后自动停机。 */
uint8_t motor_calibrate(void)
{
    uint32_t key = board_lock();
    if (!ready() || fabsf(status.speed_rpm) > 5.0f)
    {
        board_unlock(key);
        return 0u;
    }
    reset_pids();
    config.calibrated = 0u;
    status.calibrated = 0u;
    cal_start_ms = board_millis();
    status.calibration_ms = 0u;
    cal_theta = 0.0f;
    cal_start_counts = tracker.continuous;
    status.state = MOTOR_CALIBRATING;
    enable_bridge();
    board_unlock(key);
    return 1u;
}
/* 选择电流/速度/位置模式。先停机并清状态，随后需要显式重新启动。 */
uint8_t motor_set_mode(ControlMode mode)
{
    if (mode > MODE_POSITION)
        return 0u;
    motor_stop();
    uint32_t key = board_lock();
    status.mode = mode;
    reset_pids();
    board_unlock(key);
    return 1u;
}
/* 设置有符号机械转速目标，单位 rpm；实际参考值还要经过斜坡。 */
void motor_set_speed(float rpm)
{
    if (!isfinite(rpm))
        return;
    uint32_t key = board_lock();
    status.speed_target_rpm = cm_clamp(rpm, -config.speed_limit_rpm, config.speed_limit_rpm);
    board_unlock(key);
}
/* 设置相对机械位置目标，单位 rad；串口输入的度数已在 console.c 换算。 */
void motor_set_position(float rad)
{
    if (!isfinite(rad))
        return;
    uint32_t key = board_lock();
    status.position_target_rad = cm_clamp(rad, -100.0f * APP_TAU, 100.0f * APP_TAU);
    board_unlock(key);
}
/* 设置 q 轴电流目标，单位 A；这是电流模式的目标，受 current_limit 限制。 */
void motor_set_current(float amps)
{
    if (!isfinite(amps))
        return;
    uint32_t key = board_lock();
    status.current_target = cm_clamp(amps, -config.current_limit, config.current_limit);
    board_unlock(key);
}
/* 仅停机时把当前累计计数设为机械原点；不会改变 FOC 电角零偏。 */
void motor_zero_position(void)
{
    uint32_t key = board_lock();
    if (status.state == MOTOR_STOPPED)
    {
        position_origin = tracker.continuous;
        status.position_rad = 0.0f;
        status.position_target_rad = 0.0f;
    }
    board_unlock(key);
}
/* 遥控器 4 键将当前模式的目标取反。 */
void motor_reverse_target(void)
{
    uint32_t key = board_lock();
    if (status.mode == MODE_SPEED)
        status.speed_target_rpm = -status.speed_target_rpm;
    else if (status.mode == MODE_CURRENT)
        status.current_target = -status.current_target;
    else
        status.position_target_rad = -status.position_target_rad;
    board_unlock(key);
}
/* 校准分为固定 d 轴 0.5 s、旋转一圈电角 2 s、稳定 0.4 s，再估计极对数、方向和零偏。 */
static void calibration_tick(uint32_t ms)
{
    uint32_t elapsed = ms - cal_start_ms;
    status.calibration_ms = elapsed;
    if (elapsed < 500u)
    {
        cal_theta = 0.0f;
        cal_start_counts = tracker.continuous;
    }
    else if (elapsed < 2500u)
        cal_theta = APP_TAU * (float)(elapsed - 500u) / 2000.0f;
    else if (elapsed < 2900u)
        cal_theta = 0.0f;
    else
    {
        board_gate(0u);
        board_pwm(0u, 0u, 0u);
        /* 命令磁场转过一圈电角：极对数 p ≈ 2π / 转子机械位移的绝对值。 */
        float moved = (float)(tracker.continuous - cal_start_counts) * counts_to_rad;
        if (!isfinite(moved) || fabsf(moved) < 0.1f)
        {
            motor_fault(FAULT_CALIBRATION);
            return;
        }
        float estimate = APP_TAU / fabsf(moved);
        if (estimate < 0.65f || estimate > 30.35f)
        {
            motor_fault(FAULT_CALIBRATION);
            return;
        }
        uint32_t pairs = (uint32_t)(estimate + 0.5f);
        if (pairs < 1u || pairs > 30u || fabsf(estimate - (float)pairs) > 0.35f)
        {
            motor_fault(FAULT_CALIBRATION);
            return;
        }
        /* 计算期间 ADC 仍可抢占并关桥；只有仍在无故障 CAL 时才提交成功结果。 */
        uint32_t key = board_lock();
        if (status.state != MOTOR_CALIBRATING || status.fault != FAULT_NONE)
        {
            board_unlock(key);
            return;
        }
        config.pole_pairs = pairs;
        config.sensor_direction = moved > 0.0f ? 1 : -1;
        /* 最后保持 d 轴电角为 0，故此时的 p×方向×机械角就是应扣除的电角零偏。 */
        config.electrical_zero = cm_wrap((float)config.sensor_direction * (float)tracker.previous *
                                         counts_to_rad * (float)pairs);
        config.calibrated = 1u;
        status.calibrated = 1u;
        position_origin = tracker.continuous;
        status.state = MOTOR_STOPPED;
        status.position_target_rad = 0.0f;
        reset_pids();
        board_unlock(key);
    }
}
/* 1 kHz 角度任务：跨零累计、实测 dt 测速、发布反馈；随后分频运行位置环和速度环。 */
void motor_sensor_isr(uint16_t raw, uint8_t ok, uint8_t magnet, uint32_t cycles, uint32_t ms)
{
    uint32_t begin = board_cycles();
    ++status.sensor_samples;
    status.sensor_ok = ok;
    status.magnet_ok = magnet;
    if (!ok)
    {
        ++status.sensor_errors;
        tracker.valid = 0u;
        if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
            motor_fault(FAULT_SENSOR);
        return;
    }
    if (!magnet && (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING))
    {
        motor_fault(FAULT_MAGNET);
        return;
    }
    int32_t delta = 0;
    uint8_t has_delta = cm_tracker_update(&tracker, raw, &delta);
    /* CPU 周期差转为秒；先做无符号减法，再转浮点，兼容 32 位周期计数回绕。 */
    float dt = (float)(uint32_t)(cycles - sensor_previous_cycles) / (float)BOARD_CPU_HZ;
    sensor_previous_cycles = cycles;
    if (!has_delta)
    {
        speed_filtered = 0.0f;
        position_origin = tracker.continuous;
    }
    else if (dt > 0.004f || dt < 0.0002f)
    {
        if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
            motor_timing_fault(TIMING_SENSOR_INTERVAL, (uint32_t)(dt * (float)BOARD_CPU_HZ));
        speed_filtered = 0.0f;
    }
    else
    {
        float speed = (float)config.sensor_direction * (float)delta * counts_to_rad / dt;
        /* 系数随实际 dt 计算；20 ms 时间常数减少低速速度环的反馈滞后。 */
        speed_filtered += (dt / (BOARD_SPEED_FILTER_TAU_S + dt)) * (speed - speed_filtered);
    }
    float position = (float)config.sensor_direction *
                     (float)(tracker.continuous - position_origin) * counts_to_rad;
    status.raw = raw;
    status.position_rad = position;
    status.speed_rpm = speed_filtered * (60.0f / APP_TAU);
    uint8_t next = active_frame ^ 1u;
    sensor_frames[next] =
        (SensorFrame){cycles, (float)config.sensor_direction * (float)raw * counts_to_rad,
                      speed_filtered, position, 1u};
    __DMB();
    active_frame = next;
    if (status.state == MOTOR_CALIBRATING)
        calibration_tick(ms);
    if (status.state == MOTOR_RUNNING)
    {
        ++outer_div;
        /* 位置环：目标位置-实际位置，输出单位 rad/s，作为速度环目标。 */
        if (status.mode == MODE_POSITION && (outer_div % 10u) == 0u)
        {
            float position_dt =
                (float)(uint32_t)(cycles - position_update_cycles) / (float)BOARD_CPU_HZ;
            position_update_cycles = cycles;
            position_speed = cm_pid_step(&pid_position, &config.position_pid,
                                         status.position_target_rad - position, position,
                                         position_dt, config.speed_limit_rpm * APP_TAU / 60.0f);
        }
        /* 每两帧运行一次速度/电流目标更新：速度环输出 A，送给 q 轴电流环。 */
        if ((outer_div % 2u) == 0u)
        {
            float speed_dt = (float)(uint32_t)(cycles - speed_update_cycles) / (float)BOARD_CPU_HZ;
            speed_update_cycles = cycles;
            if (status.mode == MODE_CURRENT)
            {
                float goal =
                    cm_clamp(status.current_target, -config.current_limit, config.current_limit);
                current_reference +=
                    cm_clamp(goal - current_reference, -config.current_slew_a_s * speed_dt,
                             config.current_slew_a_s * speed_dt);
                iq_request = current_reference;
            }
            else
            {
                float max_speed = config.speed_limit_rpm * APP_TAU / 60.0f;
                float goal = cm_clamp(status.mode == MODE_POSITION
                                          ? position_speed
                                          : status.speed_target_rpm * APP_TAU / 60.0f,
                                      -max_speed, max_speed);
                float slew = config.speed_slew_rpm_s * (APP_TAU / 60.0f) * speed_dt;
                /* 每次只允许目标变化 slew，限制速度给定的变化率。 */
                speed_reference += cm_clamp(goal - speed_reference, -slew, slew);
                iq_request =
                    cm_pid_step(&pid_speed, &config.speed_pid, speed_reference - speed_filtered,
                                speed_filtered, speed_dt, config.current_limit);
            }
        }
        /* 计数到 100 就回到 0，防止 uint8_t 自然回绕破坏位置环的 10 分频节奏。 */
        if (outer_div >= 100u)
            outer_div = 0u;
    }
    uint32_t elapsed = board_cycles() - begin;
    if (elapsed > status.sensor_max_cycles)
        status.sensor_max_cycles = elapsed;
}
/* 记录包含 I²C 在内的传感器任务最大耗时，计数单位为 CPU 周期。 */
void motor_record_sensor_time(uint32_t cycles)
{
    if (cycles > status.sensor_max_cycles)
        status.sensor_max_cycles = cycles;
}
/* 即使零点尚未有效，也调度独立任务，心跳表示任务活着，不等于采样已经可用于驱动。 */
static void publish_current_sample(uint16_t a, uint16_t b)
{
    if (++current_div < BOARD_CURRENT_DIV)
        return;
    current_div = 0u;
    current_pair = (uint32_t)a | ((uint32_t)b << 16);
    __DMB();
    ++current_sequence;
    board_current_request();
}
/* 15 kHz ADC 入口只做零点、原始过流检查和分频发布，不执行完整浮点控制。 */
void motor_adc_isr(uint16_t a, uint16_t b)
{
    status.adc_a = a;
    status.adc_b = b;
    if (!status.offsets_ready)
    {
        /* 此阶段 PA8 关闭，4096 次停机采样的平均值作为电流零点。 */
        offset_sum_a += a;
        offset_sum_b += b;
        if (++offset_count >= BOARD_OFFSET_SAMPLES)
        {
            status.offset_a = (float)offset_sum_a / (float)BOARD_OFFSET_SAMPLES;
            status.offset_b = (float)offset_sum_b / (float)BOARD_OFFSET_SAMPLES;
            if (status.offset_a < 512 || status.offset_a > 3584 || status.offset_b < 512 ||
                status.offset_b > 3584)
            {
                motor_fault(FAULT_ADC);
                offset_count = 0u;
                offset_sum_a = offset_sum_b = 0u;
            }
            else
                status.offsets_ready = 1u;
        }
        publish_current_sample(a, b);
        return;
    }
    if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
    {
        int da = (int)a - (int)status.offset_a, db = (int)b - (int)status.offset_b;
        /* 每次采样检查三相电流；A/B 同向增益下，C 相由 Ic=-Ia-Ib 推算。 */
        if (da > (int)trip_counts || da < -(int)trip_counts || db > (int)trip_counts ||
            db < -(int)trip_counts || (da + db) > (int)trip_counts || (da + db) < -(int)trip_counts)
        {
            motor_fault(FAULT_OVERCURRENT);
            return;
        }
    }
    /* 每 5 帧发布一次双相采样，请求 3 kHz PendSV 控制任务。 */
    publish_current_sample(a, b);
}
/* PendSV 可被 ADC/USART 抢占，预算按 333 μs 控制周期设置；后台界面不参与调度。 */
void motor_current_task(void)
{
    uint32_t key = board_lock();
    uint32_t sequence = current_sequence, pair = current_pair;
    board_unlock(key);
    uint32_t passed = sequence - current_processed;
    if (!passed)
        return;
    current_processed = sequence;
    if (passed > 1u && (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING))
    {
        motor_timing_fault(TIMING_BACKLOG, passed);
        return;
    }
    uint16_t a = (uint16_t)pair, b = (uint16_t)(pair >> 16);
    uint32_t begin = board_cycles();
    ++status.current_steps;
    if (!status.offsets_ready)
    {
        status.ia = status.ib = status.id = status.iq = 0.0f;
        return;
    }
    status.ia = lesson06_amps_from_adc(a, status.offset_a, BOARD_CURRENT_A_SIGN);
    status.ib = lesson06_amps_from_adc(b, status.offset_b, BOARD_CURRENT_B_SIGN);
    SensorFrame f = sensor_frames[active_frame];
    uint8_t running = status.state == MOTOR_RUNNING,
            calibrating = status.state == MOTOR_CALIBRATING;
    if (!running && !calibrating)
    {
        status.ud = status.uq = status.iq_target = 0.0f;
        status.id = status.iq = 0.0f; /* 停机不保留最后一帧 CAL/RUN 的旧 d/q 电流显示。 */
        current_filter_valid = 0u;
        return;
    }
    uint32_t age = board_cycles() - f.cycles;
    if (!f.ok || age > 216000u)
    {
        motor_fault(FAULT_SENSOR);
        return;
    }
    /* 两次读角之间按最近速度短时外推机械角，再乘极对数并扣除真实零偏，得到电角。 */
    float theta = calibrating
                      ? cal_theta
                      : cm_wrap((float)config.pole_pairs *
                                    (f.mechanical + f.speed * (float)age / (float)BOARD_CPU_HZ) -
                                config.electrical_zero);
    float s, c;
    cm_sincos(theta, &s, &c);
    float id, iq;
    cm_dq(status.ia, status.ib, s, c, &id, &iq);
    /* 只平滑控制器使用的 d/q 反馈；最高优先级 ADC 的原始过流检查不经过滤波。 */
    if (!current_filter_valid)
    {
        id_filtered = id;
        iq_filtered = iq;
        current_filter_valid = 1u;
    }
    else
    {
        id_filtered += BOARD_CURRENT_FILTER_ALPHA * (id - id_filtered);
        iq_filtered += BOARD_CURRENT_FILTER_ALPHA * (iq - iq_filtered);
    }
    id = id_filtered;
    iq = iq_filtered;
    status.id = id;
    status.iq = iq;
    float dt = (float)BOARD_CURRENT_DIV / (float)BOARD_PWM_HZ;
    float requested = cm_clamp(iq_request, -config.current_limit, config.current_limit);
    status.iq_target = requested;
    /* 普通闭环时 Id目标=0、Iq目标=requested；校准时改为固定 Ud、Uq=0。 */
    float ud = calibrating
                   ? config.calibration_voltage
                   : cm_pid_step(&pid_d, &config.current_pid, -id, id, dt, config.voltage_limit);
    float uq = calibrating ? 0.0f
                           : cm_pid_step(&pid_q, &config.current_pid, requested - iq, iq, dt,
                                         config.voltage_limit);
    float magnitude_squared = ud * ud + uq * uq;
    /* 限制电压矢量长度，按相同比例缩放两个轴，保持矢量方向。 */
    if (magnitude_squared > config.voltage_limit * config.voltage_limit)
    {
        /* 未超限时无需开方；超限后才计算统一缩放比例，保留原有矢量限幅。 */
        float scale = config.voltage_limit / sqrtf(magnitude_squared), old_d = ud, old_q = uq;
        ud *= scale;
        uq *= scale;
        if (!calibrating)
        {
            cm_pid_track(&pid_d, old_d, ud, config.voltage_limit);
            cm_pid_track(&pid_q, old_q, uq, config.voltage_limit);
        }
    }
    if (!isfinite(ud) || !isfinite(uq) || !isfinite(theta))
    {
        motor_fault(FAULT_NUMERIC);
        return;
    }
    status.ud = ud;
    status.uq = uq;
    PhaseVoltage v = cm_modulate(ud, uq, s, c, config.bus_voltage);
    uint16_t compare_a = cm_duty_compare(v.a, BOARD_PWM_COUNTS),
             compare_b = cm_duty_compare(v.b, BOARD_PWM_COUNTS),
             compare_c = cm_duty_compare(v.c, BOARD_PWM_COUNTS);
    /* ADC 可能在计算期间触发过流关桥；不能在它关桥清零后又写回本帧 PWM。 */
    key = board_lock();
    if (status.state == MOTOR_RUNNING || status.state == MOTOR_CALIBRATING)
        board_pwm(compare_a, compare_b, compare_c);
    board_unlock(key);
    uint32_t elapsed = board_cycles() - begin;
    if (elapsed > status.fast_max_cycles)
        status.fast_max_cycles = elapsed;
    if (elapsed > BOARD_CONTROL_BUDGET_US * 72u)
        motor_timing_fault(TIMING_CONTROL, elapsed);
}
/* 把运行状态枚举转换为串口/OLED 使用的文本。 */
const char *motor_state_name(MotorState s)
{
    static const char *const names[] = {"STOP", "CAL", "RUN", "FAULT"};
    return s <= MOTOR_FAULT ? names[s] : "?";
}
/* 把锁存故障编号转换为可读名称，便于定位失败环节。 */
const char *motor_fault_name(MotorFault f)
{
    static const char *const names[] = {"NONE",        "SENSOR",     "MAGNET",
                                        "OVERCURRENT", "ADC OFFSET", "CALIBRATION",
                                        "TIMING",      "NUMERIC"};
    return f <= FAULT_NUMERIC ? names[f] : "?";
}
/* 把三种闭环模式转换为文本名称。 */
const char *motor_mode_name(ControlMode m)
{
    static const char *const names[] = {"CURRENT", "SPEED", "POSITION"};
    return m <= MODE_POSITION ? names[m] : "?";
}
const char *motor_timing_name(MotorTimingReason reason)
{
    static const char *const names[] = {"NONE", "CONTROL", "SENSOR_DT", "SENSOR_TASK", "BACKLOG"};
    return reason <= TIMING_BACKLOG ? names[reason] : "?";
}
