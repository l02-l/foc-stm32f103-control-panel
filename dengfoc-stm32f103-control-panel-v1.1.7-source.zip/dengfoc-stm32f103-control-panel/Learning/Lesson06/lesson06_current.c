/*
 * 第六课：把“ADC 计数 -> 相电流”拆成可独立编写的函数。
 * 本课生成的 motor_lesson06.c 在真实 3 kHz 电流任务中调用此函数两次。
 * ADC 配置、启动零点平均、原始过流检查和控制状态逻辑沿用正式工程。
 */
#include "lesson06_current.h"
#include "app_config.h"

/* 每个 ADC count 对应多少 A。4096 是 12 位 ADC 的量化级数。
 * 3.3 / (4096 * 0.01 * 50) = 0.001611328125 A/count。
 * 它是按标称参数推算的比例，不表示实际测量准确到这个小数位。
 */
static const float amps_per_count =
    BOARD_ADC_VREF / (4096.0f * BOARD_SHUNT_OHMS * BOARD_CURRENT_GAIN);

float lesson06_amps_from_adc(uint16_t adc, float offset, float sign)
{
    /* 先转 float 再减零点，保留平均零点的小数部分，也能表示负差值。
     * offset 单位是 count，不能误传成 1.65 V。
     */
    float delta = (float)adc - offset;
    /* 本机 A/B 的 sign 都是 -1：电流正方向对应采样输出下降。
     * 不取绝对值，也不为让显示好看而把小电流强制清零。
     */
    return delta * amps_per_count * sign;
}

float lesson06_reconstruct_c(float ia, float ib)
{
    /* 三线电机满足 ia+ib+ic=0，第三相由前两相估计。
     * 顺序采样、偏置和瞬态会影响重建；求和为零是公式的结果，不能证明精度。
     */
    return -ia - ib;
}
