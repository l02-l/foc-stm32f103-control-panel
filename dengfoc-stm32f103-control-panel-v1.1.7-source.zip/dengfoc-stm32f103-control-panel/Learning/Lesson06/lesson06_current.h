#ifndef LESSON06_CURRENT_H
#define LESSON06_CURRENT_H
#include <stdint.h>

/* adc/offset 均为 ADC 计数，sign 是本项目定义的电流方向（+1 或 -1）。返回 A。 */
float lesson06_amps_from_adc(uint16_t adc, float offset, float sign);
/* 三线电机、同一电流参考方向下估算第三相，返回 A；不是第三路独立测量。 */
float lesson06_reconstruct_c(float ia, float ib);
#endif
