# 第三课：USART1、环形缓冲与命令调试通道

日期：2026-11-02。基线：**v1.1.7，无旋钮，STM32F103C8T6 标准外设库**。建议 8～10 小时。

## 0. 本课目标与代码入口

前两课已经建立启动顺序和引脚/时钟概念。这一课追踪一条完整路径：**电脑发出字符，STM32 如何把它变成命令，又怎样把回复发回来？**

学完应能：

1. 解释 PA9/PA10、115200/8N1、RXNE/TXE/TC。
2. 画出中断与主循环分别读写哪个缓冲区、哪个索引。
3. 理解 static、extern、volatile 在本项目中的实际作用。
4. 从字符、换行、分词一直追踪到电机接口。
5. 独立写出一条简单命令，解释队列满与串口输出占时。

| 文件 | 本课用途 |
| --- | --- |
| [正式 BSP/board.c](../../BSP/board.c) | uart_init、USART1_IRQHandler、收发环形缓冲 |
| [正式 App/console.c](../../App/console.c) | console_poll、行缓存、分词、数值解析与命令分派 |
| [lesson03_commands.c](lesson03_commands.c) / [头文件](lesson03_commands.h) | 本课新增 echo/uart 命令，实际接入处理链 |
| [console_lesson03.c](console_lesson03.c) | 从正式 console.c 生成，只增加本课命令接入点 |
| [main.c](main.c) | 完整学习入口，保留控制、界面与看门狗 |
| [ControlPanel_Lesson03.uvprojx](../../ControlPanel_Lesson03.uvprojx) | Target 为 Lesson03_NoKnob |
| [build.log](build.log) | 本机编译 0 错误、0 警告 |

本轮只生成、编译课程，尚未烧录学习入口，也未在串口实测新增命令。下文交互记录是预期示例。正式项目文件保持原来的接口和行为。

## 1. 硬件路径：电脑 USB 与单片机 UART

```text
电脑串口程序
    ↕ USB
绿色转接板板载 CH340
    ↕ 逻辑电平 UART
PA10 RX / PA9 TX
    ↕ USART1
STM32 内部收发处理
```

- PA9 是 STM32 的发送端 TX，接转换器接收端。
- PA10 是 STM32 的接收端 RX，接转换器发送端。
- 接收与发送共用 GND 作为电平参考，TX/RX 分别传输，可同时工作。
- MCU 侧是逻辑电平 UART；USB、UART、RS-232 不是同一种电气接口。

当前工程用绿色转接板已有的 CH340，不需要再并接一套 USB-TTL。蓝色核心板 USB 接口不因本程序启用 USART1 就自动成为 USB 串口。

历史设备曾为 COM6，实际使用应以电脑当前枚举为准。一个串口通常由一个程序独占；VOFA 占用时，其他助手无法同时打开。

## 2. 115200/8N1：一字节为什么占 10 个时间位？

| 配置 | 含义 |
| --- | --- |
| 115200 | 波特率，本项目二进制 UART 每秒约 115200 个比特时间 |
| 8 | 8 个数据位 |
| N | 无校验位 |
| 1 | 1 个停止位 |

本配置一帧为：空闲高电平→1 个起始位→8 个数据位→1 个停止位，数据通常低位先发。[ST RM0008：USART 章节](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf)

```text
一个字节的线路时间 = (1 + 8 + 1) / 115200
                   ≈ 86.8 μs
理论有效字节速率   = 115200 / 10 = 11520 字节/秒
```

`help\n` 是 5 字节，理论占约 434 μs；`help\r\n` 是 6 字节，约 521 μs。C 源码中的转义写法不是要求发送反斜杠和字母 n。

200 字节日志约占 17.36 ms。每秒 10 帧约需 2000 字节/秒；每秒 1000 帧则需 200000 字节/秒，远超当前链路。中断发送和缓冲区能减少等待，却不能提高线路物理吞吐上限。

## 3. 回到标准库 uart_init

```c
static void uart_init(void)
{
    GPIO_InitTypeDef g;
    USART_InitTypeDef u;
    NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    g.GPIO_Pin = GPIO_Pin_9;
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);
    g.GPIO_Pin = GPIO_Pin_10;
    g.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &g);
    USART_StructInit(&u);
    u.USART_BaudRate = BOARD_UART_BAUD;
    USART_Init(USART1, &u);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);
    n.NVIC_IRQChannel = USART1_IRQn;
    /* 115200/8N1 每字节约 86.8 μs，F103 的 USART 没有接收 FIFO。
     * 串口只搬运字节，必须能抢占耗时的软件 I²C（TIM4），避免 RXNE 来不及读取而 ORE。
     * 优先级：ADC=0、USART1=1、PendSV控制=2、TIM4/红外=3、SysTick=4。 */
    n.NVIC_IRQChannelPreemptionPriority = 1;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
}
```

按上一课的四个问题阅读：

1. 外设时钟：USART1 挂 APB2，使用 PCLK2；不使用定时器的 APB×2 规则。
2. 引脚：PA9 复用推挽发送，PA10 浮空输入接收。
3. 外设格式：USART_StructInit 的默认配置包括 8 位、1 停止、无校验、无硬件流控、收发启用，再设波特率。
4. 中断：启用 RXNE；NVIC 优先级为 1。TXE 中断等有数据入队时才开启。

当前 PCLK2=72 MHz，16 倍过采样对应 USARTDIV=72MHz/(16×115200)=39.0625，BRR 对应 0x0271。实际由 USART_Init 根据时钟配置计算，本课不用手写 BRR。

### 为什么串口优先级高于软件 I²C？

F103 这一路 USART 没有多字节接收 FIFO。连续接收时，每约 86.8 μs 就可能到下一字节；上一字节还没及时取走会出现 ORE。

软件 I²C 的 TIM4 优先级为 3，USART1 为 1，所以 USART 可以及时抢占读角任务。**RAM 里的 RX 环形缓冲再大，也不能补回已经在外设阶段丢失的字节。** 这与前面项目中 status/help 丢字的实际排查相关，见 [串口故障知识库](../../Docs/UART_HISTORY.md)。

## 4. 把接收路径和发送路径分别画清楚

```mermaid
flowchart LR
    PC[电脑字符] --> HW[USART1 接收寄存器]
    HW --> IRQ[RXNE 中断]
    IRQ --> RX[RX 环形缓冲]
    RX --> READ[board_uart_read]
    READ --> LINE[console_poll 逐字节拼行]
    LINE --> TOK[换行后分词与 execute]
    TOK --> CALL[控制接口 / 学习命令]
    CALL --> MSG[console_message]
    MSG --> TX[TX 环形缓冲]
    TX --> TXE[TXE 中断写 USART_DR]
    TXE --> PC2[电脑收到回复]
```

中断做及时的字节搬运，主循环处理文本和业务。不能把整条命令解析或长串 printf 都搬进 USART 中断。

### 三个层次的“缓冲”

| 位置 | 大小/用途 | 谁处理 |
| --- | --- | --- |
| USART 接收寄存器 | 保存硬件接收到的数据 | RXNE 中断及时读取 |
| RX 环形缓冲 rx[256] | 允许应用稍后逐字节取数据 | 中断生产，主循环消费 |
| 命令行 input[128] | 把多个字符拼成一条文本命令 | console_poll 写入，execute 使用 |

它们不是同一片数据。命令超过一轮 64 字符的处理预算，可以下一次 poll 继续拼行；超出 127 个可保存字符则按代码设置 overflow，等换行反馈过长。

## 5. 环形缓冲：不搬动数组，只移动索引

本项目用 head 表示下一次写入位置，tail 表示下一次读取位置。

```text
空：head == tail
写入后的下一位置：next = (head + 1) % N
满：next == tail
```

这里预留一个空位区分满与空，所以 N=256 时实际最多存 255 字节，N=1024 时最多存 1023 字节。

### 5.1 为什么写 &255，而不是 %256？

```c
next = (rx_head + 1u) & 255u;
```

256=2⁸、255=0xFF，保留低 8 位可实现 0～255 回绕。255→0，不能把掩码 255 理解为数组大小 255。这种等价关系依赖 N 是 2 的幂；长度 300 不能照抄 `&299`。

例如 head=255、tail=0，下一位置为 0，等于 tail，因此已经满，不能覆盖尚未读取的数据。

### 5.2 RX 与 TX 的生产者不同

| 队列 | 写数据/推进 head | 读数据/推进 tail |
| --- | --- | --- |
| RX | USART1_IRQHandler | 主循环 board_uart_read |
| TX | 主循环 board_uart_write | USART1_IRQHandler |

使用接口取数据，不在另一个模块里直接修改 rx_head/rx_tail。TX 写入时还会进入短临界区，防止共享更新过程被打断。

### 5.3 真实发送入队和接收取字节代码

```c
uint8_t board_uart_write(const char *s)
{
    unsigned len = (unsigned)strlen(s);
    uint32_t key = board_lock();
    unsigned free_space = (tx_tail - tx_head - 1u) & 1023u;
    if (len > free_space)
    {
        ++dropped;
        board_unlock(key);
        return 0u;
    }
    while (*s)
    {
        tx[tx_head] = *s++;
        tx_head = (tx_head + 1u) & 1023u;
    }
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    board_unlock(key);
    return 1u;
}

int board_uart_read(void)
{
    if (rx_head == rx_tail)
        return -1;
    int c = (uint8_t)rx[rx_tail];
    rx_tail = (rx_tail + 1u) & 255u;
    return c;
}
```

几个关键点：

- board_uart_write 返回 1 表示文本已进入发送队列，不表示最后一位已经从 PA9 发完。
- 空间不足时整次文本入队失败，dropped 增加一次，不在这里等待串口慢慢腾空间。
- board_uart_read 用 int 返回值：-1 表示没有数据，0～255 表示字节值。
- 读到 0xFF 返回 255，不能把它与 -1 混淆。这是代码先转换为 uint8_t 的原因。
- console_message 忽略了入队返回值；调用它不保证电脑收到文字，需要结合丢弃统计、链路和接收端判断。

## 6. RXNE、TXE、TC 与 ORE

| 标志 | 含义 | 本工程怎样处理 |
| --- | --- | --- |
| RXNE | 有接收数据未读 | 读 DR，再放到 RX 队列 |
| TXE | 发送数据寄存器可接收下一个数据 | 从 TX 队列取一个字节，写 DR |
| TC | 最后一个发送帧连停止位都完成 | 当前队列发送流程不依赖它逐字节喂数据 |
| ORE | 接收覆盖错误，未及时处理前一个数据 | 读状态/数据清理错误并计数 |

TXE 不等于整个发送结束。TX 队列空时，最后一个字节可能仍在硬件移位寄存器里发送。具体标志与清除规则见 [ST RM0008 USART 章节](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf)。

```c
void USART1_IRQHandler(void)
{
    uint8_t error = USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET ||
                    USART_GetFlagStatus(USART1, USART_FLAG_FE) != RESET ||
                    USART_GetFlagStatus(USART1, USART_FLAG_NE) != RESET;
    /* 先读取状态，再调用标准库读数据，完成 F1 串口错误标志的清除序列。 */
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET || error)
    {
        uint8_t c = (uint8_t)USART_ReceiveData(USART1);
        uint16_t next = (rx_head + 1u) & 255u;
        if (error)
            ++dropped;
        else if (next != rx_tail)
        {
            rx[rx_head] = (char)c;
            rx_head = next;
        }
        else
            ++dropped;
    }
    if (USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
    {
        if (tx_tail != tx_head)
        {
            USART_SendData(USART1, (uint8_t)tx[tx_tail]);
            tx_tail = (tx_tail + 1u) & 1023u;
        }
        else
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
    }
}
```

有数据时开启 TXE 中断；队列空时关闭，避免发送寄存器一直为空造成反复进入中断。USART_SendData 本身只是写寄存器，不会自动替你等待 TXE。

代码将 ORE、FE、NE 统一按错误处理，先读状态再读数据，丢弃这次错误关联的数据并增加统计。本项目未开启奇偶校验。

`board_uart_dropped()` 混合统计 RX 外设错误、RX 队列满和 TX 入队失败事件。它不是严格的接收丢失字节总数：一次 TX 失败可能对应一整行，接收端电脑的问题也不包含在内。

## 7. C 语言：static、extern、volatile

### 7.1 文件作用域 static：模块私有

```c
static char tx[1024], rx[256];
static volatile uint16_t tx_head, tx_tail, rx_head, rx_tail;
```

这些对象一直存在，但名字只在 board.c 内可见。其他文件通过 board_uart_read/write 使用队列，而不是依赖内部数组和索引。

`static void usage(...)` 同样只在当前文件内可调用。

### 7.2 函数内 static：跨调用保留状态

console_poll 中的 `static uint32_t last;` 记住上次遥测时刻，不会每次调用重新清零。普通本轮临时变量如 c、budget 则每次调用重新建立。

### 7.3 extern：引用其他文件定义的对象

概念示例，不要求加进当前工程：

```c
/* counter.c：定义一次，分配对象。 */
volatile uint32_t counter = 0u;

/* counter.h：声明，供其他文件引用同一个对象。 */
extern volatile uint32_t counter;
```

不能在多个 `.c` 都重复定义同一个外部对象。board.c 已经将索引设为 static，因此不能在另一个文件靠写 extern 就把这些私有对象导出。

函数头文件里的 `int board_uart_read(void);` 本身具有外部链接声明的含义，不必每个函数声明都显式写 extern。

### 7.4 volatile：提示每次按实际对象访问

head/tail 会在中断和主循环之间变化，volatile 防止编译器按普通局部状态处理这些访问。

它不自动把 `x++` 变成不可分割操作，也不保证整个结构体快照一致。TX 队列的短临界区、状态快照的同步措施仍然各有作用；不能给所有变量加 volatile 来替代数据所有权设计。

## 8. 收到一字节后，为什么还不执行命令？

UART 只提供字节，没有自带“这是 help 的最后一个字母”的语义。本项目在应用层约定：遇到 CR 或 LF，提交一条命令。

| 写法 | ASCII 值 | 用途 |
| --- | --- | --- |
| `\r` | 0x0D | 回车，当前程序也作为命令结束 |
| `\n` | 0x0A | 换行，当前程序也作为命令结束 |
| `\0` | 0x00 | C 字符串内部结束符，由程序补入缓冲区 |

发送 help 但没带行尾，字符可以已经到达，却仍停留在 input 中等待。发送 CRLF 时，CR 提交命令，LF 对应空行，不会再次执行同一条命令。

```c
void console_poll(void)
{
    int c;
    unsigned budget = 64u;
    while (budget-- && (c = board_uart_read()) >= 0)
    {
        if (rx_preview_used < sizeof(rx_preview))
            rx_preview[rx_preview_used++] = (uint8_t)c;
        if (c == '\r' || c == '\n')
        {
            if (overflow)
                console_message("ERR: command too long\r\n");
            else if (used)
            {
                input[used] = '\0';
                execute(input);
            }
            used = 0u;
            overflow = 0u;
            rx_preview_used = 0u;
        }
        else if (c == 8 || c == 127)
        {
            if (used)
                --used;
        }
        else if (c >= 32 && c < 127)
        {
            if (used < sizeof(input) - 1u)
                input[used++] = (char)c;
            else
                overflow = 1u;
        }
    }
    static uint32_t last;
    uint32_t now = board_millis();
    if (telemetry && (uint32_t)(now - last) >= 100u)
    {
        last = now;
        console_status();
    }
}
```

本代码接收可打印 ASCII，并支持退格。UTF-8 中文是多个高位字节，不属于该命令输入范围；不能用“echo 中文没成功”直接判断波特率错误。

`used < sizeof(input)-1` 留一个位置给 `\0`；缺少字符串结束符，strcmp/strtok 等函数就无法可靠判断文本边界。

## 9. 从一行字符串变成函数调用

以文本 `speed 10` 为例：

```text
input = "speed 10\0"
    → strtok 按空格/制表符拆分
args[0] → "speed"
args[1] → "10"
count = 2
    → strcmp 判断命令
    → strtof 解析数值
    → motor_set_speed(10.0f)
```

### 9.1 字符串指针数组

```c
char *args[8];
```

这是 8 个字符指针，不是 8 个独立的大字符串。strtok 会把原 input 中的分隔符改成 `\0`，让 args 指向各段起点，不必把每个词再复制一份。

strtok 使用内部状态；当前只在主循环同一解析链使用。不要同时在中断里调用它来拆另一条字符串。当前解析不支持带空格的引号参数，所以本课 echo 只接一个单词。

### 9.2 strcmp 相等时返回 0

```c
if (!strcmp(args[0], "echo"))
```

等价于 `strcmp(args[0], "echo") == 0`。`==` 用来直接比较两个字符串指针的地址，不能替代 strcmp 的文本比较。

### 9.3 strtof 与 char **end

正式 number 函数：

```c
static uint8_t number(const char *s, float *f)
{
    char *end;
    *f = strtof(s, &end);
    return s[0] && *end == '\0' && isfinite(*f);
}
```

- s 指向输入字符串。
- f 指向接收解析结果的 float 对象。
- end 是字符指针，`&end` 让 strtof 把“解析停止位置”写回来，因此需要指针的地址。
- `"10abc"` 虽可能解析出开头 10，但 end 指向 a，当前函数会拒绝。
- 解析为有限数字不等于通过业务范围检查；PID 配置还经过 params_valid，速度等目标接口还有自己的限幅。

### 9.4 OK 的证据范围

`speed 10` 返回 OK 表示命令已被处理，不表示已达到 10 rpm。当前 motor_start 会重置目标，因此实际运行操作中先 RUN，再给定目标；STOP 下设置目标也不自动启动。

本课新增命令只做文本往返和统计查询。读懂普通命令后，沿同样的分派路径追踪电机指令。

## 10. 读一条状态日志

```text
t=2000 st=STOP mode=SPEED r=1000 rpm10=-125 pos100=1234 iq_mA=20 ... fault=NONE
```

此行为字段解释示例，不是本轮测量记录。

| 字段 | 解释 |
| --- | --- |
| rpm10=-125 | 速度约 -12.5 rpm，负号依据项目的方向约定 |
| pos100=1234 | 位置约 12.34°，内部位置是 rad |
| iq_mA=20 | q 轴电流反馈约 0.020 A |
| r | AS5600 单圈原始计数 |
| us / sens_us | 控制/角度任务已观察到的最大耗时，不是每一帧即时耗时 |
| err | 累计传感器读取失败，不是 UART drop |

整数缩放方便输出，但转换为整数会截去小数部分；显示 0 不必然表示物理量严格为 0。串口每 100 ms 打一行，也不能拿相邻行直接当作 1 ms 电流环波形。

## 11. 从“看懂”到“能写”：先实现 echo

### 11.1 输入输出约定

输入：已分词的 args/count。

- `echo hello` → `L3 ECHO=hello`。
- `uart` → 当前配置波特率、引脚名与 drop 计数。
- 其他命令 → 返回 0，继续进入原 execute 分支。

返回 1 表示已处理，包括已经输出用法错误。它不是“业务操作一定成功”的通用标志。

### 11.2 伪代码

```text
没有词：交回原处理器
命令名是 echo：
    参数个数不对则反馈用法
    否则把 args[1] 放进固定格式文本并发送
    返回已处理
命令名是 uart：
    检查参数个数，读取 drop，整理文本并发送
    返回已处理
其他命令：交回原处理器
```

### 11.3 先填三个空

```c
if (/* A：命令名为 echo */)
{
    if (count != 2u)
        return 1u; /* 完整参考里还会反馈用法。 */
    snprintf(line, sizeof(line), "L3 ECHO=%s\r\n", /* B */);
    console_message(line);
    return /* C：已经处理 */;
}
```

参考：A 为 `strcmp(args[0], "echo") == 0`；B 为 `args[1]`；C 为 `1u`。前提是调用前或函数开头已确认 count 非零。

## 12. 完整中文注释代码

### 命令模块 lesson03_commands.c

```c
/*
 * 第三课：在真实收发、行缓冲与分词代码之后增加两条学习命令。
 * echo hello：回传一个 ASCII 单词；uart：查询配置波特率和累计丢弃/错误事件。
 * 这里在主循环执行，不在 USART 中断中执行，不直接更改电机目标。
 */
#include "lesson03_commands.h"
#include "console.h"
#include "board.h"
#include "app_config.h"
#include <stdio.h>
#include <string.h>

/* static 限制本函数只供当前文件使用；const char * 表示本函数不修改用法字符串。 */
static void usage(const char *text)
{
    console_message("L3 usage: ");
    console_message(text);
    console_message("\r\n");
}

uint8_t lesson03_handle(char *args[], unsigned count)
{
    /* args 是字符串指针数组，args[0] 是命令名；先确认存在，再访问。 */
    if (count == 0u)
        return 0u;

    /* strcmp 相等返回 0；这里的 ! 把 0 转为真，表示匹配 echo。 */
    if (!strcmp(args[0], "echo"))
    {
        if (count != 2u)
        {
            usage("echo <one_ASCII_word>");
            return 1u; /* 已反馈用法问题，不再交给原处理器报 unknown command。 */
        }
        char line[160];
        /* 原行缓冲最多存 127 字节，单词加前后缀可放入 160 字节。
         * 固定格式 %s 只把输入当文本，不把输入当 printf 格式字符串。
         */
        (void)snprintf(line, sizeof(line), "L3 ECHO=%s\r\n", args[1]);
        console_message(line); /* 进入 TX 队列，真正写 USART_DR 的是 TXE 中断。 */
        return 1u;
    }

    if (!strcmp(args[0], "uart"))
    {
        if (count != 1u)
        {
            usage("uart");
            return 1u;
        }
        char line[160];
        /* BOARD_UART_BAUD 是配置值；drop 混合统计 RX 错误、RX 满与 TX 入队失败。
         * 它不是严格的“接收丢失字节数”，也不覆盖接收端电脑自己的丢包。
         */
        (void)snprintf(line, sizeof(line),
                       "L3 UART baud=%lu tx=PA9 rx=PA10 drop=%lu\r\n",
                       (unsigned long)BOARD_UART_BAUD,
                       (unsigned long)board_uart_dropped());
        console_message(line);
        return 1u;
    }

    return 0u; /* help/status/log 等原有命令继续由生成的 console 处理。 */
}
```

### 完整入口 main.c

```c
/* 第三课：原板级驱动 + 带学习命令的 console，复用实际控制、菜单与参数模块。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"

int main(void)
{
    AppParams params;
    uint32_t last_check_ms, last_samples = 0u, last_steps = 0u;

    board_init(); /* 包含 USART1 115200/8N1、RXNE 中断和 NVIC 配置 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson03 v1.1.7: UART -> queue -> line -> command\r\n");
    console_message("Learning commands: echo <one_ASCII_word> | uart\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");

    board_start_control();
    ui_init();
    board_watchdog_start();
    last_check_ms = board_millis();
    while (1)
    {
        /* console_poll 从 RX 队列取字节，遇到换行才提交一条命令。
         * 不另外写一套 board_uart_read 循环，否则两处会竞争消费同一个队列。
         */
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus snapshot;
            last_check_ms = now;
            motor_snapshot(&snapshot);
            if (snapshot.sensor_samples != last_samples && snapshot.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = snapshot.sensor_samples;
            last_steps = snapshot.current_steps;
        }
    }
}
```

### 怎样实际接入原解析器？

```text
console_poll 拼行
    → execute 原分词
    → lesson03_handle(args, count)
        → 返回 1：本条已处理
        → 返回 0：继续执行 help/status/电机命令等原分支
```

console_lesson03.c 从 App/console.c 自动生成，只增加头文件和这处接入调用。第三课工程只链接这一份 console，不再同时链接 App/console.c；BSP/board.c 仍用正式版本。

练习修改 lesson03_commands.c。Tools/make_learning_project.py 可重新生成各课独立工程及连接文件，不把课程入口混到正式工程中。

## 13. 编译和一次代表性命令往返

打开 ControlPanel_Lesson03.uvprojx，选择 Lesson03_NoKnob；HEX 在 Objects/Lesson03/Lesson03_NoKnob.hex。本课已实际编译，但尚未上板验证。

后续运行本课程序时，串口设置 115200、8N1、无流控，文本发送并带 LF 或 CRLF。按顺序观察下面的**预期交互**：

```text
发送：log 0
回复：OK

发送：echo hello
回复：L3 ECHO=hello

发送：uart
回复：L3 UART baud=115200 tx=PA9 rx=PA10 drop=0

发送：status
回复：t=... st=STOP ...

发送：log 1
回复：OK，随后恢复常规状态行
```

drop 的真实值以本次运行读回为准，示例中的 0 不是预先保证。log 0 不停止中断、OLED 或电机，只关闭常规周期遥测；已经进入 TX 队列的旧状态行仍可能随后到达。

本课不含第一课专用 L1 行。若只有正式版本启动标记而没有 Lesson03 提示，echo/uart 学习命令尚未进入当前程序。

## 14. 只做一个小扩展

在本课模块增加 `ping` 命令，输入 `ping` 回复 `L3 PONG`。它不需要数值参数，也不调用电机接口。

先写输入/输出/返回值，再按 echo 的分支结构实现。完成后解释：哪个函数收到字节、哪个函数看到 ping 单词、哪个函数真正把回复写入 USART 寄存器。

## 15. 自测与参考答案

1. 115200/8N1 每字节约多少 μs？200 字节约多少 ms？
2. RX 数组有 256 个位置，为什么最多只存 255 字节？head=255、tail=0 时还能写吗？
3. `&255` 为什么可用于长度 256，不能用于任意长度？
4. RXNE 与 TXE 分别让中断做什么？TXE 是否表示最后停止位发完？
5. 为什么 head/tail 使用 volatile，仍不能依靠 volatile 完成所有同步？
6. board_uart_read 为什么返回 int 而不是 uint8_t？收到 0xFF 应返回多少？
7. `help` 没有换行、`help\r\n` 各会怎样？
8. strcmp 相等返回多少？strtok 是否改动原字符串？
9. number 为什么拒绝 `10abc`？&end 与 end 有什么区别？
10. echo 分支反馈用法错误后为何仍返回 1？
11. uart 的 drop=1 能否断言只丢了一个 RX 字节？
12. speed 10 返回 OK，是否证明正在以 10 rpm 转动？

参考答案：

1. 约 86.8 μs，约 17.36 ms。
2. 预留一个位置区分满与空；next=0 等于 tail，不能再写。
3. 它利用 2 的幂长度的低位回绕性质。
4. RXNE 取接收数据入队；TXE 取发送队列写 DR；TXE 不代表整帧完成，TC 才对应更后面的完成条件。
5. volatile 使共享访问不被当作普通不变状态，不能保证复合操作或整组数据原子性。
6. 需要同时表示 -1 与 0～255；0xFF 返回 255。
7. 前者等待行尾；后者执行一次，后一个行尾对应空行。
8. 0；strtok 会写入分隔用的零字符。
9. end 停在 a；end 是字符指针，&end 让函数写回这个指针。
10. 返回值表示这条命令已处理，避免继续报 unknown。
11. 不能，统计混合了 RX 错误/队列满及 TX 整段入队失败。
12. 不能，要结合状态、故障与实际反馈；目标限幅和启动条件另有接口处理。

## 16. 完成标准与求职积累

产出：收发路径图、两队列生产者/消费者表、你实现的 ping 分支、一次预期与实测对照记录。

一分钟讲解可以这样组织：

> 我用 USART 中断搬运字节，主循环完成拼行、分词和命令处理。接收和发送分别使用环形缓冲，索引回绕与满空判定有明确约定。发送入队成功不等于线路发送完成，缓冲区也不能突破波特率上限。调试时把外设接收错误、队列丢弃、输入格式与业务状态分别检查，再用状态反馈确认命令效果。

下一课：AS5600 软件 I²C、状态/角度连续读取、跨零和实际时间测速。从 PB10/PB11 到一组有效机械角反馈，继续追踪同一完整工程。
