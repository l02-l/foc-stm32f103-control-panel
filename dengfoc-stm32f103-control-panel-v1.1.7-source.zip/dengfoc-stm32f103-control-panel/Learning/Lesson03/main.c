/* 第三课：原板级驱动 + 带学习命令的 console，复用实际控制、菜单与参数模块。 */
#include "board.h"
#include "as5600.h"
#include "ir_receiver.h"
#include "motor.h"
#include "settings.h"
#include "console.h"
#include "ui.h"

int main(void)
{
    AppParams params;
    uint32_t last_check_ms, last_samples = 0u, last_steps = 0u;

    board_init(); /* 包含 USART1 115200/8N1、RXNE 中断和 NVIC 配置 */
    uint8_t loaded = settings_load(&params);
    motor_init(&params);
    as5600_init();
    ir_receiver_init();
    console_init();
    console_message("Lesson03 v1.1.7: UART -> queue -> line -> command\r\n");
    console_message("Learning commands: echo <one_ASCII_word> | uart\r\n");
    console_message(loaded ? "Settings loaded; still STOPPED\r\n"
                           : "Defaults loaded; calibration required\r\n");

    board_start_control();
    ui_init();
    board_watchdog_start();
    last_check_ms = board_millis();
    while (1)
    {
        /* console_poll 从 RX 队列取字节，遇到换行才提交一条命令。
         * 不另外写一套 board_uart_read 循环，否则两处会竞争消费同一个队列。
         */
        console_poll();
        ui_poll();
        uint32_t now = board_millis();
        if ((uint32_t)(now - last_check_ms) >= 100u)
        {
            MotorStatus snapshot;
            last_check_ms = now;
            motor_snapshot(&snapshot);
            if (snapshot.sensor_samples != last_samples && snapshot.current_steps != last_steps)
                board_watchdog_feed();
            last_samples = snapshot.sensor_samples;
            last_steps = snapshot.current_steps;
        }
    }
}
