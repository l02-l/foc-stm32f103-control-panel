/*
 * 第三课：在真实收发、行缓冲与分词代码之后增加两条学习命令。
 * echo hello：回传一个 ASCII 单词；uart：查询配置波特率和累计丢弃/错误事件。
 * 这里在主循环执行，不在 USART 中断中执行，不直接更改电机目标。
 */
#include "lesson03_commands.h"
#include "console.h"
#include "board.h"
#include "app_config.h"
#include <stdio.h>
#include <string.h>

/* static 限制本函数只供当前文件使用；const char * 表示本函数不修改用法字符串。 */
static void usage(const char *text)
{
    console_message("L3 usage: ");
    console_message(text);
    console_message("\r\n");
}

uint8_t lesson03_handle(char *args[], unsigned count)
{
    /* args 是字符串指针数组，args[0] 是命令名；先确认存在，再访问。 */
    if (count == 0u)
        return 0u;

    /* strcmp 相等返回 0；这里的 ! 把 0 转为真，表示匹配 echo。 */
    if (!strcmp(args[0], "echo"))
    {
        if (count != 2u)
        {
            usage("echo <one_ASCII_word>");
            return 1u; /* 已反馈用法问题，不再交给原处理器报 unknown command。 */
        }
        char line[160];
        /* 原行缓冲最多存 127 字节，单词加前后缀可放入 160 字节。
         * 固定格式 %s 只把输入当文本，不把输入当 printf 格式字符串。
         */
        (void)snprintf(line, sizeof(line), "L3 ECHO=%s\r\n", args[1]);
        console_message(line); /* 进入 TX 队列，真正写 USART_DR 的是 TXE 中断。 */
        return 1u;
    }

    if (!strcmp(args[0], "uart"))
    {
        if (count != 1u)
        {
            usage("uart");
            return 1u;
        }
        char line[160];
        /* BOARD_UART_BAUD 是配置值；drop 混合统计 RX 错误、RX 满与 TX 入队失败。
         * 它不是严格的“接收丢失字节数”，也不覆盖接收端电脑自己的丢包。
         */
        (void)snprintf(line, sizeof(line),
                       "L3 UART baud=%lu tx=PA9 rx=PA10 drop=%lu\r\n",
                       (unsigned long)BOARD_UART_BAUD,
                       (unsigned long)board_uart_dropped());
        console_message(line);
        return 1u;
    }

    return 0u; /* help/status/log 等原有命令继续由生成的 console 处理。 */
}
