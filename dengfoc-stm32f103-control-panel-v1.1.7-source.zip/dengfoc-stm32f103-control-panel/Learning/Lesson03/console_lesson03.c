/* Generated from App/console.c; edit lesson03_commands.c for command practice. */
/*
 * 串口交互：把收到的文本命令转换为控制请求，并输出带单位缩放的状态。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "console.h"
#include "lesson03_commands.h"
#include "board.h"
#include "motor.h"
#include "settings.h"
#include "oled.h"
#include "app_config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static char input[128];
static unsigned used;
static uint8_t overflow, telemetry = 1u;
/* 保留过滤/分词之前的前 24 个原始字节，供未知命令诊断；包含行尾字节。 */
static uint8_t rx_preview[24], rx_preview_used, error_reported;
static uint32_t command_errors, last_error_ms;
/* 把字符串放入串口发送队列；USART 发送中断逐字节发送，避免等待整行发送完成。 */
void console_message(const char *s)
{
    (void)board_uart_write(s);
}
/* 输出启动提示，明确当前驱动为停机状态，并提示使用 help 查看命令。 */
void console_init(void)
{
    used = overflow = rx_preview_used = error_reported = 0u;
    command_errors = last_error_ms = 0u;
    telemetry = 1u;
    console_message("\r\nDengFOC ControlPanel " APP_VERSION
                    " | PA8 OFF\r\n115200 8N1; type help. No automatic start.\r\n");
}
/* 显示实际收到的字节，区分输入格式、线路乱码和 TX 回接 RX。
 * 最多每 500 ms 报告一次，避免回接时把错误回复再次当命令产生输出风暴。 */
static void unknown_command(const char *cmd)
{
    ++command_errors;
    uint32_t now = board_millis();
    if (error_reported && (uint32_t)(now - last_error_ms) < 500u)
        return;
    error_reported = 1u;
    last_error_ms = now;
    char line[224];
    unsigned n = (unsigned)snprintf(
        line, sizeof(line), "ERR: unknown cmd='%.24s' count=%lu uart_drop=%lu RXHEX:", cmd,
        (unsigned long)command_errors, (unsigned long)board_uart_dropped());
    for (uint8_t i = 0u; i < rx_preview_used; ++i)
        n += (unsigned)snprintf(line + n, sizeof(line) - n, " %02X", (unsigned)rx_preview[i]);
    (void)snprintf(line + n, sizeof(line) - n, "\r\n");
    console_message(line);
}
/* 读取一次完整状态快照。rpm10 为转速×10，pos100 为角度×100，电流转换为 mA。 */
void console_status(void)
{
    MotorStatus s;
    motor_snapshot(&s);
    char line[320];
    snprintf(line, sizeof(line),
             "t=%lu st=%s mode=%s r=%u rpm10=%ld pos100=%ld iq_mA=%ld id_mA=%ld ref_mA=%ld cal=%u "
             "mag=%u off=%u err=%lu fault=%s us=%lu timing=%s tc=%lu sens_us=%lu\r\n",
             (unsigned long)board_millis(), motor_state_name(s.state), motor_mode_name(s.mode),
             (unsigned)s.raw, (long)(s.speed_rpm * 10.0f),
             (long)(s.position_rad * 18000.0f / APP_PI), (long)(s.iq * 1000.0f),
             (long)(s.id * 1000.0f), (long)(s.iq_target * 1000.0f), (unsigned)s.calibrated,
             (unsigned)s.magnet_ok, (unsigned)s.offsets_ready, (unsigned long)s.sensor_errors,
             motor_fault_name(s.fault), (unsigned long)(s.fast_max_cycles / 72u),
             motor_timing_name(s.timing_reason), (unsigned long)s.timing_cycles,
             (unsigned long)(s.sensor_max_cycles / 72u));
    console_message(line);
}
/* 解析一个完整的有限浮点数；参数有多余字符或为 NaN/无穷大时返回 0。 */
static uint8_t number(const char *s, float *f)
{
    char *end;
    *f = strtof(s, &end);
    return s[0] && *end == '\0' && isfinite(*f);
}
/* 向串口反馈命令是否被接受；接受命令不等于电机已经达到目标。 */
static void result(uint8_t ok)
{
    console_message(ok ? "OK\r\n"
                       : "ERR: check state, calibration, wiring, or parameter range\r\n");
}
/* 解析一行 ASCII 命令，按命令名调用电机接口；PID、限幅和按键表统一经过参数校验。 */
static void execute(char *line)
{
    char *args[8];
    unsigned count = 0;
    char *p = strtok(line, " \t");
    while (p && count < 8u)
    {
        args[count++] = p;
        p = strtok(NULL, " \t");
    }
    if (!count)
        return;
    if (lesson03_handle(args, count))
        return;
    const char *cmd = args[0];
    float x = 0.0f;
    AppParams cfg;
    motor_get_params(&cfg);
    if (!strcmp(cmd, "help"))
    {
        console_message(
            "stop | run | cal | clear | status | zero | mode current/speed/position\r\n");
        console_message(
            "speed <rpm> | position <deg> | current <A> | pid c/v/p <kp> <ki> <kd>\r\n");
        console_message("limit voltage/current/trip/speed <value> | bus <V>\r\n");
        console_message(
            "screen sh1106/ssd1306 | ir <key> <hex cmd> | save | defaults | log 0/1\r\n");
        console_message(
            "RUN resets targets; issue target after RUN. CAL rotates shaft for about 3 s.\r\n");
        return;
    }
    if (!strcmp(cmd, "stop") && count == 1u)
    {
        motor_stop();
        result(1u);
        return;
    }
    if (!strcmp(cmd, "run") && count == 1u)
    {
        result(motor_start());
        return;
    }
    if (!strcmp(cmd, "cal") && count == 1u)
    {
        result(motor_calibrate());
        return;
    }
    if (!strcmp(cmd, "clear") && count == 1u)
    {
        result(motor_clear_fault());
        return;
    }
    if (!strcmp(cmd, "status") && count == 1u)
    {
        console_status();
        return;
    }
    if (!strcmp(cmd, "zero") && count == 1u)
    {
        MotorStatus s;
        motor_snapshot(&s);
        if (s.state != MOTOR_STOPPED)
        {
            result(0u);
            return;
        }
        motor_zero_position();
        result(1u);
        return;
    }
    if (!strcmp(cmd, "mode") && count == 2u)
    {
        for (unsigned i = 0; i < 3u; i++)
        {
            const char *name = i == 0u ? "current" : i == 1u ? "speed" : "position";
            if (!strcmp(args[1], name))
            {
                result(motor_set_mode((ControlMode)i));
                return;
            }
        }
        result(0u);
        return;
    }
    if (count == 2u &&
        (!strcmp(cmd, "speed") || !strcmp(cmd, "position") || !strcmp(cmd, "current")))
    {
        if (!number(args[1], &x))
        {
            result(0u);
            return;
        }
        if (!strcmp(cmd, "speed"))
            motor_set_speed(x);
        else if (!strcmp(cmd, "position"))
            motor_set_position(x * (APP_PI / 180.0f));
        else
            motor_set_current(x);
        result(1u);
        return;
    }
    if (!strcmp(cmd, "pid") && count == 5u)
    {
        PidGains g;
        if (!number(args[2], &g.kp) || !number(args[3], &g.ki) || !number(args[4], &g.kd))
        {
            result(0u);
            return;
        }
        if (!strcmp(args[1], "c"))
            cfg.current_pid = g;
        else if (!strcmp(args[1], "v"))
            cfg.speed_pid = g;
        else if (!strcmp(args[1], "p"))
            cfg.position_pid = g;
        else
        {
            result(0u);
            return;
        }
        result(motor_apply_params(&cfg));
        return;
    }
    if (!strcmp(cmd, "limit") && count == 3u && number(args[2], &x))
    {
        if (!strcmp(args[1], "voltage"))
            cfg.voltage_limit = x;
        else if (!strcmp(args[1], "current"))
            cfg.current_limit = x;
        else if (!strcmp(args[1], "trip"))
            cfg.trip_current = x;
        else if (!strcmp(args[1], "speed"))
            cfg.speed_limit_rpm = x;
        else
        {
            result(0u);
            return;
        }
        result(motor_apply_params(&cfg));
        return;
    }
    if (!strcmp(cmd, "bus") && count == 2u && number(args[1], &x))
    {
        cfg.bus_voltage = x;
        result(motor_apply_params(&cfg));
        return;
    }
    if (!strcmp(cmd, "screen") && count == 2u)
    {
        if (!strcmp(args[1], "sh1106"))
            cfg.oled_sh1106 = 1u;
        else if (!strcmp(args[1], "ssd1306"))
            cfg.oled_sh1106 = 0u;
        else
        {
            result(0u);
            return;
        }
        if (motor_apply_params(&cfg))
            result(oled_init((uint8_t)cfg.oled_sh1106));
        else
            result(0u);
        return;
    }
    if (!strcmp(cmd, "ir") && count == 3u)
    {
        int key = params_key_index(args[1]);
        char *end;
        unsigned long value = strtoul(args[2], &end, 16);
        if (key < 0 || *end || value > 255u)
        {
            result(0u);
            return;
        }
        cfg.ir_codes[key] = (uint8_t)value;
        result(motor_apply_params(&cfg));
        return;
    }
    if (!strcmp(cmd, "save") && count == 1u)
    {
        result(settings_save(&cfg));
        return;
    }
    if (!strcmp(cmd, "defaults") && count == 1u)
    {
        motor_stop();
        params_defaults(&cfg);
        result(motor_apply_params(&cfg));
        return;
    }
    if (!strcmp(cmd, "log") && count == 2u && number(args[1], &x) && (x == 0 || x == 1))
    {
        telemetry = (uint8_t)x;
        result(1u);
        return;
    }
    unknown_command(cmd);
}
/* 后台轮询入口：每次最多处理 64 个接收字符，并按 100 ms 周期输出状态。 */
void console_poll(void)
{
    int c;
    unsigned budget = 64u;
    while (budget-- && (c = board_uart_read()) >= 0)
    {
        if (rx_preview_used < sizeof(rx_preview))
            rx_preview[rx_preview_used++] = (uint8_t)c;
        if (c == '\r' || c == '\n')
        {
            if (overflow)
                console_message("ERR: command too long\r\n");
            else if (used)
            {
                input[used] = '\0';
                execute(input);
            }
            used = 0u;
            overflow = 0u;
            rx_preview_used = 0u;
        }
        else if (c == 8 || c == 127)
        {
            if (used)
                --used;
        }
        else if (c >= 32 && c < 127)
        {
            if (used < sizeof(input) - 1u)
                input[used++] = (char)c;
            else
                overflow = 1u;
        }
    }
    static uint32_t last;
    uint32_t now = board_millis();
    if (telemetry && (uint32_t)(now - last) >= 100u)
    {
        last = now;
        console_status();
    }
}
