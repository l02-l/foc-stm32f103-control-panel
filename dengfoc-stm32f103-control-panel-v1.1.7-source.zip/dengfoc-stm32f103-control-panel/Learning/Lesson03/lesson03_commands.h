/* 第三课命令扩展：只有学习工程使用，正式 console.c 保持原样。 */
#ifndef LESSON03_COMMANDS_H
#define LESSON03_COMMANDS_H
#include <stdint.h>

/* 返回 1 表示已处理这个命令（含反馈用法错误）；0 表示交给原命令处理器。 */
uint8_t lesson03_handle(char *args[], unsigned count);

#endif
