/*
 * ARM 代码仿真测试：使用合成传感器输入验证算法与状态机，不代表实物电机已调通。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
/* Executed as the compiled ARM code under Unicorn, not a Python rewrite. */
#include "control_math.h"
#include "params.h"
#include "nec_decoder.h"
#include "motor.h"
#include "board.h"
#include "app_config.h"
#include "soft_i2c.h"
#include "console.h"
#include "settings.h"
#include "oled.h"
#include "as5600.h"
#include <math.h>
#include <string.h>

volatile uint32_t test_checks, test_failures, test_failed_lines[64];
static uint32_t fake_cycles, fake_ms;
static uint8_t gate;
static uint16_t pwm_a, pwm_b, pwm_c;
static uint8_t current_pending;
void board_current_request(void)
{
    current_pending = 1u;
}
static void inject_adc(uint16_t a, uint16_t b)
{
    motor_adc_isr(a, b);
    if (current_pending)
    {
        current_pending = 0u;
        motor_current_task();
    }
}
static const char *fake_uart_input;
static char fake_uart_output[2048];
static unsigned fake_uart_length;
uint8_t board_uart_write(const char *text)
{
    unsigned n = (unsigned)strlen(text);
    if (fake_uart_length + n >= sizeof(fake_uart_output))
        return 0u;
    memcpy(fake_uart_output + fake_uart_length, text, n + 1u);
    fake_uart_length += n;
    return 1u;
}
int board_uart_read(void)
{
    if (!fake_uart_input || !*fake_uart_input)
        return -1;
    return (uint8_t)*fake_uart_input++;
}
uint32_t board_uart_dropped(void)
{
    return 0u;
}
uint8_t settings_save(const AppParams *p)
{
    (void)p;
    return 1u; /* 仅满足命令层链接；此测试不验证真实 Flash。 */
}
uint8_t oled_init(uint8_t type)
{
    (void)type;
    return 1u;
}
/* 只模拟 I²C 的传输边界，AS5600 解析执行真实 ARM 代码。 */
const SoftI2c sensor_bus = {GPIOB, GPIO_Pin_10, GPIO_Pin_11};
static uint8_t fake_sensor_bytes[3], fake_sensor_fail;
uint8_t soft_i2c_read_reg(const SoftI2c *b, uint8_t addr, uint8_t reg, uint8_t *out, uint16_t n)
{
    if (b != &sensor_bus || addr != 0x36u || reg != 0x0Bu || n != 3u || fake_sensor_fail)
        return 0u;
    memcpy(out, fake_sensor_bytes, 3u);
    return 1u;
}
void soft_i2c_init(const SoftI2c *b)
{
    (void)b;
}
uint32_t board_lock(void)
{
    return 0u;
}
void board_unlock(uint32_t key)
{
    (void)key;
}
uint32_t board_cycles(void)
{
    return fake_cycles;
}
uint32_t board_millis(void)
{
    return fake_ms;
}
void board_gate(uint8_t enabled)
{
    gate = enabled;
}
void board_pwm(uint16_t a, uint16_t b, uint16_t c)
{
    pwm_a = a;
    pwm_b = b;
    pwm_c = c;
}
void board_pwm_latch(void)
{
}
static void check(uint8_t condition, uint32_t line)
{
    ++test_checks;
    if (!condition)
    {
        if (test_failures < 64u)
            test_failed_lines[test_failures] = line;
        ++test_failures;
    }
}
#define CHECK(x) check((uint8_t)(x), __LINE__)
static uint8_t near(float a, float b, float e)
{
    return fabsf(a - b) <= e;
}
static void test_math(void)
{
    CHECK(cm_angle_delta(3u, 4095u) == 4);
    CHECK(cm_angle_delta(4095u, 3u) == -4);
    CHECK(cm_angle_delta(400u, 410u) == -10);
    CHECK(cm_angle_delta(0u, 2048u) == -2048);
    AngleTracker t = {0};
    int32_t delta;
    CHECK(!cm_tracker_update(&t, 4095u, &delta) && delta == 0 && t.continuous == 4095);
    CHECK(cm_tracker_update(&t, 3u, &delta) && delta == 4 && t.continuous == 4099);
    CHECK(cm_tracker_update(&t, 4095u, &delta) && delta == -4 && t.continuous == 4095);
    t.continuous = 2147483647LL;
    CHECK(cm_tracker_update(&t, 0u, &delta) && t.continuous == 2147483648LL);
    for (int i = -100; i <= 100; i++)
    {
        float a = (float)i * 0.17f, s, c;
        cm_sincos(a, &s, &c);
        CHECK(near(s, sinf(a), 0.00003f));
        CHECK(near(c, cosf(a), 0.00003f));
    }
    float s, c, id, iq;
    cm_sincos(0.0f, &s, &c);
    cm_dq(1.0f, -0.5f, s, c, &id, &iq);
    CHECK(near(id, 1, 0.00001f) && near(iq, 0, 0.00001f));
    PhaseVoltage v = cm_modulate(0, 2, 1, 0, 12);
    CHECK(near(v.a, 1.0f / 3.0f, 0.00001f));
    CHECK(near(v.b, 7.0f / 12.0f, 0.00001f) && near(v.c, 7.0f / 12.0f, 0.00001f));
    CHECK(near(v.a + v.b + v.c, 1.5f, 0.00001f));
    CHECK(cm_duty_compare(0.25f, 4800u) == 1200u && cm_duty_compare(1.0f, 4800u) == 4800u);
    CHECK(cm_crc32("123456789", 9u) == 0xCBF43926u);
    PidState p = {0};
    PidGains g = {2, 10, 0};
    for (unsigned i = 0; i < 1000u; i++)
    {
        float u = cm_pid_step(&p, &g, 100, 0, 0.001f, 1);
        CHECK(u <= 1.0f && u >= -1.0f);
        cm_pid_track(&p, u, u * 0.7f, 1);
        CHECK(fabsf(p.integral) <= 1.0f);
    }
    cm_pid_reset(&p);
    CHECK(!p.initialized && p.integral == 0);
    CHECK(cm_pid_step(&p, &g, 1, 0, 0, 1) == 0);
    /* Kd 关闭时仍更新历史测量，重新启用后只对最近一步差值求导。 */
    cm_pid_reset(&p);
    g = (PidGains){0, 0, 2};
    CHECK(near(cm_pid_step(&p, &g, 0, 0, 0.1f, 10), 0, 0.00001f));
    CHECK(near(cm_pid_step(&p, &g, 0, 0.1f, 0.1f, 10), -2, 0.00001f));
    g.kd = 0;
    CHECK(near(cm_pid_step(&p, &g, 0, 0.2f, 0.1f, 10), 0, 0.00001f));
    g.kd = 2;
    CHECK(near(cm_pid_step(&p, &g, 0, 0.3f, 0.1f, 10), -2, 0.00001f));
}
static void test_params(void)
{
    AppParams p;
    params_defaults(&p);
    CHECK(params_valid(&p) && p.reserved_input == 0u);
    p.reserved_input = 1u; /* 兼容旧 Flash 中的旋钮启用标记。 */
    CHECK(params_valid(&p));
    p.current_limit = NAN;
    CHECK(!params_valid(&p));
    params_defaults(&p);
    p.trip_current = p.current_limit;
    CHECK(!params_valid(&p));
    params_defaults(&p);
    p.pole_pairs = 0u;
    CHECK(!params_valid(&p));
    params_defaults(&p);
    p.sensor_direction = 0;
    CHECK(!params_valid(&p));
    params_defaults(&p);
    p.electrical_zero = APP_TAU;
    CHECK(!params_valid(&p));
    params_defaults(&p);
    p.bus_voltage = 8.0f;
    p.voltage_limit = 2.0f;
    CHECK(params_valid(&p));
    p.voltage_limit = 2.01f;
    CHECK(!params_valid(&p));
    p.bus_voltage = 12.0f;
    p.voltage_limit = 3.0f;
    CHECK(params_valid(&p));
    CHECK(params_key_index("ok") == KEY_OK && params_key_index("missing") == -1);
}
static void test_nec(void)
{
    NecDecoder d = {0};
    CHECK(nec_falling(&d, 13500u) == 0u);
    uint32_t bits = 0xE71800FFu;
    uint8_t result = 0u;
    for (unsigned i = 0; i < 32u; i++)
    {
        result = nec_falling(&d, (bits & (1u << i)) ? 2250u : 1125u);
        if (i < 31u)
            CHECK(!result);
    }
    CHECK(result == 1u && d.command == 0x18u && d.address == 0x00FFu);
    CHECK(nec_falling(&d, 11250u) == 2u && d.repeat);
    CHECK(!nec_falling(&d, 13500u));
    bits = 0x001800FFu;
    for (unsigned i = 0; i < 32u; i++)
        result = nec_falling(&d, (bits & (1u << i)) ? 2250u : 1125u);
    CHECK(result == 0u);
    CHECK(!nec_falling(&d, 13500u));
    CHECK(!nec_falling(&d, 5000u) && !d.state);
}
static void tick(uint16_t raw)
{
    ++fake_ms;
    fake_cycles += 72000u;
    motor_sensor_isr(raw, 1u, 1u, fake_cycles, fake_ms);
    for (unsigned i = 0; i < 15u; i++)
        inject_adc(2050u, 2052u);
}
static void test_motor(void)
{
    AppParams p;
    params_defaults(&p);
    motor_init(&p);
    MotorStatus st;
    CHECK(!gate && !motor_start());
    for (unsigned i = 0; i < 300u; i++)
        tick(1000u);
    motor_snapshot(&st);
    CHECK(st.offsets_ready && st.state == MOTOR_STOPPED && !gate);
    CHECK(!motor_start());
    CHECK(motor_calibrate() && gate);
    uint32_t started = fake_ms;
    for (unsigned e = 1; e <= 2910u; e++)
    {
        float fraction = e < 500u ? 0.0f : e < 2500u ? (float)(e - 500u) / 2000.0f : 1.0f;
        uint16_t raw = (uint16_t)(1000.0f + 4096.0f * fraction / 7.0f + 0.5f);
        tick(raw);
    }
    (void)started;
    motor_snapshot(&st);
    motor_get_params(&p);
    CHECK(st.state == MOTOR_STOPPED && !gate && p.calibrated && p.pole_pairs == 7u &&
          p.sensor_direction == 1);
    CHECK(motor_set_mode(MODE_CURRENT) && motor_start() && gate);
    motor_set_current(0.1f);
    for (unsigned i = 0; i < 100u; i++)
        tick(1585u);
    motor_snapshot(&st);
    CHECK(st.state == MOTOR_RUNNING && st.iq_target > 0 && st.iq_target <= 0.1f);
    CHECK(pwm_a <= 4800u && pwm_b <= 4800u && pwm_c <= 4800u);
    CHECK(fabsf(st.ud) <= p.voltage_limit && fabsf(st.uq) <= p.voltage_limit);
    motor_sensor_isr(0u, 0u, 1u, fake_cycles, fake_ms);
    motor_snapshot(&st);
    CHECK(st.state == MOTOR_FAULT && st.fault == FAULT_SENSOR && !gate);
    CHECK(!motor_start());
    tick(1585u);
    CHECK(motor_clear_fault());
    CHECK(motor_start());
    inject_adc(3000u, 2052u);
    motor_snapshot(&st);
    CHECK(st.fault == FAULT_OVERCURRENT && st.state == MOTOR_FAULT && !gate && pwm_a == 0u);
    tick(1585u);
    CHECK(motor_clear_fault());
    CHECK(motor_start());
    fake_cycles += 300000u;
    for (unsigned i = 0; i < 5u; i++)
        inject_adc(2050u, 2052u);
    motor_snapshot(&st);
    CHECK(st.state == MOTOR_FAULT && !gate && st.fault == FAULT_SENSOR);
    tick(1585u);
    CHECK(motor_clear_fault());
    CHECK(motor_calibrate());
    for (unsigned e = 1; e <= 2910u; e++)
    {
        float fraction = e < 500u ? 0.0f : e < 2500u ? (float)(e - 500u) / 2000.0f : 1.0f;
        tick((uint16_t)(1585.0f - 4096.0f * fraction / 7.0f + 0.5f));
    }
    motor_get_params(&p);
    motor_snapshot(&st);
    CHECK(p.calibrated && p.pole_pairs == 7u && p.sensor_direction == -1 &&
          st.state == MOTOR_STOPPED && !gate);
    for (unsigned i = 0; i < 100u; i++)
        tick(1000u);
    CHECK(motor_set_mode(MODE_SPEED) && motor_start());
    motor_set_speed(30.0f);
    for (unsigned i = 0; i < 100u; i++)
        tick(1000u);
    motor_snapshot(&st);
    CHECK(st.mode == MODE_SPEED && st.iq_target > 0 && st.iq_target <= p.current_limit);
    CHECK(motor_set_mode(MODE_POSITION) && !gate && motor_start());
    motor_set_position(0.5f);
    for (unsigned i = 0; i < 100u; i++)
        tick(1000u);
    motor_snapshot(&st);
    CHECK(st.mode == MODE_POSITION && st.iq_target > 0 && st.iq_target <= p.current_limit);
    motor_stop();
    CHECK(!gate);
}
/* 验证采样只发布任务，以及未及时消费多个控制节拍时确实关桥。 */
static void test_reinitialization(void)
{
    AppParams p;
    params_defaults(&p);
    motor_init(&p);
    tick(1000u);
    tick(1100u);
    MotorStatus st;
    motor_snapshot(&st);
    CHECK(st.position_rad > 0);
    motor_zero_position();
    motor_snapshot(&st);
    CHECK(st.position_rad == 0 && st.position_target_rad == 0);
    motor_init(&p);
    for (unsigned i = 0; i < 4095u; ++i)
        inject_adc(2000u, 2010u);
    motor_snapshot(&st);
    CHECK(!st.offsets_ready && st.current_steps > 0 && !gate);
    inject_adc(2000u, 2010u);
    motor_snapshot(&st);
    CHECK(st.offsets_ready && st.offset_a == 2000.0f && st.offset_b == 2010.0f);
    /* 模拟无模拟电源：故障仍保持任务心跳，不需要靠反复复位处理。 */
    motor_init(&p);
    for (unsigned i = 0; i < 4500u; ++i)
        inject_adc(0u, 0u);
    motor_snapshot(&st);
    CHECK(st.fault == FAULT_ADC && !st.offsets_ready && st.current_steps >= 900u && !gate);
}
static void test_control_dispatch(void)
{
    AppParams p;
    params_defaults(&p);
    p.calibrated = 1u;
    current_pending = 0u;
    motor_init(&p);
    for (unsigned i = 0; i < 300u; ++i)
        tick(1000u);
    MotorStatus before, after;
    motor_snapshot(&before);
    for (unsigned i = 0; i < 5u; ++i)
        motor_adc_isr(2050u, 2052u);
    motor_snapshot(&after);
    CHECK(current_pending && after.current_steps == before.current_steps);
    current_pending = 0u;
    motor_current_task();
    motor_snapshot(&after);
    CHECK(after.current_steps == before.current_steps + 1u && !gate);
    CHECK(motor_start());
    for (unsigned i = 0; i < 10u; ++i)
        motor_adc_isr(2050u, 2052u);
    current_pending = 0u;
    motor_current_task();
    motor_snapshot(&after);
    CHECK(after.state == MOTOR_FAULT && after.fault == FAULT_TIMING && !gate && pwm_a == 0u);
    CHECK(after.timing_reason == TIMING_BACKLOG && after.timing_cycles == 2u);
}
static void receive_command(const char *text)
{
    fake_uart_input = text;
    fake_uart_length = 0u;
    fake_uart_output[0] = '\0';
    console_poll();
}
static void test_console(void)
{
    AppParams p;
    params_defaults(&p);
    p.reserved_input = 1u; /* 模拟带旧输入标记的参数，启动应保持 STOP。 */
    motor_init(&p);
    motor_get_params(&p);
    CHECK(p.reserved_input == 0u);
    console_init();
    receive_command("help\n");
    CHECK(strstr(fake_uart_output, "stop | run | cal") != 0);
    receive_command("HELP\n");
    CHECK(strstr(fake_uart_output, "cmd='HELP'") != 0);
    CHECK(strstr(fake_uart_output, "48 45 4C 50 0A") != 0);
    receive_command("HELP\n");
    CHECK(fake_uart_output[0] == '\0'); /* 抑制回接时的错误回复风暴。 */
    fake_ms += 500u;
    receive_command("t=100 st=STOP\n");
    CHECK(strstr(fake_uart_output, "cmd='t=100'") != 0);
    CHECK(strstr(fake_uart_output, "74 3D 31 30 30 20") != 0);
    receive_command("help\r\n");
    CHECK(strstr(fake_uart_output, "stop | run | cal") != 0);
    receive_command("status\n");
    CHECK(strstr(fake_uart_output, "st=STOP") != 0);
    CHECK(strstr(fake_uart_output, " pot=") == 0 && strstr(fake_uart_output, " link=") == 0);
}
/* 用合成 I²C 边界执行真正的 AS5600 解析代码，不代替实机顺序读与时序验证。 */
static void test_as5600_sample(void)
{
    uint16_t raw = 1234u;
    uint8_t magnet = 99u;
    fake_sensor_fail = 1u;
    CHECK(!as5600_sample(&raw, &magnet));
    CHECK(raw == 1234u && magnet == 0u);
    fake_sensor_fail = 0u;
    fake_sensor_bytes[0] = 0x20u;
    fake_sensor_bytes[1] = 0x0Fu;
    fake_sensor_bytes[2] = 0xFFu;
    CHECK(as5600_sample(&raw, &magnet));
    CHECK(raw == 4095u && magnet == 1u);
    fake_sensor_bytes[1] = 0u;
    fake_sensor_bytes[2] = 0u;
    CHECK(as5600_sample(&raw, &magnet) && raw == 0u && magnet == 1u);
    const uint8_t bad_magnets[] = {0u, 0x28u, 0x30u, 0x38u};
    for (unsigned i = 0; i < sizeof(bad_magnets); ++i)
    {
        fake_sensor_bytes[0] = bad_magnets[i];
        CHECK(as5600_sample(&raw, &magnet));
        CHECK(magnet == 0u);
    }
    fake_sensor_bytes[0] = 0x20u;
    fake_sensor_bytes[1] = 0x10u;
    CHECK(!as5600_sample(&raw, &magnet) && magnet == 0u);
}
uint32_t tests_run_all(void)
{
    test_as5600_sample();
    test_math();
    test_params();
    test_nec();
    test_motor();
    test_control_dispatch();
    test_reinitialization();
    test_console();
    return test_failures;
}
int main(void)
{
    return (int)tests_run_all();
}
