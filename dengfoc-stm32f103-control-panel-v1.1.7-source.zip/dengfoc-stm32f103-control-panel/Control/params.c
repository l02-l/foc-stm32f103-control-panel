/*
 * 参数管理：给出初始值、检查可用范围，提供遥控按键名称与命令码的对应关系。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "params.h"
#include "app_config.h"
#include <string.h>
#include <math.h>
static const char *const names[KEY_COUNT] = {"up",   "down", "left", "right", "ok", "star",
                                             "hash", "0",    "1",    "2",     "3",  "4",
                                             "5",    "6",    "7",    "8",     "9"};
/* 建立完整默认参数；先清结构体，避免未初始化的保留字节影响保存记录。 */
void params_defaults(AppParams *p)
{
    static const uint8_t codes[KEY_COUNT] = {0x18, 0x52, 0x08, 0x5A, 0x1C, 0x16, 0x0D, 0x19, 0x45,
                                             0x46, 0x47, 0x44, 0x40, 0x43, 0x07, 0x15, 0x09};
    memset(p, 0, sizeof(*p));
    /* 已在当前 12 V/2208 无负载样机上完成低电流、±10 rpm 和小角度位置试运行。 */
    p->current_pid = (PidGains){2.0f, 500.0f, 0.0f};
    p->speed_pid = (PidGains){0.05f, 0.01f, 0.0f};
    p->position_pid = (PidGains){5.0f, 0.0f, 0.0f};
    p->bus_voltage = 12.0f;
    p->voltage_limit = 1.0f;
    p->current_limit = 0.20f;
    p->trip_current = 0.60f;
    p->speed_limit_rpm = 60.0f;
    p->speed_slew_rpm_s = 30.0f;
    p->current_slew_a_s = 0.3f;
    p->calibration_voltage = 1.0f;
    p->pole_pairs = 7u;
    p->sensor_direction = 1;
    p->oled_sh1106 = BOARD_OLED_SH1106;
    memcpy(p->ir_codes, codes, sizeof(codes));
}
/* 检查一组 PID 增益为有限且非负的数，并处于本项目允许范围。 */
static uint8_t gains_ok(PidGains g)
{
    return isfinite(g.kp) && isfinite(g.ki) && isfinite(g.kd) && g.kp >= 0 && g.kp <= 100 &&
           g.ki >= 0 && g.ki <= 2000 && g.kd >= 0 && g.kd <= 1;
}
/* 检查参数之间的关系，例如跳闸电流大于目标上限、校准电压不超过输出上限。 */
uint8_t params_valid(const AppParams *p)
{
    const float f[] = {p->bus_voltage,      p->voltage_limit,       p->current_limit,
                       p->trip_current,     p->speed_limit_rpm,     p->speed_slew_rpm_s,
                       p->current_slew_a_s, p->calibration_voltage, p->electrical_zero};
    for (unsigned i = 0; i < sizeof(f) / sizeof(f[0]); i++)
        if (!isfinite(f[i]))
            return 0u;
    if (!gains_ok(p->current_pid) || !gains_ok(p->speed_pid) || !gains_ok(p->position_pid))
        return 0u;
    return p->bus_voltage >= 8.0f && p->bus_voltage <= 16.0f && p->voltage_limit >= 0.1f &&
           p->voltage_limit <= 3.0f && p->voltage_limit <= p->bus_voltage * 0.25f &&
           p->current_limit >= 0.01f && p->current_limit <= 0.5f &&
           p->trip_current > p->current_limit && p->trip_current <= 1.0f &&
           p->speed_limit_rpm >= 1 && p->speed_limit_rpm <= 300 && p->speed_slew_rpm_s >= 1 &&
           p->speed_slew_rpm_s <= 300 && p->current_slew_a_s >= 0.01f && p->current_slew_a_s <= 2 &&
           p->calibration_voltage >= 0.1f && p->calibration_voltage <= p->voltage_limit &&
           p->electrical_zero >= 0 && p->electrical_zero < APP_TAU && p->pole_pairs >= 1u &&
           p->pole_pairs <= 30u && (p->sensor_direction == 1 || p->sensor_direction == -1) &&
           p->calibrated <= 1u && p->reserved_input <= 1u && p->oled_sh1106 <= 1u;
}
/* 用按键枚举查名称，供命令映射和调试使用。 */
const char *params_key_name(RemoteKey key)
{
    return key < KEY_COUNT ? names[key] : "?";
}
/* 用文本名称查按键枚举；找不到返回 -1，避免把无效名称写入按键表。 */
int params_key_index(const char *s)
{
    for (int i = 0; i < KEY_COUNT; i++)
        if (strcmp(s, names[i]) == 0)
            return i;
    return -1;
}
