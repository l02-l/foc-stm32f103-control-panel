/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef CONTROL_MATH_H
#define CONTROL_MATH_H
#include <stdint.h>

/* 增益没有统一单位：电流环输出 V，速度环输出 A，位置环输出 rad/s。 */
typedef struct
{
    float kp, ki, kd;
} PidGains;
/* integral 保存已累积的积分输出；previous_measurement 用于对测量值求微分。 */
typedef struct
{
    float integral, previous_measurement;
    uint8_t initialized;
} PidState;
/* previous 为上一帧单圈计数；continuous 为 64 位累计计数；valid 表示是否已有上一帧。 */
typedef struct
{
    uint16_t previous;
    int64_t continuous;
    uint8_t valid;
} AngleTracker;
/* a/b/c 表示调制后的三相占空比（0～1），已除以母线电压，单位不再是 V。 */
typedef struct
{
    float a, b, c;
} PhaseVoltage;

float cm_clamp(float x, float lo, float hi);
float cm_wrap(float radians);
void cm_sincos(float angle, float *sine, float *cosine);
int32_t cm_angle_delta(uint16_t now, uint16_t before);
uint8_t cm_tracker_update(AngleTracker *t, uint16_t raw, int32_t *delta);
void cm_pid_reset(PidState *p);
float cm_pid_step(PidState *p, const PidGains *g, float error, float measurement, float dt,
                  float limit);
void cm_pid_track(PidState *p, float requested, float applied, float limit);
void cm_dq(float ia, float ib, float s, float c, float *id, float *iq);
PhaseVoltage cm_modulate(float ud, float uq, float s, float c, float bus);
uint16_t cm_duty_compare(float duty, uint16_t period);
uint32_t cm_crc32(const void *data, uint32_t size);
#endif
