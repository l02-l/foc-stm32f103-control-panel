/*
 * 控制数学：角度处理、PID、Clarke/Park、反变换和三相占空比，公式对应 DengFOC 例程。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
/* 控制公式参考本地 DengFOC 例程；使用显式 dt、查表三角函数和抗积分饱和。 */
#include "control_math.h"
#include "app_config.h"
#include <math.h>

/* 四分之一正弦表由 Tools/generate_tables.py 生成，完整周期由象限对称性还原。 */
#include "sine_table.h"

/* 限幅：把 x 限制在闭区间 [lo, hi]，用于目标、电压、电流和积分限制。 */
float cm_clamp(float x, float lo, float hi)
{
    return x < lo ? lo : (x > hi ? hi : x);
}
/* 把弧度角归一化到 [0, 2π)。floorf 能正确处理负角度，避免整数取余用于浮点角。 */
float cm_wrap(float a)
{
    if (!isfinite(a))
        return 0.0f;
    a -= floorf(a / APP_TAU) * APP_TAU;
    return a >= APP_TAU ? 0.0f : a;
}
/* 把角度映射到四个象限，查四分之一周期表并线性插值，减少快速环的三角函数开销。 */
static float sine_lookup_phase(float x)
{
    uint32_t whole = (uint32_t)x;
    uint32_t quadrant = whole >> 8;
    float f = x - (float)(quadrant << 8);
    if (quadrant & 1u)
        f = 256.0f - f;
    uint32_t i = (uint32_t)f;
    float value = i >= 256u
                      ? 1.0f
                      : sine_quarter[i] + (sine_quarter[i + 1u] - sine_quarter[i]) * (f - (float)i);
    return (quadrant & 2u) ? -value : value;
}
/* 输入 angle 单位为弧度；通过输出指针返回 sin 和 cos，供坐标变换重复使用。 */
void cm_sincos(float a, float *s, float *c)
{
    /* 同一电角只归一化一次。余弦相位比正弦多四分之一圈（256 个表格单位），
     * 避免在无 FPU 的 F103 上重复执行浮点除法和 floorf。 */
    float x = cm_wrap(a) * (512.0f / APP_PI);
    if (x >= 1024.0f)
        x = 0.0f; /* 接近 2π 的浮点舍入不能使象限索引变成 4。 */
    *s = sine_lookup_phase(x);
    x += 256.0f;
    if (x >= 1024.0f)
        x -= 1024.0f;
    *c = sine_lookup_phase(x);
}
/* 求两个 12 位角度之间的最短有符号增量；假设相邻采样真实位移小于半圈。 */
int32_t cm_angle_delta(uint16_t now, uint16_t before)
{
    int32_t d = (int32_t)now - (int32_t)before;
    if (d > 2048)
        d -= 4096;
    else if (d < -2048)
        d += 4096;
    return d;
}
/* 首帧建立连续角起点并返回 0；后续累计修正增量、更新 previous，再返回 1。 */
uint8_t cm_tracker_update(AngleTracker *t, uint16_t raw, int32_t *delta)
{
    if (!t->valid)
    {
        t->continuous = raw;
        t->previous = raw;
        t->valid = 1u;
        *delta = 0;
        return 0u;
    }
    *delta = cm_angle_delta(raw, t->previous);
    t->continuous += *delta;
    t->previous = raw;
    return 1u;
}
/* 清除积分和上次测量值；停机/切换模式时调用，避免沿用旧控制状态。 */
void cm_pid_reset(PidState *p)
{
    p->integral = 0.0f;
    p->previous_measurement = 0.0f;
    p->initialized = 0u;
}
/* 离散 PID：e=目标-测量，y=当前测量，dt 单位 s，limit 为输出绝对上限。微分对测量求导。 */
float cm_pid_step(PidState *p, const PidGains *g, float e, float y, float dt, float limit)
{
    if (!(dt > 0.0f) || !(limit > 0.0f))
        return 0.0f;
    /* 使用 PI（Kd=0）时不计算微分除法，历史测量值仍在下方正常更新。 */
    float derivative = p->initialized && g->kd != 0.0f
                           ? -(y - p->previous_measurement) / dt
                           : 0.0f;
    float next = cm_clamp(p->integral + g->ki * e * dt, -limit, limit);
    float pd = g->kp * e + g->kd * derivative;
    float u = pd + next;
    /* 未饱和时正常积分；饱和后仅允许能使输出退出饱和的方向继续积分。 */
    if ((u <= limit && u >= -limit) || (u > limit && e < 0.0f) || (u < -limit && e > 0.0f))
        p->integral = next;
    p->previous_measurement = y;
    p->initialized = 1u;
    return cm_clamp(pd + p->integral, -limit, limit);
}
/* 矢量统一限幅后，用实际输出修正积分并再次限幅，避免两个轴的积分持续积累。 */
void cm_pid_track(PidState *p, float requested, float applied, float limit)
{
    p->integral = cm_clamp(p->integral + applied - requested, -limit, limit);
}
/* 两相电流先作 Clarke，再作 Park：输出 Id/Iq，单位 A；s/c 是当前电角的 sin/cos。 */
void cm_dq(float ia, float ib, float s, float c, float *id, float *iq)
{
    float beta = 0.57735026919f * ia + 1.15470053838f * ib;
    *id = ia * c + beta * s;
    *iq = beta * c - ia * s;
}
/* 反 Park 将 Ud/Uq 变为 Uα/Uβ，再反 Clarke 并加母线中点，返回三路无量纲占空比。 */
PhaseVoltage cm_modulate(float ud, float uq, float s, float c, float bus)
{
    float alpha = ud * c - uq * s, beta = ud * s + uq * c;
    /* bus 已由参数检查保证为正；一次求倒数，三相共用，公式仍为 0.5+相电压/bus。 */
    float inverse_bus = 1.0f / bus;
    PhaseVoltage v = {0.5f + alpha * inverse_bus,
                      0.5f + (-0.5f * alpha + 0.86602540378f * beta) * inverse_bus,
                      0.5f + (-0.5f * alpha - 0.86602540378f * beta) * inverse_bus};
    return v;
}
/* 把 0～1 占空比变成比较值并四舍五入；period 应传 ARR+1，本工程为 4800。 */
uint16_t cm_duty_compare(float duty, uint16_t period)
{
    return (uint16_t)(cm_clamp(duty, 0.0f, 1.0f) * (float)period + 0.5f);
}
/* 计算 CRC32，用来判断 Flash 参数记录是否完整；它不是电机控制算法的一部分。 */
uint32_t cm_crc32(const void *data, uint32_t size)
{
    const uint8_t *p = (const uint8_t *)data;
    uint32_t crc = 0xFFFFFFFFu;
    while (size--)
    {
        crc ^= *p++;
        for (uint8_t b = 0; b < 8u; b++)
            crc = (crc >> 1) ^ ((0u - (crc & 1u)) & 0xEDB88320u);
    }
    return ~crc;
}
