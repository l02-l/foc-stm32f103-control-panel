/*
 * NEC 协议解码：根据相邻下降沿时间差判断引导码、数据位和重复帧。
 * 中文说明采用 UTF-8 编码；外设访问使用 STM32F10x 标准外设库。
 */
#include "nec_decoder.h"
/* 输入相邻下降沿间隔，单位 μs。返回 0=未完成/无效，1=新命令，2=长按重复。 */
uint8_t nec_falling(NecDecoder *d, uint16_t us)
{
    if (us >= 12500u && us <= 14500u)
    {
        d->bits = 0u;
        d->count = 0u;
        d->state = 1u;
        return 0u;
    }
    if (us >= 10500u && us <= 12000u)
    {
        d->state = 0u;
        d->repeat = 1u;
        return 2u;
    }
    if (!d->state)
        return 0u;
    uint8_t bit;
    if (us >= 800u && us <= 1450u)
        bit = 0u;
    else if (us >= 1800u && us <= 2700u)
        bit = 1u;
    else
    {
        d->state = 0u;
        return 0u;
    }
    d->bits |= (uint32_t)bit << d->count;
    if (++d->count < 32u)
        return 0u;
    d->state = 0u;
    uint8_t cmd = (uint8_t)(d->bits >> 16), inv = (uint8_t)(d->bits >> 24);
    if ((uint8_t)(cmd ^ inv) != 0xFFu)
        return 0u;
    d->address = (uint16_t)d->bits;
    d->command = cmd;
    d->repeat = 0u;
    return 1u;
}
