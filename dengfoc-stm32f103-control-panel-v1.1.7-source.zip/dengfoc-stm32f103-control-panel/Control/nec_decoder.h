/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef NEC_DECODER_H
#define NEC_DECODER_H
#include <stdint.h>
typedef struct
{
    uint32_t bits;
    uint8_t state, count;
    uint16_t address;
    uint8_t command, repeat;
} NecDecoder;
/* Called on each falling edge; elapsed is time since the preceding falling edge. */
uint8_t nec_falling(NecDecoder *d, uint16_t elapsed_us);
#endif
