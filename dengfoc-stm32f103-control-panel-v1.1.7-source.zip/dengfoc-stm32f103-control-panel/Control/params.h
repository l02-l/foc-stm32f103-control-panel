/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef PARAMS_H
#define PARAMS_H
#include "control_math.h"

/* 三种模式分别从电流目标、速度目标、位置目标进入同一个 FOC 控制链。 */
typedef enum
{
    MODE_CURRENT = 0,
    MODE_SPEED = 1,
    MODE_POSITION = 2
} ControlMode;
typedef enum
{
    KEY_UP,
    KEY_DOWN,
    KEY_LEFT,
    KEY_RIGHT,
    KEY_OK,
    KEY_STAR,
    KEY_HASH,
    KEY_0,
    KEY_1,
    KEY_2,
    KEY_3,
    KEY_4,
    KEY_5,
    KEY_6,
    KEY_7,
    KEY_8,
    KEY_9,
    KEY_COUNT
} RemoteKey;
typedef struct
{
    PidGains current_pid, speed_pid, position_pid; /* 三环增益；d/q 轴共用一组电流增益 */
    float bus_voltage, voltage_limit, current_limit, trip_current; /* 单位依次为 V、V、A、A */
    float speed_limit_rpm, speed_slew_rpm_s, current_slew_a_s;     /* rpm、rpm/s、A/s */
    float calibration_voltage, electrical_zero;    /* d 轴校准电压 V，真实电角零偏 rad */
    uint32_t pole_pairs;                           /* 极对数，不是磁极总数 */
    int32_t sensor_direction;                      /* 传感器方向，只能是 +1 或 -1 */
    uint32_t calibrated;
    uint32_t reserved_input; /* 保留 Flash v1 布局，兼容旧记录中的 0 或 1。 */
    uint32_t oled_sh1106;
    uint8_t ir_codes[KEY_COUNT];                   /* 各菜单按键对应的 NEC 命令字节 */
    uint8_t reserved[3];                           /* 保留并清零，使参数记录布局固定、按字对齐 */
} AppParams;

void params_defaults(AppParams *p);
uint8_t params_valid(const AppParams *p);
const char *params_key_name(RemoteKey key);
int params_key_index(const char *name);
#endif
