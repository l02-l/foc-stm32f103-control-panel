/* 本项目接口声明：函数用途和参数单位请结合对应 .c 文件中的中文说明阅读。 */
#ifndef MOTOR_PANEL_H
#define MOTOR_PANEL_H
#include "params.h"

/* STOPPED 停机；CALIBRATING 校准；RUNNING 闭环运行；FAULT 故障锁存。 */
typedef enum
{
    MOTOR_STOPPED,
    MOTOR_CALIBRATING,
    MOTOR_RUNNING,
    MOTOR_FAULT
} MotorState;
typedef enum
{
    FAULT_NONE,
    FAULT_SENSOR,
    FAULT_MAGNET,
    FAULT_OVERCURRENT,
    FAULT_ADC,
    FAULT_CALIBRATION,
    FAULT_TIMING,
    FAULT_NUMERIC
} MotorFault;
/* 区分 TIMING 的触发路径；timing_cycles 在 BACKLOG 时保存漏处理的控制节拍数。 */
typedef enum
{
    TIMING_NONE,
    TIMING_CONTROL,
    TIMING_SENSOR_INTERVAL,
    TIMING_SENSOR_TASK,
    TIMING_BACKLOG
} MotorTimingReason;
typedef struct
{
    /* 运行计数和耗时统计，耗时字段单位为 72 MHz CPU 周期数。 */
    uint32_t sensor_samples, current_steps, sensor_errors, fast_max_cycles, sensor_max_cycles;
    uint16_t raw, adc_a, adc_b; /* 三个原始量均为 0～4095 的计数 */
    uint8_t offsets_ready, sensor_ok, magnet_ok, calibrated;
    MotorState state;
    MotorFault fault;
    ControlMode mode;
    float position_rad, speed_rpm, ia, ib, id, iq, ud, uq,
        iq_target;                                               /* rad、rpm、A、A、A、A、V、V、A */
    float speed_target_rpm, position_target_rad, current_target; /* 用户给定：rpm、rad、A */
    float offset_a, offset_b;                                    /* 电流为零时两路 ADC 的平均计数 */
    uint32_t calibration_ms;                                     /* 本次校准已运行的毫秒数 */
    MotorTimingReason timing_reason;
    uint32_t timing_cycles;
} MotorStatus;

void motor_init(const AppParams *p);
void motor_snapshot(MotorStatus *out);
void motor_get_params(AppParams *out);
uint8_t motor_apply_params(const AppParams *p);
uint8_t motor_start(void);
void motor_stop(void);
uint8_t motor_calibrate(void);
uint8_t motor_clear_fault(void);
uint8_t motor_set_mode(ControlMode mode);
void motor_set_speed(float rpm);
void motor_set_position(float radians);
void motor_set_current(float amps);
void motor_zero_position(void);
void motor_reverse_target(void);
void motor_fault(MotorFault fault);
void motor_timing_fault(MotorTimingReason reason, uint32_t value);
void motor_adc_isr(uint16_t a, uint16_t b);
void motor_current_task(void);
void motor_sensor_isr(uint16_t raw, uint8_t ok, uint8_t magnet, uint32_t cycles, uint32_t ms);
void motor_record_sensor_time(uint32_t cycles);
const char *motor_state_name(MotorState state);
const char *motor_fault_name(MotorFault fault);
const char *motor_mode_name(ControlMode mode);
const char *motor_timing_name(MotorTimingReason reason);
#endif
